const fs = require('fs')
const {resolve} = require('path')
let filePath = __dirname +'\\src\\common\\BASE_URL.js'
let config =  []
let str=  fs.readFileSync(filePath,'utf-8')
str = str.replace(/\s*/g,"");
let url = /(http|ftp|https):\/\/[\w-]+(\.[\w-]+)+([\w.,@?^=%&amp;:\/~+#-]*[\w@?^=%&amp;\/~+#-])?/g;
config = str.match(url)

module.exports = {
  outputDir: "dist",
  publicPath: "/",
  assetsDir: "assets",
  productionSourceMap: false,
  devServer: {
    proxy: {
      "/api": {
         target: config[0],
        ws: true,
        changeOrigin: true,
        secure: false,
        pathRewrite: {
          "^/api": "/api",
        },
        headers: {
          Referer:config[0]
        }
      },
    },
    open: true,
    port:8888
  },
};
