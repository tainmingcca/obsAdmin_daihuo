<template>
  <div class="ser_home">
    <ul class="red_packet" id="red_packet">
        <li
        v-for="(item, index) in liParams"
          :key="index"
          :style="{
            left: item.left,
            animationDuration: item.durTime,
            webkitAnimationDuration: item.durTime,
          }"
          :class="item.cls"
          :data-index="index"
          @webkitAnimationEnd="removeDom"
        >
          <a @click="getredNums">
            <i
              :style="{
                transform: item.transforms,
                webkitTransform: item.transforms,
              }"
            ></i>
          </a>
        </li>
    </ul>
  </div>
</template>
 
 
<script>
import {MessageBox} from 'element-ui'
export default {
  data() {
    return {
      liParams: [],
      timer: null,
      redCatch:[],
      duration: 10*1000, // 红包持续时间
    };
  },
  mounted() {
    this.startRedPacket();
  },
  methods: {
    /**
     * 开启动画
     */
    startRedPacket() {
      let win =
        document.documentElement.clientWidth || document.body.clientWidth;
      let left = parseInt(Math.random() * (win - 50) + 0);

      let rotate = 0 + "deg"; // 旋转角度
      let scales = (Math.random() * (12 - 8 + 1) + 8) * 0.1; // 图片尺寸
      let durTime = Math.random() * (2.5 - 10 + 1) + 10 + "s"; // 时间  1.2和1.2这个数值保持一样
      this.liParams.push({
        left: left + "px",
        cls: "move_1",
        transforms: "rotate(" + rotate + ") scale(" + scales + ")",
        durTime: durTime,
      });

      setTimeout(() => {
        // 多少时间结束
        clearTimeout(this.timer);
        return;
      }, this.duration);

      this.timer = setTimeout(() => {
        this.startRedPacket();
      }, 100);
    },

    getredNums () {

      if (this.userInfo.isYk) return MessageBox.confirm("Please log in and get the red envelope", "Tips", { confirmButtonText: "confirm", cancelButtonText: "cancel", type: "warning",}).then(() => {this.$router.push("/login");});
            if (this.userInfo.is_open_red == 0) return  MessageBox.alert("You can't get it now, please contact customer service",'Tips',{ confirmButtonText: 'confirm', callback:action=>{}})
            let randomNum = (min, max) =>(Math.random() * (max - min + 1)).toFixed(1) + min;
            MessageBox.alert('Congratulations on your success','Tips',{
             confirmButtonText: 'confirm',
             customClass:"redrain_alert",
            callback:action=>{
       }
     })
     let data = { item :randomNum(3,11), type:1}
     this.$store.commit('getCatchRedNum',data)

    
    },
    /**
     * 回收dom节点
     */
    removeDom(e) {
      let target = e.currentTarget;
      document.querySelector("#red_packet").removeChild(target);
    },
  },
};
</script>
 
 
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
ul>li{
  list-style: none;
}
.ser_home {
  width: 100%;
  height: 100%;
  position: absolute;
  left: 0;
  top: 0;
}
.red_packet {
  display: block;
  position: relative;
  width: 100%;
  height: 100%;
  overflow: hidden;
  i {
    width: 50px;
    height: 56px;
    display: block;
    background: url("../assets/img/petal8.png") 100% 100%;
    overflow: hidden;
    background-size: cover;
  }
  li {
    position: absolute;
    animation: all 3s linear;
    top: -100px;
    z-index: 10;

    &.move_1 {
      -webkit-animation: aim_move 5s linear 1 forwards;
      animation: aim_move 5s linear 1 forwards;
    }
  }
  a {
    display: block;
  }
}

@keyframes aim_move {
  0% {
    -webkit-transform: translateY(0);
    transform: translateY(0);
  }
  100% {
    -webkit-transform: translateY(120vh);
    transform: translateY(120vh);
  }
}
</style>