<template>
  <div class="LuckyWheel_bg">
    <LuckyWheel
      class="zhuna_pai"
      width="524px"
      height="524px"
      :blocks="blocks"
      :prizes="prizes"
      :fonts="fonts.text"
      @start="startCallBack"
      @end="endCallBack"
      :buttons="buttons"
      ref="myLucky"
    />
    <span @click="$emit('closeTurnTable')" class="el-icon-close prze_close"></span>

  <div class="tzck" v-if ="isZhongJinag" >
    <ul  >
        <span @click="isZhongJinag = false" class="tzck_close">X</span>
        <h1 id="jx_1">Congratulations on your acquisition {{prizeInfo.prize}}</h1>
        <li>Please check your information:</li>
        <li><font id="jx_2" class="message">username ：{{prizeInfo.info.nick_name}}</font></li>
        <li><font id="jx_3" class="message">cell-phone number：{{prizeInfo.info.mobile?prizeInfo.info.mobile:'no data'}}   QQ：{{prizeInfo.info.user_qq?prizeInfo.info.user_qq:'no data'}}</font></li>
        <li><font id="jx_5" class="message">Winning time：{{prizeInfo.info.create_time}}</font></li>
        <li><font class="message">How to receive the award:</font>
        <!-- <a @click="$store.dispatch('getQQApi')" style="color:red;font-weight:600;cursor:pointer;">Click me </a>Send the winning screenshots to customer service -->
        </li>
    </ul>
</div>

  <div class="zhong_jiang_list">
    <vue-seamless-scroll :class-option="optionSingleHeight" :data="listData" class="seamless-warp">
        <ul class="item">
            <li v-for="(item,index) in listData" :key="index">
                <span class="title" v-text="item.nick_name"></span> acquire <span class="date" v-text="item.prize"></span>
            </li>
        </ul>
    </vue-seamless-scroll>

  </div>
    <div class="tips">
      Warm reminder: Each member can get a chance to draw, and the prize will be distributed within three working days. After winning the prize, you will send your mobile phone number and screenshot to the customer service. Please be sure to keep your mobile phone unblocked, so that the staff can verify the information and distribute the prize.
    </div>
  </div>
</template>

<script>
import { getTurnTableInfoApi, luckDrawApi } from "@/apis/index";
import vueSeamlessScroll from 'vue-seamless-scroll'
export default {
  data() {
    return {
      isZhongJinag:false,

      blocks: [
        {
          imgs: [
            {
              src: "",
              width: "100%",
              rotate: true,
            },
          ],
        },
      ],

      buttons: [
        {
          radius: "50%",
          imgs: [
            {
              src: require("../assets/img/z.png"),
              width: "127px",
              top: "-70px",
            },
          ],
        },
      ],


      prizes: [
        { title: "0" },
        { title: "1" },
        { title: "2" },
        { title: "3" },
        { title: "4" },
        { title: "5" },
        { title: "6" },
        { title: "7" },
        { title: "8" },
        { title: "9" },
        { title: "10" },
        { title: "11" },

        // { title: "0" , fonts: [{ text: 0, top: '10%' }]},
        // { title: "1" , fonts: [{ text: 1, top: '10%' }]},
        // { title: "2" , fonts: [{ text: 2, top: '10%' }]},
        // { title: "3" , fonts: [{ text: 3, top: '10%' }]},
        // { title: "4" , fonts: [{ text: 4, top: '10%' }]},
        // { title: "5" , fonts: [{ text: 5, top: '10%' }]},
        // { title: "6" , fonts: [{ text: 6, top: '10%' }]},
        // { title: "7" , fonts: [{ text: 7, top: '10%' }]},
        // { title: "8" , fonts: [{ text: 8, top: '10%' }]},
        // { title: "9" , fonts: [{ text: 9, top: '10%' }]},
        // { title: "10" , fonts: [{ text: 10, top: '10%' }]},
        // { title: "11" , fonts: [{ text: 11, top: '10%' }]},
      ],
      fonts:[

      ],
      prizeInfo:{},
      listData: []
    };
  },
  computed: {
    optionSingleHeight () {
      return {
                singleHeight: 26
              }
    }
  },
  methods: {
    async getTurnTableInfo() {
      const { data: res } = await getTurnTableInfoApi();
      if (res.code == 201) return this.$toast(res.msg);
      this.listData = res.data.prizeList
      this.blocks[0].imgs[0].src = res.data.turntableInfo.bg_img;
    },
    // 开始转
    async startCallBack() {
      this.$refs.myLucky.init();
      const { data: res } = await luckDrawApi();
      if (res.code !== 200) return this.$toast(res.msg);
      this.$refs.myLucky.play();
      setTimeout((_) => {
        this.$refs.myLucky.stop(res.data.index);
        this.prizeInfo = res.data
      }, 2500);
    },
    endCallBack() {
       this.currStatus = 0;
        this.isZhongJinag = true

    },
  },
  components: {
    vueSeamlessScroll
  },
  created() {this.getTurnTableInfo();},

};
</script>
<style lang="scss" scoped>

.prze_close {
  position: absolute;
  right: 50px;
  top: 0;
  font-size: 28px;
  color: red;
  background-color: #fff;
  border-radius: 50%;
}
.zhong_jiang_list{
    position: absolute;
    right: 153px;
    bottom: 111px;
    width: 300px;
    color: #fff;
    text-align: center;
    .seamless-warp{
      width: 100%;
      height: 133px;
      overflow: hidden;
      ul li {
        line-height: 30px;
      }
    }
}
.tips{
    position: absolute;
    bottom: 45px;
    right: 75px;
    color: #fff;
    width: 450px;
    text-indent: 2em;
}
.tzck,.tzck1{position:fixed;width:400px;background:#fff;border:8px solid #f60;top:39%;left:0;right:0;margin:0 auto;text-align:center;height:260px;border-radius:15px;z-index:3}
.tzck h1,.tzck1 h1{margin:15px auto;font:30px "Microsoft Yahei";text-align:center;color:#f60;font-weight:bold;width:380px}
.tzck span,.tzck1 span{position:absolute;right:-10px;height:30px;background:#F60;line-height:23px;width:30px;text-align:center;top:-20px;border:5px solid #fff;border-radius:30px;color:#fff;cursor:pointer}
.tzck li{width:330px;float:left;font-style:normal;list-style:none;height:30px;line-height:30px;text-align:left;padding-left:2em;font:16px "Microsoft Yahei"}
.tzck li .message{color:#f60}

</style>