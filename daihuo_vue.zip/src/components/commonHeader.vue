<template>
  <div>


    <header v-if="bodyWidth > 880" :style="{ background: '#22232D' }">
      <div class="bo_logo f_left" id="headlogo"
        :style="{ background: `url('${roomInfo.logo_url}') center center / 100% 80% no-repeat`, }"></div>
      <section class="header_nav_menu">
        <div class="header_nav_menu_left">
          <div class="hover_bg" :class="$route.path == '/' ? 'current' : ''" @click="showDialog('Home')">
            <span>Home</span>
          </div>





          <div class="hover_bg" :class="$route.path == '/yssm' ? 'current' : ''" @click="showDialog('Class schedule')">
            <span>Class schedule</span>
          </div>

          <div class="hover_bg" @click="showDialog('Save desktop')">
            <span>Save desktop</span>
          </div>
        </div>

        <div v-if="!isShowChat" class="min_chat " @click="$store.commit('getIsShowChat', true)">
          <el-badge :value="redcount" :hidden="redcount == 0" :max="99">
            <img height="200" src="@/assets/img/kefu.png" alt="">
          </el-badge>
        </div>


        <div class="flex_right">

          <span style="margin: 0 5px;color:#FFF;" v-if="userInfo.isYk == 1">{{ userInfo.nick_name }}</span>
          <div v-if="userInfo.isYk == 1" style="margin-left:10px;">
            <span @click="headMenu2Click(3)" class="login_btn hover">login</span>
            <span> / </span>
            <span @click="headMenu2Click(4)" class="login_btn hover">register</span>
          </div>

          <div v-else class="user_line" @click="showUserInfo = true">
            <img :src="userInfo.head_img" alt="">
            <span class="nick_name"> {{ userInfo.nick_name }}</span>
          </div>

        </div>
      </section>

      <userInfo class="poab_user_info" v-if="showUserInfo" @showInfoCener="showInfoCeners" @showChangePwd="showChangePwds"
        @closeUserInfo="closeUserInfos" @showregred="showregreds" />
      <!-- 登录 -->
      <login v-if="showLogin" @openRegCloseLogin="showReg = true; showLogin = false" @closeLogin=" showLogin = false " />
      <!-- 注册 -->
      <reg v-if=" showReg " @openLoginCloseReg=" showLogin = true; showReg = false " @closeReg=" showReg = false " />
      <!-- 课程安排 -->
      <class v-if=" showClass " @closeClass=" showClass = false " />
      <!-- 产品介绍 -->
      <chanpin v-if=" showchanPin " @closeChanPin=" showchanPin = false " />
      <!-- 在线开户 -->
      <server v-if=" showServer " @closeSever=" showServer = false " />
      <!-- 手机直播 -->
      <shoujizhibo v-if=" showShoujizhibo " @closeMobile=" showShoujizhibo = false " />
      <!-- 名师指导 -->
      <teacher v-if=" showTeacher " @closeTeacher=" showTeacher = false " />
      <!-- 修改密码 -->
      <changePwd v-if=" showChangePwd " @closePwd=" showChangePwd = false " />
      <!-- 个人资料 -->
      <infoCenter v-if=" showInfoCener " @closeInfoCenter=" showInfoCener = false " />
      <!-- 快递查询 -->
      <kuaidi v-if=" showKuaDi " @closeKuaidi=" showKuaDi = false " />
    </header>
  </div>
</template>

<script>
import { Alert, MessageBox } from "element-ui";
import { EventBus } from "@/tools/EventBus";
import { mapGetters } from "vuex";
export default {
  data() {
    return {
      showUserInfo: false,
      showInfoCener: false, // 用户个人资料
      showChangePwd: false, // 修改密码
      showKuaDi: false, // 快递查询
      showShoujizhibo: false,
      showServer: false,
      showchanPin: false,
      showTeacher: false,
      showRiLi: false,
      showClass: false,
      showLogin: false,
      showReg: false,
      time: ""
    };
  },
  computed: {
    ...mapGetters(["redcount"]),

  },
  methods: {
    closeUserInfos() {
      this.showUserInfo = false;
    },
    showInfoCeners() {
      this.showInfoCener = true;
    },
    showChangePwds() {
      this.showChangePwd = true;
    },
    showregreds() {
      this.showRegRedDialog = true;
    },
    // 坐着tab栏弹窗
    showDialog(item) {
      switch (item) {
        case "Home":
          this.$router.push('/')
          break;
        case "Class schedule":
          this.showClass = true;
          break;
        case "Privacy statement":
          this.$router.push('/yssm')
          // this.showchanPin = true;
          break;
        case "在线开户":
          // this.showServer = true;
          break;

        case "名师风采":
          this.showTeacher = true;
          break;
        case "软件下载":
          // location.href="/soft/按揭首付云期货交易端.exe"
          break;
        case "Save desktop":
          window.open("/api/saveDesktop");
          // this.showKuaDi = true
          break;

        default:
          break;
      }
    },
    headMenu2Click(id) {
      switch (id) {
        case 1:
          this.showUserInfo = this.userInfo.isYk ? false : true;
          break;
        case 2:
          //  this.isShowSkin = true
          break;
        case 3:
          // this.$router.push("/login");
          this.showLogin = true
          break;
        case 4:
          if (this.roomInfo.is_open_reg == 0) {
            MessageBox.alert("Please contact customer service to register", "Tips", {
              confirmButtonText: "confirm",
              showClose: false,
              callback: (action) => {
                this.lookTimeEnd = false;
              },
            });
          } else {
            // this.$router.push("/register");
            this.showReg = true
          }
          break;
        default:
          break;
      }
    },
    getThisTime() {
      let datas = new Date()
      var on2 = ":";
      var onS = datas.getHours(); //时
      var onF = datas.getMinutes(); //分
      var onN = datas.getSeconds(); //秒
      if (onS >= 0 && onS <= 9) {
        onS = "0" + onS;
      }
      if (onF >= 0 && onF <= 9) {
        onF = "0" + onF;
      }
      if (onN >= 0 && onN <= 9) {
        onN = "0" + onN;
      }
      return {
        time: onS + on2 + onF + on2 + onN,
      };
    },
  },
  components: {
    userInfo: () => import("../components/userInfo/userInfo.vue"),
    class: () => import("../components/diaLog/class.vue"),
    chanpin: () => import("../components/diaLog/chanpin.vue"),
    login: () => import("../components/diaLog/login.vue"),
    reg: () => import("../components/diaLog/reg.vue"),
    server: () => import("../components/diaLog/server.vue"),
    shoujizhibo: () => import("../components/diaLog/shoujizhibo.vue"),
    teacher: () => import("../components/diaLog/teacher.vue"),
    kuaidi: () => import("../components/diaLog/kuaidi.vue"),
    changePwd: () => import("../components/userInfo/changePwd.vue"),
    infoCenter: () => import("../components/userInfo/infoCenter.vue"),
  },
  created() { },
  mounted() {
    const clock = setInterval(() => {
      this.time = this.getThisTime().time;
    }, 1000);
    // 通过$once来监听定时器，在beforeDestroy钩子可以被清除。
    this.$once("hook:beforeDestroy", () => {
      clearInterval(clock);
    });
    EventBus.$on('opReg', () => {
      this.showReg = true
    })
    EventBus.$on('openLogin', () => {
      this.showLogin = true
    })
  }
};
</script>
<style lang="scss" scoped>
.poab_user_info {
  position: absolute;
  right: 20px;
  top: 65px;
  z-index: 9;
}

.new_header {
  width: 100%;
  background-color: #263049;
  color: #fff;
  height: 30px;
  display: flex;
  justify-content: space-between;
  box-sizing: border-box;
  padding: 0 20px;
  align-items: flex-end;

  .right {
    display: flex;

    .text {
      margin-right: 10px;

    }

    .line {
      margin: 0 10px;
    }
  }
}

.current {
  background-color: #ead5d336;
}

.user_line {
  display: flex;
  align-items: center;

  img {
    width: 30px;
    height: 30px;
    border-radius: 50%;
    margin-right: 10px;
  }

  .nick_name {
    color: #fff;
  }

  .user_center {
    padding: 5px 10px;
    background: #DD952B;
    cursor: pointer;
  }

}

.min_chat {
  position: fixed;
    top: 35%;
    right: 20px;
  z-index: 9;
  box-sizing: border-box;
  align-items: center;
  padding: 5px 10px;
  line-height: 20px;
  cursor: pointer;
  display: flex;

 
}</style>