<template>
  <div>
    <div id="topic" ref="rightChatBox">
      <div class="notice" v-if="bodyWidth > 800">
        <img width="30" height="30" src="@/assets/img/duoren.png" alt="">
        <div class="tops_info">
          <span style="color:#FFF326;flex-shrink: 0;">Online audience {{onLineData.totalUser}} </span>
        <!---->
        <marquee direction="left" style="color:#fff;font-size:16px;font-weight:700;margin-left:10px;"  id="livenotice" scrollamount="3" > {{userData.notice}} </marquee>
        </div>

      </div>

      <!-- 移动端状态栏 -->
      <div v-else class="m_header" style="padding: 5px 10px">
        <div
          class="m_header_left"
          v-if="userInfo.admin_uid"
          @click="lianxiKeFu"
          style="width: 40%; text-align: left"
        >
          <span v-if="!mobileChat">【Online Service】</span>
          <span v-else><i class="el-icon-arrow-left mobile_icon"></i> </span>
        </div>
        <div class="m_header_right">
          <span>{{ userInfo.nick_name }}</span>
          <div
            v-if="utoken"
            @click="logOut"
            class="cfg m_reg_btn"
            style="background-color: #f34a1e; margin-left: 10px"
          >
          quit
          </div>

          <template v-else>
            <div class="cfg m_login_btn" @click="$router.push('/login')">
             login
            </div>
            <div
              class="cfg m_reg_btn"
              @click="$router.push('/register')"
              style="background-color: #f34a1e"
            >
             register
            </div>
          </template>
        </div>
      </div>
      <!-- 移动端状态栏 -->

      <!-- 互动容器 -->
      <template v-if="!mobileChat">
        <div
          @scroll="closeBox()"
          @click="closeOtherBox"
          class="chat_content"
          id="hd_list"
          ref="rightChat"
          :style="{ background: mobileChat ? '#eeeeee' : '#22232D' }"
        >
          <!-- 互动聊天 -->
          <div
            class="topicbox"
            @contextmenu.prevent="rightClick($event, item)"
            v-for="(item, index) in hdMsgList"
            :key="index"
          >
            <div class="msguser">
              <img class="roleimg" :src="item.group_icon" />
              <span v-if="userInfo.user_type == 1 && item.admin_nickname != ''" :class="item.admin_nickname != '' ? 'redCss' : 'whiteCss'" >【{{ item.admin_nickname }}】</span>
              <span  :class="item.is_nick_name_red == 1 ? 'redCss' : 'whiteCss'" >{{ item.nick_name }} </span>
              <span class="talk_time"> {{ item.send_time }}</span>
              <span v-if="userInfo.user_type == 1 && !item.admin_nickname" :class="!item.admin_nickname ? 'redCss' : 'whiteCss'" >({{ item.ip }})</span>
              <span v-if="userInfo.user_type == 1 && item.status == 0" class="redCss" >(待审核)</span>
            <div :class="item.is_red == 1 ? 'redCss' : ''" @click="viewImg(item.content)" v-html="item.content.replace(/\#[\u4E00-\u9FA5]{1,3}\;/gi, emotion)" class="talk_content"></div>
            </div>
          </div>
          <!-- 互动聊天 -->
        </div>
        <!-- 这里是PC端底部聊天 -->
        <div class="chat_footer pore" v-if="!mobileChat">
          <div id="topicinput">
            <div class="tool_bar bg_color" @click.self = "closeOtherBox">
 
                <!-- 放烟花 -->
                <!-- <img @click="sendFireWork" style="width: 30px; height: 30px; margin-right: 30px" src="../assets/img/3.png"/> -->
                <!-- 语音和红包雨 -->
                <!-- <div class="jnpai_zhuli" style="background-color: #67c23a">
                  <img @click="showAudio = true"   style="width:20px;" src="../assets/img/audio.png" alt="">
                  <img @click="tipRedRain"   style="width:30px;" src="../assets/img/redyu.png" alt="">
                </div> -->
   
   
            

                <div class="select_class" @click="showRobotList =!showRobotList" v-if="userInfo.user_type == 1">
                    <span class="shenglue">{{defaultUser}}</span>
                    <img width="15" src="@/assets/img/sanjiao.png" alt="">
                    <div class="robot_list" @click.stop  v-show="showRobotList">
                      <span  @click.stop="getRobot(0,false)">当前登录账户</span>
                      <span :class="robotId == item.id ? 'span_active' : ''" v-for="(item, index) in robotList" :key="index" @click.stop="getRobot(item.id,item)">{{ item.nick_name }} ( {{ item.group_name }} )</span>
                    </div>
                </div>
                <!-- 选择群发或者过度   -->
                <section class="radio_class" v-if="userInfo.user_type == 1" >
                    <div @click="setDanMu" :class="isDanmu == 1 ? 'radio_current':''">
                        <span class="round"><i></i></span>
                        <span>danmu</span>
                    </div>
                    <!-- <div  class="qun_btn" @click="groupSend">
                        <span>group</span>
                    </div> -->
                </section>
                <!-- <div class="danmu_btn" style="color: #fff" name="danmu">
                  <input type="checkbox" @click="setDanMu" :checked="isDanmu" />弹幕
                </div> -->
            </div>

            <div class="what_list" v-if="userInfo.user_type != 1">
            <div  @click="openOtherLink(item)" class="jnpai_zhuli" v-for="(item, index) in qqList" :key="index" >
              <img :src="item.qq_icon" alt="">
            </div>
            </div>

            <div class="input_area bg_color">
             <!-- 表情列表 -->
                <div class="qqFace" v-show="isShowqqFace">
                  <img class="imgBox" @click="closeqqFace(item.alt)" v-for="(item, index) in qqFaceList.emojiList" :key="index" :src="item.url"/>
                </div>
                <!-- 彩条列表 -->
                <dl class="caitiao_box" v-show="isShowcalTiao">
                  <dd @click="closeCaiTiao(item)" v-for="(item, index) in praiseList" :key="index">
                    <img :src="item" />
                  </dd>
                </dl>

                <!-- 发送表情和图片 -->
                <div class="send_tool">
                    <!-- 表情 -->
                    <img width="25" class="icon_img" @click="isShowqqFace = !isShowqqFace" :src="require('@/assets/img/biaoqing.png')" />
                    <!-- 彩条 -->
                    <img width="25" class="icon_img" @click="isShowcalTiao = !isShowcalTiao" :src="require('@/assets/img/caitiao.png')" style="margin:0 10px;"/>
                    <!-- 图片 -->
                    <el-upload v-if="userInfo.user_type == 1" :auto-upload="false" action="" :on-change="fileAdress" :show-file-list="false" accept="image/gif,image/jpeg,image/jpg,image/png">
                        <img width="25" class="icon_img" :src="require('@/assets/img/tupian.png')" />
                    </el-upload>
                </div>

                <!--公屏输入框  -->
                <div id="sendMsgInput" @paste="getPritContend($event)" @keydown.enter="sendMsg($event)" ref="inputBody" contenteditable="true" class="content1" placeholder="Let's interact with you..."></div>
                <!-- 发送按钮 -->
                <a class="btn_send" @click="sendMsg($event)"> send</a>
            </div>
          </div>
        </div>
        <!-- 这里是PC端底部聊天 -->
      </template>
      <!-- /互动容器 -->

      <template v-else>
        <!-- 移动端客服聊天 -->
        <div @scroll="loadMoreKefuMsg($event)" @click="closeOtherBox" id="appScroll" class="chat_content chat_main chatContent chat_main_min" ref="mobileChat" :style="{   background: mobileChat ? '#eeeeee' : 'rgba(0, 0, 0, 0.3)',   marginBottom: '100px',}">
          <div class="pore msg_detail" v-for="(item, index) in historylist" :key="index" :class="item.send_uid == userInfo.id ? ' my_msg_detail ' : '   '">
            <img :src="item.send_uid != userInfo.id? item.send_headimg: userInfo.head_img" width="40px" height="40px" style="border-radius: 50%"/>

            <div class="msg_detail_main">
              <div class="nick_name_class" :class="item.send_uid == userInfo.id ? ' my_nick_name_class ' : '' ">
                <span>{{ item.create_time }}</span> {{ item.send_nickname }}
              </div>
              <div class="msg_box">
                <!-- 文本 -->
                <div v-html="item.content.replace(/\#[\u4E00-\u9FA5]{1,3}\;/gi, emotion) " v-if="item.msg_type == 1" class="text_body"></div>
                <!-- /文本 -->
				
                <!-- 图片 -->
                <div v-if="item.msg_type == 2" class="image_body">
                  <el-image fit="scale-down" :src="item.content" @load="scrollBottom"></el-image>
                </div>
                <div class="read_box" v-show="item.send_uid == userInfo.id">
                  <span :class="item.send_uid != userInfo.id ? ' other_style' : ' my_style'" class="wzdu_item" v-if="item.is_read == 0" >未读</span>
                  <span :class="  item.send_uid != userInfo.id ? ' other_style' : ' my_style' " class="yidu_item" v-else >已读</span>
                </div>
                <!-- /图片 -->
              </div>
            </div>
          </div>
        </div>
        <!-- /移动端客服聊天 -->
        <!-- 这里是移动端底部聊天 -->
        <div class="chat_footer_mobile">
          <div class="flex_input">
            <input @keyup.enter="sendMobileMsg" ref="mobileBbody" type="text" />
            <el-button @click="sendMobileMsg" type="primary"> 发送 </el-button>
          </div>
          <div class="icon_box">
            <div @click="isShowqqFace = !isShowqqFace">
              <i class="iconfont icon-biaoqing"></i>
            </div>
            <el-upload
              :auto-upload="false"
              action=""
              :on-change="fileAdress2"
              :show-file-list="false"
              accept="image/gif,image/jpeg,image/jpg,image/png"
            >
              <i class="iconfont icon-tupian"></i>
            </el-upload>
            <div class="appqqFace" v-show="isShowqqFace">
              <img
                class="imgBox"
                @click="getFaceByApp(item.alt)"
                v-for="(item, index) in qqFaceList.emojiList"
                :key="index"
                :src="item.url"
                alt=""
              />
            </div>
          </div>
        </div>
        <!--/ 这里是移动端底部聊天 -->
      </template>
    </div>

    <ul v-if="userInfo.user_type == 1" v-show="menuVisible" class="menu">
      <li @click="atUser" class="contextmenu__item" name="aite">@this user</li>
      <li @click="jinYanUser" class="contextmenu__item" name="jinyan">
Ban the user
      </li>
      <li @click="pingbiUser" class="contextmenu__item" name="pingb">
        Mask the IP address of the user
      </li>
      <li @click="delMsg" class="contextmenu__item" name="del">Delete this message</li>
      <li @click="passMsg" class="contextmenu__item" name="pass">By this message</li>
    </ul>

    <div class="menu_list">
      <!-- <a @click="$emit('openSig')" style="color:#fff;margin-right:10px;course:pointer;">
                <img width="40" src="@/assets/img/qiandao.png" alt="" class="pulse"/>
                <span style="display: inline-block;  vertical-align: middle;">大礼包</span>
            </a>  -->
      <!-- <a href="https://okg-pub-hk.oss-cn-hongkong.aliyuncs.com/upgradeapp/OKX_Setup.exe" target="_blank" style="color:#fff;margin-right:10px;">
            <img width="50" src="@/assets/img/okex.png" alt="" class="pulse"/>
            </a> -->
      <!-- <a href="/soft/Skype_8.75.0.140.exe" target="_blank" style="color:#fff;margin-right:10px;">
          <img width="40" src="@/assets/img/skype1.png" alt="" class="pulse"/>
          <span style="display: inline-block; vertical-align: middle">Skype</span>
        </a> -->
      <!-- <a @click="$emit('openDaZhuanPa')"  v-if="$store.state.userData.turnopen"  style="color:#fff;margin-right:10px;" >
          <img width="40" src="@/assets/img/dzp.png" alt="" />
          <span style="display: inline-block;  vertical-align: middle">大转盘</span>
        </a> -->
    </div>

    <AudioBox v-if="showAudio" @closeAudio="showAudio = false" />
  </div>
</template>

<script>
import emojiList from "@/assets/js/emjoy";
import { Alert, MessageBox } from "element-ui";
// import {imgUrl} from '@/common/BASE_URL.js'
import { sendHdMsgApi, contextMenuApi, sendImMsgApi, getHistoryMsgApi, sendBalloonApi, sendRedRainApi, sendGroupMsgApi} from "@/apis/index.js";
import { EventBus } from "@/tools/EventBus";
EventBus.$on("updateHdMsgScroll", () => {
  setTimeout(() => {
    let scroll = document.getElementById("hd_list");
    try {
      scroll.scrollTop = scroll.scrollHeight;
    } catch (error) {}
  }, 13);
});
EventBus.$on("updateHistoryMsgScrollByApp", () => {
  setTimeout(() => {
    let scroll = document.getElementById("appScroll");
    try {
      scroll.scrollTop = scroll.scrollHeight;
    } catch (error) {}
  }, 13);
});
export default {
  data() {
    return {
      isShowcalTiao: false, // 彩条
      isShowqqFace: false, // QQ表情
      isShowKehu: true, //在线客服
      menuVisible: false, //右键菜单
      hdMsgInfo: new Object(), // 点击右键获取的消息
      qqFaceList: emojiList, // QQ表情
      robotId: 0, // 是不是机器人
      isDanmu: 0, // 发送类型是否为弹幕
      sendType:"",
      srcByOss: "", // oss
      flag: true, // 滚动方式多次出发加载历史消息
      showAudio: false,
      showRobotList:false,
      defaultUser:"Current login account",
	  robotList2:[]
    };
  },
  computed: {
    praiseList() {
      let arr = [];
      for (var i = 1; i <= 4; i++) {
        arr.push(require(`@/assets/img/praise2/${i}01.png`));
      }
      return arr;
    },
  },
  methods: {
	  async groupSend () {
		  if (!this.$refs.inputBody.innerHTML) return this.$toast("Content is null");
		  if (this.robotList2.length == 0) return this.$toast("Please select robot");
		  let ids = this.robotList2.toString()
		  
			let reqdata = {
				robotId:ids,
				content:this.$refs.inputBody.innerHTML
			}
			const {data:res} =  await sendGroupMsgApi(reqdata)
			if (res.code == 200) {
				this.$refs.inputBody.innerText = "";
			}else {
				return this.$toast(res.msg)
			}
	  },
    // 获取发送类型
    getSendType () {
      if (this.sendType == 1) {
        this.sendType = 0
      }else {
        this.sendType = 1
      }
    },
    openOtherLink (item) {
      const aLink = document.createElement('a')
      aLink.href =  `https://wa.me/${item.qq_account}`
      aLink.setAttribute('target', '_blank');
      aLink.setAttribute('aria-label', 'Chat on WhatsApp');
      aLink.click()
    },
    async sendFireWork() {
      const { data: res } = await sendBalloonApi();
    },
    tipRedRain() {
      MessageBox.confirm("Whether to start red envelope rain", "Tips", {
        confirmButtonText: "confirm",
        cancelButtonText: "cancel",
        type: "warning",
      }).then(async () => {
        const { data: res } = await sendRedRainApi();
        if (res.code != 200) return this.$toast(res.msg);
        // EventBus.$emit('sendRedRain')
      });
    },

    viewImg(str) {
      try {
        let srcReg = /src=[\'\"]?([^\'\"]*)[\'\"]?/i; // 匹配图片中的src
        let src = str.match(srcReg);
        this.$bigImg(src[1]);
      } catch (error) {
        console.log(error);
      }
    },
    logOut() {
      this.$store.dispatch("logOutApi");
    },
    closeBox() {
      this.closeOtherBox();
    },
    // 获取QQ

    lianxiKeFu() {
      if (this.mobileChat) {
        this.$store.commit("showMobileChat", false);
      } else {
        let reqdata = {
          id: this.userInfo.admin_uid,
          last_time: "",
        };
        this.$store.dispatch("getHistoryMsgApi", reqdata);
        this.$store.commit("showMobileChat", true);
      }
    },
    // @ 功能
    atUser() {
      let font = document.createElement("font");
      font.style.color = "red";
      font.style.fontWeight = 700;
      font.innerHTML = ` Say it to【${this.hdMsgInfo.nick_name}】 :`;
      document.getElementById("sendMsgInput").innerHTML = "";
      document.getElementById("sendMsgInput").append(font);
    },
    // 删除消息
    delMsg() {
      this.$store.dispatch("delMsg", this.hdMsgInfo);
    },
    async jinYanUser() {
      let reqdata = {
        type: "jinyan",
        id: this.hdMsgInfo.id,
      };
      const { data: res } = await contextMenuApi(reqdata);
      this.$toast(res.msg);
    },
    async pingbiUser() {
      let reqdata = {
        type: "pingb",
        id: this.hdMsgInfo.id,
      };
      const { data: res } = await contextMenuApi(reqdata);
      this.$toast(res.msg);
    },
    passMsg() {
      this.$store.dispatch("passMsg", this.hdMsgInfo);
    },

    // 获取机器人
    getRobot(id,item) {
      this.robotId = id
      this.showRobotList = false
	  // if ()
	  // let index = this.robotList2.findIndex(item=>item == id)
	  // if (index == -1) {
		//   this.robotList2.push(id);
	  // }else {
		//   this.robotList2.splice(index,1)
		  
	  // }
	  
    //   if (id!=0) {
		// if (this.robotList2.length >1) {
		// 	this.defaultUser = `${this.robotList2.length} robots have been selected`
		// }else {
		// 	this.defaultUser = item.nick_name + '('+  item.group_name + ')'
		// }
    //   }else {
		// this.robotList2 = []
    //     this.defaultUser = 'Current login account'
		// this.showRobotList = false
    //   }
    },
    // 是否弹幕
    setDanMu(e) {
      if (this.isDanmu) this.isDanmu = 0;
      else this.isDanmu = 1;
    },
    // oss 图片
    async fileAdress(file) {
      let img = new Image();
      img.src = await this.getOssSrc(file, "chat");
      document.getElementById("sendMsgInput").append(img);
    },
    // oss图片2
    async fileAdress2(file) {
      let content = await this.getOssSrc(file, "im");
      let reqdata = {
        friend_id: this.userInfo.admin_uid,
        content,
        msg_type: 2,
      };
      let msgData = {
        content,
        msg_type: 2,
        send_nickname: this.userInfo.nick_name,
        send_uid: this.userInfo.id,
        is_read: 0,
      };
      this.$store.commit("addHistoryMsg", msgData);
      const { data: res2 } = await sendImMsgApi(reqdata);
      if (res2.code != 200) return this.$toast(res.msg);
      this.$nextTick(() => {
        this.$refs.mobileChat.scrollTop = this.$refs.mobileChat.scrollHeight;
      });
    },
    // 情况聊天
    clearCHatMsg() {
      this.$store.commit("clearHdMsgList");
    },
    // 来消息不滚动
    changeScroll() {
      this.$store.commit("changeScroll");
    },
    // 发送消息
    async sendMsg(event) {
      event.cancelBubble = true;
      event.preventDefault();
      event.stopPropagation();
      this.closeOtherBox();
      if (!this.$refs.inputBody.innerHTML) return this.$toast("Content is null");
      let content = this.$refs.inputBody.innerHTML;
      // let ids = this.robotList2.toString()
      let reqdata = {
        isDanmu: this.isDanmu || "",
        robotId: this.robotId || "",
        content,
      };
      console.log(reqdata);
      const { data: res } = await sendHdMsgApi(reqdata);
      this.$refs.inputBody.innerText = "";
      if (res.code !== 200) return this.$toast(res.msg);
      this.$nextTick(() => {
        this.$refs.rightChat.scrollTop = this.$refs.rightChat.scrollHeight;
      });
    },
    // 移动端发送消息
    async sendMobileMsg() {
      this.closeOtherBox();
      if (!this.$refs.mobileBbody.value) return  this.$toast("Content is null");
      let content = this.$refs.mobileBbody.value;
      let reqdata = {
        friend_id: this.userInfo.admin_uid,
        content,
        msg_type: 1,
      };
      const { data: res } = await sendImMsgApi(reqdata);
      this.$refs.mobileBbody.value = "";

      let msgData = {
        content,
        msg_type: 1,
        send_nickname: this.userInfo.nick_name,
        send_uid: this.userInfo.id,
        is_read: 0,
      };
      this.$store.commit("addHistoryMsg", msgData);
      if (res.code !== 200) return this.$toast(res.msg);

      this.$nextTick(() => {
        this.$refs.mobileChat.scrollTop = this.$refs.mobileChat.scrollHeight;
      });
    },
    // 移动端发送QQ表情
    getFaceByApp(body) {
      this.$refs.mobileBbody.value += body;
    },
    // 移动端加载历史消息
    async loadMoreKefuMsg(e) {
      if (this.historylist.length == 0) return false;
      this.closeOtherBox();
      let scrollTop = e.target.scrollTop;
      if (scrollTop == 0) {
        let reqdata = {
          friend_id: this.userInfo.admin_uid,
          last_time: this.historylist[0].last_time,
        };
        if (!this.flag) return false;
        this.flag = true;
        const { data: res } = await getHistoryMsgApi(reqdata);
        if (res.code != 200) return this.$toast(res.msg);
        if (res.data.length == 0) {
          this.flag = false;
        } else {
          let hst = e.target.scrollHeight;
          this.$store.commit("mergeHistTotyList", res.data.reverse());
          this.$nextTick(() => {
            e.target.scrollTop = e.target.scrollHeight - hst;
          });
        }
      }
    },
    // 关闭彩条
    async closeCaiTiao(body) {
      let reqdata = {
        isDanmu: this.isDanmu || "",
        robotId: this.robotId || "",
        content: `<img src="${body}" />`,
      };

      const { data: res } = await sendHdMsgApi(reqdata);
      if (res.code !== 200) return this.$toast(res.msg);
      this.$nextTick(() => {
        this.$refs.rightChat.scrollTop = this.$refs.rightChat.scrollHeight;
      });
    },
    // 关闭QQ表情
    closeqqFace(body) {
      this.$refs.inputBody.innerText += body;
    },
    // 关闭 彩条和表情
    closeOtherBox() {
      this.isShowcalTiao = false; // 彩条
      this.isShowqqFace = false; // QQ表情
	  this.sendType = ""
	  this.showRobotList = false
    },
    // 展示右键菜单
    rightClick(event, item) {
      if (!this.userInfo.is_audit) return false;
      this.hdMsgInfo = item;
      //   this.testModeCode = row.testModeCode
      this.menuVisible = false; // 先把模态框关死，目的是 第二次或者第n次右键鼠标的时候 它默认的是true
      this.menuVisible = true; // 显示模态窗口，跳出自定义菜单栏
      event.preventDefault(); //关闭浏览器右键默认事件
      //   this.CurrentRow = row
      var menu = document.querySelector(".menu");
      this.styleMenu(menu, event);
    },
    foo() {
      // 取消鼠标监听事件 菜单栏
      this.menuVisible = false;
      document.removeEventListener("click", this.foo); // 关掉监听，
    },
    styleMenu(menu) {
      if (event.clientX > 1800) {
        menu.style.left = event.clientX - 100 + "px";
      } else {
        menu.style.left = event.clientX + 1 + "px";
      }
      document.addEventListener("click", this.foo); // 给整个document新增监听鼠标事件，点击任何位置执行foo方法
      if (event.clientY > 700) {
        menu.style.top = event.clientY - 30 + "px";
      } else {
        menu.style.top = event.clientY - 1 + "px";
      }
    },
    // 图片加载完成滚动到底部
    scrollBottom() {
      this.$refs.mobileChat.scrollTop = this.$refs.mobileChat.scrollHeight;
    },
    // 获取剪切板内容
    async getPritContend(e) {
      const cbd = e.clipboardData;
      const ua = window.navigator.userAgent;
      // 如果是 Safari 直接 return
      if (!(e.clipboardData && e.clipboardData.items)) return;
      if (
        cbd.items &&
        cbd.items.length === 2 &&
        cbd.items[0].kind === "string" &&
        cbd.items[1].kind === "file" &&
        cbd.types &&
        cbd.types.length === 2 &&
        cbd.types[0] === "text/plain" &&
        cbd.types[1] === "Files" &&
        ua.match(/Macintosh/i) &&
        Number(ua.match(/Chrome\/(\d{2})/i)[1]) < 49
      )
        return;
      for (let i = 0; i < cbd.items.length; i++) {
        let item = cbd.items[i];
        if (item.kind == "file") {
          const blob = item.getAsFile();
          // const { data: res } = await getOssApi("chat");
          const formData = new FormData();
          // formData.append("policy", res.data.policy);
          // formData.append("OSSAccessKeyid", res.data.accessid);
          // formData.append("signature", res.data.signature);
          // formData.append("success_action_status", 200);
          // formData.append("key",res.data.dir + blob.lastModified + blob.name
          // );
          formData.append("file", blob);
          formData.append("dir", "chat");
          const { data: res } = await this.$upload.post("/upload", formData);
          this.srcByOss = res.data.src;
          let img = new Image();
          img.src = this.srcByOss;
          document.getElementById("sendMsgInput").innerHTML = "";
          document.getElementById("sendMsgInput").append(img);
        }
      }
    },
  },
  watch : {
	  robotList2:{
		   handler(newVal,oldVal) {
				  if (newVal.length == 0) {
					  // this.showRobotList =false
					  this.defaultUser = "Current login account"
				  }
		        },
	  }
  },
  components: {
    login: () => import("@/components/diaLog/login.vue"),
    reg: () => import("@/components/diaLog/reg.vue"),
    AudioBox: () => import("@/components/diaLog/AudioBox.vue"),
  },
 
};
</script>


<style lang="scss" scoped>
.pore {
  position: relative;
}
.flexbox {
  display: flex;
  flex-direction: column; /*定义排列方向为竖排*/
  height: 100%; /*这里也要定义，重要*/
  width: 100%;
  background-color: #fff;
  float: right;
}

.qqFace {
    position: absolute;
    z-index: 1000;
    bottom: 60px;
    width: 372px;
    right: 42px;
    background-color: #42424B;
}
                    .caitiao_box {
                        position: absolute;
                        z-index: 1000;
                        left: 240px;
                        bottom: 61px;
                        background-color: #42424B;
                        padding: 10px;
                        dd {
                            width: 100%;
                            height: 30px;
                            vertical-align: middle;
                            text-align: center;
                            img {
                                display: block;
                                width: 156px;
                                margin: auto;
                                cursor: pointer;
                            }
                        }
                    }
.imgBox:hover {
  border: 1px solid #666;
  cursor: pointer;
}
.mobile_chat {
  background-color: #eeeeee;
  height: 100%;
}
.contextmenu__item {
  display: block;
  line-height: 34px;
  text-align: center;
  color: #333333;
}
.contextmenu__item:not(:last-child) {
  border-bottom: 1px solid rgba(0, 0, 0, 0.1);
}
.menu {
  position: absolute;
  background-color: #fff;
  width: 100px;
  /*height: 106px;*/
  font-size: 12px;
  color: #444040;
  border-radius: 4px;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  border-radius: 3px;
  border: 1px solid rgba(0, 0, 0, 0.15);
  box-shadow: 0 6px 12px rgba(0, 0, 0, 0.175);
  white-space: nowrap;
  z-index: 1000;
}
.contextmenu__item:hover {
  cursor: pointer;
  background: #66b1ff;
  border-color: #66b1ff;
  color: #fff;
}
// .sub_btn:hover {
//     background-color: #f46b0a;
//     padding: 3px 15px;
//     color: #fff;
// }
.sub_btn {
  // padding: 3px 15px;
  background-color: #4171f5;
  color: #fff;
  height: 100px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.header {
  display: flex;
  height: 40px;
  background-color: #36373c;
  color: #fff;
  align-items: center;
  padding-left: 30px;
  font-size: 18px;
}
.header span:first-child {
  margin-right: 30px;
}
.chat_main {
  width: 100%;
}

.chat_main_min {
  height: 660px;
}
.chatContent {
  box-sizing: border-box;
  padding: 20px;
  overflow: auto;
  .msg_detail {
    display: flex;
    flex-direction: row;
    padding-top: 10px;
    .msg_detail_main {
      padding: 0 10px;
      .nick_name_class {
        font-size: 12px;
        color: #999999;
        display: flex;
        align-items: center;
        flex-direction: row-reverse;
        span {
          display: inline-block;
          margin-left: 10px;
        }
      }
      .msg_box {
        .text_body {
          background-color: #5fb878;
          color: #fff;
          max-width: 70%;
          border-radius: 5px;
          padding: 10px;
          font-size: 14px;
          margin: 10px 0;
          word-wrap: break-word;
        }
        .image_body {
          max-width: 100px;
          max-height: 300px;
          min-width: 20px;
          background-color: #f7f6fc;
          margin: 10px;
          .el-image,
          img {
            max-width: 100px;
            max-height: 300px;
          }
        }
      }
    }
  }
  .my_msg_detail {
    display: flex;
    flex-flow: row-reverse;
    .msg_detail_main {
      padding: 0 10px;
      .nick_name_class {
        font-size: 12px;
        color: #999999;
        display: flex;
        align-items: center;
        flex-direction: row-reverse;
        span {
          display: inline-block;
          margin-left: 10px;
        }
      }
      .msg_box {
        display: flex;
        flex-direction: row-reverse;
        .text_body {
          background-color: #5fb878;
          color: #fff;
          max-width: 70%;
          border-radius: 5px;
          padding: 10px;
          font-size: 14px;
          margin: 10px 0;
          word-wrap: break-word;
        }
        .image_body {
          max-width: 100px;
          max-height: 300px;
          min-width: 20px;
          background-color: #f7f6fc;
          margin: 10px;
          .el-image,
          img {
            max-width: 100px;
            max-height: 300px;
          }
        }
        .read_box {
          margin-right: 10px;
        }
      }
    }
  }
}

#sendMsgInput {
  color: #fff;
  // background: rgba(0, 0, 0, 0.3);
  border-radius: 5px;
  background: rgb(65 113 245 / 52%);
}

.appqqFace {
  position: absolute;
  width: 201px !important;
  left: 0;
  bottom: 77px;
  background-color: #fff;
  height: 100px !important;
  overflow: auto;
}
.read_box {
  display: flex;
}
.wzdu_item {
  color: #ee3888 !important;
  display: flex;
  align-items: center;
}
.yidu_item {
  color: #35ceab !important;
  display: flex;
  align-items: center;
}
.mobile_icon {
  color: #fff;
  font-size: 20px;
}

.pore {
  position: relative;
}
::v-deep .el-carousel__container {
  height: 160px;
}
.f700 {
  font-weight: 700 !important;
}
.menu_list {
  position: absolute;
  right: 20px;
  top: 350px;
  width: 60px;
  // background-color: #35ceab;
  display: flex;
  flex-direction: column;
  justify-content: space-around;
  align-items: center;
  height: 50px;
  padding-left: 6px;
}
.select_class {
    background-color: #43444D;
    display: flex;
    align-items: center;
    cursor: pointer;
    color:#A1A1A6;
    width: 160px;
    padding:0 20px;
    justify-content: space-between;
    border-radius: 20px;
    position: relative;
    .robot_list {
      position: absolute;
      top: -125px;
      left: 0;
      background-color: #FFFEFF;
      display: flex;
      flex-direction: column;
      color: #000;
      height: 120px;
      overflow: auto;
      width: 160px;
      border-radius: 5px;
      span {
        padding: 5px;
      }
      .span_active {
        background-color: #4150FE;
        color: #fff;
      }
    }
}

.radio_class {
    display: flex;
    width: 240px;
    justify-content: space-between;
    div {
        background-color: #43444D;
        display: flex;
        align-items: center;
        width: 100px;
        border-radius: 30px;
        box-sizing: border-box;
        justify-content: space-between;
        padding: 0 10px;
        padding-right: 18px;
        font-weight: 600;
        cursor: pointer;
        .round {
            width: 25px;
            height: 25px;
            border-radius: 50%;
            background-color: #89898E;

            position: relative;
            i {
                width: 17px;
                height: 17px;
                border-radius: 50%;
                background-color: #D6D6D8;
                position: absolute;
                left: 50%;
                top: 50%;
                transform: translate(-50%,-50%);
            }
        }
    }
    span {
        color: #fff;
    }
    .radio_current {
        .round {
            background-color: #794A43;
                i{
            background-color: #D65638;
        }
        }
        span {
        color: #D65638;
    }
    }
}

.qun_btn {
      background-color: #D65638!important;
      display:flex;
      justify-content:center!important;
      align-items:center!important;
      
      
}

.shenglue {
	white-space:nowrap;
	overflow:hidden;
	text-overflow:ellipsis;
	max-width: 86px;
	
}
.tops_info {
  display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%;
    padding-right: 50px;
}

.what_list {
  display: flex;
    justify-content: space-around;
}
</style>