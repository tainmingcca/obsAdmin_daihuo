<template>
    <div class="">
        <el-dialog @close="closeReg" custom-class="noheader" :close-on-click-modal="false" :show-close="false" :visible.sync="dialogVisible">
            <img width="100%" height="480px" src="../../assets/img/login_bg.png" alt="" style="border-radius:15px;" />
            <div class="close_icon" @click="closeReg">
                <i class="el-icon-close"></i>
            </div>
            <section class="ab_form">
                <div class="title">Hi!</div>
                <div class="title">Create your account</div>
                <div class="tips2">Existing account? <span @click="$emit('openLoginCloseReg')" style="color:#4B77D2;cursor:pointer;">Log in immediately</span></div>
                <div class="input_cl">
                    <i class="el-icon-user"></i>
                    <input v-model="regForm.user_name" type="text" placeholder="Please enter the user name">
                </div>

                <div class="input_cl">
                    <i class="el-icon-edit"></i>
                    <input v-model="regForm.nick_name" type="text" placeholder="Personal nickname">
                </div>

                <div class="input_cl">
                    <i class="el-icon-lock"></i>
                    <input v-model="regForm.passwd" type="password" placeholder="enter your password">
                </div>

                <div class="input_cl">
                    <i class="el-icon-lock"></i>
                    <input v-model="regForm.repasswd" type="password" placeholder="Please enter the same password">
                </div>

                <div class="input_cl">
                    <img width="20px" src="../../assets/img/QQ.png" alt="">
                    <input v-model="regForm.user_qq" type="text" placeholder="Please enter the QQ number">
                </div>

                <div class="input_cl">
                    <img width="20px" src="../../assets/img/shouji.png" alt="">
                    <input v-model="regForm.mobile" type="text" placeholder="Please enter your mobile phone number">
                    <div @click="sendMsg" class="send_code_btn">{{codeText}}</div>
                </div>

                <div class="input_cl">
                    <img width="20px" src="../../assets/img/yanzhengma.png" alt="">
                    <input v-model="regForm.code" type="text" placeholder="Please enter the verification code">
                </div>

                
                <div class="login_btn" @click="regCount"> register </div>
                <div style="font-size:12px;">
                    Registration means you have read and agreed <span  @click="goLink('/yhxx')" class="pointer">《user agreement》</span> and <span @click="goLink('/yszc')" class="pointer">《privacy policy》</span>
                </div>
            </section>
        </el-dialog>
     <reg-red @click.native="showregres = true" @closeRegRed="showRegRedDialog = false" v-if="showRegRedDialog"></reg-red>
     <redResult :invitation_url="invlink" :money="money"  v-if="showregres" @close="showregres = false" />
    </div>
</template>

<script>
import { loginApi } from "@/apis/index.js";
import { regApi,sendCodeApi } from "@/apis/index.js";
import RegRed from '@/components/diaLog/regred.vue'
export default {
    data() {
        return {
            dialogVisible: true,
            regForm: {
                user_name: "",
                nick_name: "",
                passwd: "",
                code:"",
                repasswd: "",
                mobile: "",
                invitation:"",
                user_qq: "",
            },
            lock: false,
            codeLock:false,
            codeTime:60,
            codeText:'send',
            showRegRedDialog:false, // 注册成功展示红包
            showregres:false, // 注册红包
            money:"", // 红包金额
            invcode:"", // 邀请吗
            invlink:"" //邀请链接
        };
    },
    computed: {},
    methods: {
        goLink (path) {
            this.$emit("closeReg");
            if (this.$route.path == path) return
            this.$router.push(path)
        },
        closeReg() {
            this.$emit("closeReg");
        },
        async regCount() {
            let reqdata = this.regForm;
            this.lock = true;
            const { data: res } = await regApi(reqdata);
            this.lock = false;
            this.$toast(res.msg);
            if (res.code == 200) {
                this.$store.commit("addUserToken", res.data);
                this.invlink = res.invitation
                this.money = res.money
                this.showRegRedDialog  = true
                // this.showRegRedDialog  = true
            } 
        },
        async sendMsg () {
          let reqdata = {mobile:this.regForm.mobile}
          if (!this.regForm.mobile) return  this.$toast('Please enter your mobile phone number');
          const {data:res} = await sendCodeApi(reqdata)
          if (res.code == 200) {
            if (this.codeLock == true) return
           this.codeLock = true
           this.startCountDown()
          }else {
                return this.$toast(res.msg);
          }
  
        },
        startCountDown () {
          var timer = setInterval(()=>{
              this.codeTime --
              this.codeText = `Resend the message ${this.codeTime} seconds later`
              if (this.codeTime == 0) {
                clearInterval(timer)
                this.codeTime = 60
                this.codeLock = false
                this.codeText = 'send'
              }
          },1000)
        },
    },
    components: {
         RegRed,
         redResult: () => import("@/components/diaLog/redResult.vue"),
    },
    created() {},
    mounted() {},
};
</script>
<style lang="scss" scoped>
    .close_icon {
        position: absolute;
        right: -10px;
        top: -10px;
        width: 30px;
        height: 30px;
        border-radius: 100%;
        background-color: #757B78;
        border: 2px solid #fff;
        color: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        font-size: 20px;
        cursor: pointer;
    }
.ab_form {
    position: absolute;
    left: 30px;
    top: 30px;
    width: 250px;
    .input_cl {
        margin-top: 15px;
        border-bottom: 1px solid #d4d4d7;
        padding-bottom: 5px;
        position: relative;
        .send_code_btn {
            position: absolute;
            right: 0;
            top: -5px;
            background-color: #4B77D2;
            padding: 0 10px;
            color: #fff;
            height: 26px;
            display: flex;
            justify-content: center;
            align-items: center;
            border-radius: 15px;
            cursor: pointer;
        }
    }
    .tips {
        display: flex;
        justify-content: flex-end;
        color: #4B77D2;
        margin-top: 15px;
        cursor: pointer;
    }
    .title {
        font-size: 25px;
        font-weight: 700;
        color: #333;
    }
    .el-icon-user,.el-icon-lock,.icon_qq,.el-icon-edit {
        color: #4B77D2;
        font-weight: 700;
        font-size: 18px;
    }
    input {
        border: none;
        margin-left: 15px;
    }
}
.login_btn {
    background-color: #333951;
    color: #fff;
    height: 30px;
    border-radius: 20px;
    display: flex;
    justify-content: center;
    align-items: center;
    margin-top: 10px;
    cursor: pointer;
    margin-bottom: 5px;
}
.pointer {
    cursor: pointer;
}
.tips2 {
    margin-top: 5px;
}
</style>