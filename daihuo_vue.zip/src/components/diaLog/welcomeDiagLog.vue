<template>
  <div class="">
    <el-dialog
      :visible.sync="dialogVisible"
      @close="closeWelcome"
      :center="false"
      width="320px"
      custom-class="new_addmsg"
    >
 
    <template>
      <slot name="title">
        <div class="title_new" >Default greeting</div>
      </slot>
    </template>
      <div class="textarea_class">
        <textarea v-model="wel.welMsg" name="" id="" cols="30" rows="10"></textarea>
      </div>

      <span slot="footer" class="dialog-footer">
        <el-button @click="closeWelcome">cancel</el-button>
        <el-button type="primary" @click="setWel">confirm</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import { getWelcomeMsgApi, setWelcomeMsgApi } from "@/apis/index.js";
export default {
  data() {
    return {
      wel:{
        welMsg: "",
      },
      dialogVisible: true,
      welMsg: "",
      remark:""
    };
  },
  computed: {},
  methods: {
    closeWelcome() {
      this.$emit("closeWelcome");
    },
    setWel() {
      if (!this.wel.welMsg) return this.$toast('The content cannot be empty');
      let reqdata = {
        content: this.wel.welMsg,
      };
      setWelcomeMsgApi(reqdata).then(({ data: res }) => {
        if (res.code == 200) {
          this.$emit("closeWelcome");
        }
        this.$toast(res.msg);
      });
    },
  },
  components: {},
  created() {
    getWelcomeMsgApi().then(({ data: res }) => {
      this.wel.welMsg = res.data.content;
    });
  },
  mounted() {},
};
</script>
<style lang="scss" scoped>
.textarea_class {
  width: 100%;
  padding: 20px;
  input {
    width: 280px;
    outline: none;
    border: 1px solid #ccc;
    border-radius: 10px;
    padding: 5px;
    height: 40px;
    margin-bottom: 30px;

  }
  textarea {
    outline: none;
    border: 1px solid #ccc;
    padding: 5px;
    border-radius: 10px;
    resize: none;
    width: 280px;
  }
}
.title_new {
  font-weight: 700;
  margin-left: 20px;
  font-size: 18px;
}
</style>
