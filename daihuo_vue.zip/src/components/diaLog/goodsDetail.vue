<template>
    <div class="">
        <el-dialog width="60%" @close="closeGoodsDetail" custom-class="noheader" :close-on-click-modal="true" :show-close="false" :visible.sync="dialogVisible">
            <section class="goods_detail">
                <img width="300" height="445" :src="goodDetail.img" alt="">
                <div class="good_right">
                    <p>{{goodDetail.title}}</p>
                    <div class="price">
                        <span class="text">price</span>
                        <span class="nums">$ {{goodDetail.price}}</span>
                    </div>
					<div class="detail_item">
					    <!-- <span class="title">商品描述</span> -->
					    <span class="val" style="font-weight: 700;">  {{goodDetail.miaoshu}}</span>
					</div>
                    <div class="detail_item">
                        <span class="title">Commodity guarantee</span>
                        <span class="val2">
                           <span style="color:#FD4245;" v-for="(item,index) in goodDetail.desc" :key="index"> {{item}}</span>
                        </span>
                    </div>

                    <div class="detail_item">
                        <span class="title">commodity details</span>
                        <!-- <span class="val">  {{goodDetail.content}}</span> -->
						<span style="border: 1px solid #333;" class="val" v-html="goodDetail.content"></span>
                    </div>
          <!--          <div class="detail_item">
                        <span class="title"></span>
                        <img width="430" src="@/assets/img/goods2.png" alt="">
                    </div> -->
                </div>
            </section>
        </el-dialog>
    </div>
</template>

<script>
	import {getGoodsDetailApi} from '@/apis/index'
export default {
    data() {
        return {
            dialogVisible: true,
			goodDetail : new Object
        };
    },
	props: {
		goodsId :{
			required:true,
			type:Number
		}
	},
    computed: {},
    methods: {

        closeGoodsDetail() {
            this.$emit("closeGoodsDetail");
        },
		
		async getGoodsDetail () {
			let reqdata = {id : this.goodsId}
			const {data:res} = await getGoodsDetailApi(reqdata)
			if (res.code == 200) {
				res.data.goods.desc =  res.data.goods.desc.split('|')
				this.goodDetail = res.data.goods
			}else {
				this.$toast(res.msg)
			}
		}
    },
    components: {},
    created() {},
    mounted() {
		this.getGoodsDetail()
	},
};
</script>
<style lang="scss" scoped>


.goods_detail {
    padding: 20px;
    display: flex;
	max-height: 600px;
	overflow: auto;
    .good_right {
        margin-left: 20px;
        p {
            font-size: 24px;
            color: #333;
        }
        .price {
            background-color: #FFF2E8;
            color: #FF4646;
            width: 480px;
            height: 60px;
            display: flex;
            align-items: center;
            padding-left: 20px;
            margin: 20px 0;
            .nums {
                font-size: 38px;
                font-weight: 600;
                display: flex;
                margin-left: 10px;
            }
            .text {
                color: #B7B7B7;
            }
        }
    }
}
.detail_item {
    margin-bottom: 10px;
    display: flex;
    .title {
        color: #B7B7B7;
        width: 60px;
        text-align: right;
        display: inline-block;
        margin-right: 10px;
        flex-shrink: 0;
    }
    .val {
        color: #333;
		
		img {
			max-width: 300px;
		}
    }
}
</style>