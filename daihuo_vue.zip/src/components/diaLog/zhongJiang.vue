<template>
<el-dialog title="添加"
           :visible.sync="dialogVisible"
           width="50%">

  <span slot="footer"
        class="dialog-footer">
    <el-button @click="dialogVisible = false">取 消</el-button>
    <el-button type="primary"
               @click="dialogVisible = false">确 定</el-button>
  </span>
</el-dialog>
</template>

<script>
export default {
  data() {
    return {
      
    };
  },
  computed: {},
  methods: {},
  components: {},
  created() {},
  mounted() {}
};
</script>
<style lang="scss" scoped>
</style>