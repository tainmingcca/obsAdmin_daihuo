<template>
  <div class="">
    <el-dialog
      title="voice playing"
      center=""
      :visible.sync="dialogVisible"
      @close="closeAudio"
      width="600px"
      top="150px"
    >
      <section class="audio_section">
        <div class="blue" @click="openaudio(1)">Chen Yi</div>
        <div class="blue" @click="openaudio(2)">Li Qinyao</div>
        <div class="blue" @click="openaudio(3)">Zhao Yusheng</div>
        <div class="origin" @click="openaudio(4)">Zhou Peng</div>
        <div class="origin" @click="openaudio(5)">Wang Xueyi</div>
        <div class="origin" @click="openaudio(6)">Corporate information</div>
        <div class="red" @click="openaudio(7)">Cue to drop wheat</div>
        <div class="red" @click="openaudio(8)">Conditions of opening account</div>
        <span></span>
      </section>
    </el-dialog>
  </div>
</template>

<script>
import { getTeacherListApi, zanTeacherApi, sendMusicApi } from "@/apis/index";
// let audio = document.createElement("audio"); // 创建audio标签

export default {
  data() {
    return {
      dialogVisible: true,
      palyAudio: true,
    };
  },
  computed: {},
  methods: {
    closeAudio() {
      this.$emit("closeAudio");
    },
    async openaudio(num) {
      if (this.palyAudio == false) return;
      this.palyAudio = false;
      let reqdata = { type: num };
      const { data: res } = await sendMusicApi(reqdata);
      if (res.code == 200) {
        setTimeout(() => {
          this.palyAudio = true;
        }, 5000);
      } else {
        this.$toast(res.msg);
        this.palyAudio = true;
      }
    },
  },
  components: {},
  async created() {},
  mounted() {},
};
</script>
<style lang="scss" scoped>
::v-deep.el-dialog__header {
  padding: 15px 0;
}
.audio_section {
  margin: 30px 0;
  display: flex;
  flex-wrap: wrap;
  div {
    width: 30%;
    height: 60px;
    display: flex;
    justify-content: center;
    align-items: center;
    margin: 10px;
    cursor: pointer;
  }
}
.blue {
  color: #fff;
  background-color: #409eff;
}
.origin {
  color: #fff;
  background-color: #e6a23c;
}
.red {
  color: #fff;
  background-color: #f56c6c;
}
</style>