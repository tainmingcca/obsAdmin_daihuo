<template>
  <div>
    <el-dialog
      title="隐私声明"
      center
      :visible.sync="dialogVisible"
      @close="closeChanPin"
      width="800px"
      top="80px"
      style="height: 600px;"
    >
      <!-- <iframe class="productIdrem" scrolling="auto" src="@/views/ynsi.html" frameborder="0"></iframe> -->
      <!-- <p></p> -->
      <div class="WordSection1" style="layout-grid: 15.6pt;padding:20px;height: 600px;overflow: auto; ">
        <p
          style="
            margin-top: 30pt;
            margin-right: 0cm;
            margin-bottom: 0cm;
            margin-left: 0cm;
            mso-pagination: widow-orphan;
            background: white;
          "
        >
          <b
            ><span
              style="
                font-size: 13.5pt;
                font-family: 'PingFang SC';
                mso-fareast-font-family: 'PingFang SC';
                mso-bidi-font-family: 'PingFang SC';
                color: #3a3232;
                background: white;
              "
              >前言</span
            ></b
          ><b
            ><span
              lang="EN-US"
              style="
                font-size: 13.5pt;
                font-family: 'PingFang SC';
                mso-fareast-font-family: 'PingFang SC';
                mso-bidi-font-family: 'PingFang SC';
                color: #3a3232;
              "
              ><o:p></o:p></span
          ></b>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >【阿斯顿】一向庄严承诺保护用户的隐私。您在使用按揭首付服务时，我们可能会收集和使用您的相关信息。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <strong
            ><span
              style="
                font-size: 10pt;
                font-family: '微软雅黑', sans-serif;
                mso-bidi-font-family: 微软雅黑;
                color: #3a3232;
                background: white;
              "
              >本《隐私政策》适用于我们提供的一切按揭首付服务。请注意我们不时地会检查我们的政策，因此有关的措施会随之变化。我们恳请您定期光顾本页面，以确保对我们《隐私政策》最新版本始终保持了解。</span
            ></strong
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >在阅读完本政策之后，如您对本《隐私政策》或与本《隐私政策》相关的事宜有任何问题，请与<span
              lang="EN-US"
              >kefu@hu1x1n.com</span
            >联系。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >您使用或继续使用按揭首付服务，都表示您同意我们按照本《隐私政策》收集、使用、储存和分享您的信息。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <h1
          style="margin: 0cm; mso-pagination: widow-orphan; background: white"
        >
          <span
            style="
              font-size: 12.5pt;
              font-family: 'PingFang SC';
              mso-fareast-font-family: 'PingFang SC';
              mso-bidi-font-family: 'PingFang SC';
              color: #3a3232;
              background: white;
            "
            >一、我们可能收集的信息</span
          ><span
            lang="EN-US"
            style="
              font-size: 12.5pt;
              font-family: 'PingFang SC';
              mso-fareast-font-family: 'PingFang SC';
              mso-bidi-font-family: 'PingFang SC';
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </h1>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（一）与个人身份无关的信息：</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >当您使用按揭首付服务时，我们可能收集和汇总诸如用户的来源途径、访问顺序等信息，例如记录使用按揭首付服务的每个用户的来源途径、浏览器软件等。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（二）有关个人身份的信息：</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >当您使用按揭首付服务时，我们可能收集和汇总或要求您提供有关个人电话号码、网络身份标识信息（<span
              lang="EN-US"
              >IP</span
            >地址）；操作日志；设备信息（包括设备型号、操作系统类型）；软件列表唯一设备识别码（如<span
              lang="EN-US"
              >IMEI/android ID/IDFA/OPENUDID/GUID</span
            >基本情况的信息）。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >我们收集您的信息主要是为了您和其他用户能够更容易和更满意地使用按揭首付服务。按揭首付的目标是向所有的互联网用户提供安全、有趣及有教益的上网经历。而这些信息有助于我们实现这一目标。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >请注意，如您在按揭首付服务中其他用户可见的公开区域内上传或发布的信息中、您对其他人上传或发布的信息作出的回应中公开您的个人信息，该等信息可能会被他人收集并加以使用。当您发现按揭首付的用户不正当地收集或使用您或他人的信息时，请联系<span
              lang="EN-US"
              >kefu@hu1x1n.com.</span
            ></span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <h1
          style="margin: 0cm; mso-pagination: widow-orphan; background: white"
        >
          <span
            style="
              font-size: 12.5pt;
              font-family: 'PingFang SC';
              mso-fareast-font-family: 'PingFang SC';
              mso-bidi-font-family: 'PingFang SC';
              color: #3a3232;
              background: white;
            "
            >二、我们如何收集和使用信息</span
          ><span
            lang="EN-US"
            style="
              font-size: 12.5pt;
              font-family: 'PingFang SC';
              mso-fareast-font-family: 'PingFang SC';
              mso-bidi-font-family: 'PingFang SC';
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </h1>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（一）我们将通过以下途径收集和获得您的信息：</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >1</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >、您提供的信息。 例如：</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（<span lang="EN-US">1</span
            >）您在注册按揭首付服务的帐号或使用按揭首付服务时，向我们提供的信息；</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（<span lang="EN-US">2</span
            >）您通过按揭首付服务向其他方提供的共享信息，以及您使用按揭首付服务时所储存的信息。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >2</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >、其他方分享的您的信息。亦即其他方使用按揭首付服务时所提供有关您的共享信息。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >3</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >、我们获取的您的信息。您在使用按揭首付服务时，我们收集、汇总、记录的信息，例如日志信息、位置信息、设备信息等。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（二）<span lang="EN-US">COOKIES</span>、日志档案和<span
              lang="EN-US"
              >WEB BEACON</span
            ></span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >我们或我们的第三方合作伙伴可能通过<span lang="EN-US">COOKIES</span
            >和<span lang="EN-US">WEB BEACON</span
            >获取和使用您的信息，并将该等信息储存为日志信息。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >通过使用<span lang="EN-US">COOKIES</span>和<span lang="EN-US"
              >WEB BEACON</span
            >，我们向用户提供简单易行并富个性化的网络体验。一个<span
              lang="EN-US"
              >COOKIES</span
            >是少量的数据，它们从一个网络服务器送至您的浏览器并存在计算机硬盘上。我们使用<span
              lang="EN-US"
              >COOKIES</span
            >和<span lang="EN-US">WEB BEACON</span
            >是为了让其用户可以受益。比如，为使得按揭首付虚拟社区的登录过程更快捷，您可以选择把用户名存在一个<span
              lang="EN-US"
              >COOKIES</span
            >中。这样下次当您要登录按揭首付的服务时能更加方便快捷。<span
              lang="EN-US"
              >COOKIES</span
            >和<span lang="EN-US">WEB BEACON</span
            >能帮助我们确定您连接的页面和内容，您在按揭首付特定服务上花费的时间和您所选择的按揭首付服务。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >COOKIES</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >和<span lang="EN-US">WEB BEACON</span
            >使得我们能更好、更快地为您服务，并且使您在按揭首付服务上的经历更富个性化。然而，您应该能够控制<span
              lang="EN-US"
              >COOKIES</span
            >和<span lang="EN-US">WEB BEACON</span
            >是否以及怎样被你的浏览器接受。请查阅您的浏览器附带的文件以获得更多这方面的信息。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >我们和第三方合作伙伴可能通过<span lang="EN-US">COOKIES</span
            >和<span lang="EN-US">WEB BEACON</span
            >收集和使用您的信息，并将该等信息储存。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >我们使用自己的<span lang="EN-US">COOKIES</span>和<span lang="EN-US"
              >WEB BEACON</span
            >，用于以下用途：</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（<span lang="EN-US">1</span>）记住您的身份。例如：<span
              lang="EN-US"
              >COOKIES</span
            >和<span lang="EN-US">WEB BEACON</span
            >有助于我们辨认您作为我们的注册用户的身份，或保存您向我们提供有关您的喜好或其他信息；</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（<span lang="EN-US">2</span
            >）分析您使用我们服务的情况。我们可利用<span lang="EN-US"
              >COOKIES</span
            >和<span lang="EN-US">WEB BEACON</span
            >来了解您使用按揭首付服务进行什么活动、或哪些服务或服务最受欢迎；</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（<span lang="EN-US">3</span>）广告优化。<span lang="EN-US"
              >COOKIES</span
            >和<span lang="EN-US">WEB BEACON</span
            >有助于我们根据您的信息，向您提供与您相关的广告而非进行普遍的广告投放。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >我们为上述目的使用<span lang="EN-US">COOKIES</span>和<span
              lang="EN-US"
              >WEB BEACON</span
            >的同时，可能将通过<span lang="EN-US">COOKIES</span>和<span
              lang="EN-US"
              >WEB BEACON</span
            >收集的非个人身份信息汇总提供给广告商和其他伙伴，用于分析您和其他用户如何使用按揭首付服务并用于广告服务。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >按揭首付服务上可能会有广告商和其他合作方放置的<span lang="EN-US"
              >COOKIES</span
            >和<span lang="EN-US">WEB BEACON</span>。这些<span lang="EN-US"
              >COOKIES</span
            >和<span lang="EN-US">WEB BEACON</span
            >可能会收集与您相关的非个人身份信息，以用于分析用户如何使用该等服务、向您发送您可能感兴趣的广告，或用于评估广告服务的效果。这些第三方<span
              lang="EN-US"
              >COOKIES</span
            >和<span lang="EN-US">WEB BEACON</span
            >收集和使用该等信息不受本《隐私政策》约束，而是受到其自身的个人信息保护声明约束，我们不对第三方的<span
              lang="EN-US"
              >COOKIES</span
            >和<span lang="EN-US">WEB BEACON</span>承担责任。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >您可以通过浏览器或用户选择机制拒绝或管理<span lang="EN-US"
              >COOKIES</span
            >和<span lang="EN-US">WEB BEACON</span>。但请您注意，如果您停用<span
              lang="EN-US"
              >COOKIES</span
            >和<span lang="EN-US">WEB BEACON</span
            >，我们有可能无法为您提供最佳的服务体验，某些服务也可能无法正常使用。同时，您仍然将收到广告，只是这些广告与您的相关性会降低。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（三）我们会出于以下目的，收集和使用您的信息：</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >1</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >、帮助您完成注册</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >为便于我们为您提供服务，您需要提供基本注册信息，例如手机号码、电子邮箱地址等，并创建您的用户名和密码。在部分单项服务中，如果您仅需使用浏览等基本服务，您不需要注册成为按揭首付用户及提供上述信息。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >2</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >、向您提供商品或服务</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >我们所收集和使用的信息是为您提供按揭首付服务的必要条件，如缺少相关信息，我们将无法为您提供按揭首付服务的核心内容，例如：</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（<span lang="EN-US">1</span
            >）在部分服务项目中，为便于向您交付商品或服务，您需提供收货人个人身份信息、姓名、收货地址、邮政编码、收货人、联系电话、支付状态等信息。如果您拒绝提供此类信息，我们将无法完成相关交付服务。如您通过按揭首付服务为其他人订购商品或服务，您需要提供该实际订购人的前述信息。<strong
              >向我们提供该实际订购人的前述信息之前，您需确保您已经取得其授权同意。</strong
            ></span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（<span lang="EN-US">2</span
            >）为展示您账户的订单信息，我们会收集您在使用按揭首付服务过程中产生的订单信息用于向您展示及便于您对订单进行管理；</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（<span lang="EN-US">3</span
            >）当您与我们联系时，我们可能会保存您的通信<span lang="EN-US"
              >/</span
            >通话记录和内容或您留下的联系方式等信息，以便与您联系或帮助您解决问题，或记录相关问题的处理方案及结果。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（<span lang="EN-US">4</span
            >）为确认交易状态及为您提供售后与争议解决服务，我们会通过您基于交易所选择的交易对象、支付机构、物流公司等收集与交易进度相关的您的交易、支付、物流信息，或将您的交易信息共享给上述服务提供者。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >3</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >、向您推送消息</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（<span lang="EN-US">1</span
            >）为您展示和推送商品或服务。我们可能使用您的信息，您的浏览及搜索记录、设备信息、位置信息、订单信息，提取您的浏览、搜索偏好、行为习惯、位置信息等特征，并基于特征标签通过电子邮件、短信或其他方式向您发送营销信息，提供或推广我们或第三方的商品和服务。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（<span lang="EN-US">2</span
            >）向您发出通知。我们可能在必需时（例如当我们由于系统维护而暂停某一单项服务、变更、终止提供某一单项服务时）向您发出与服务有关的通知。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >如您不希望继续接收我们推送的消息，您可要求我们停止推送，例如：根据短信退订指引要求我们停止发送推广短信，或在移动端设备中进行设置，不再接收我们推送的消息等；但我们依法律规定或单项服务的服务协议约定发送消息的情形除外。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >4</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >、为您提供安全保障</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >为确保您身份真实性、向您提供更好的安全保障，您可以向我们提供身份证明、面部特征等生物识别信息等个人敏感信息以完成实名认证。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >除身份验证外，我们可能将您的信息用于客户服务、安全防范、诈骗监测、存档和备份等用途，确保我们向您提供的服务的安全性；我们可能使用或整合我们所收集的您的信息，以及我们的合作伙伴取得您授权或依据法律共享的信息，来综合判断您账户及交易风险、进行身份验证、检测及防范安全事件，并依法采取必要的记录、审计、分析、处置措施。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >5</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >、改进我们的服务</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >我们可能将通过某一项按揭首付服务所收集的信息，用于我们的其他服务。例如，在您使用某一项按揭首付服务时所收集的您的信息，可能在另一项按揭首付服务中用于向您提供特定内容或向您展示与您相关的、而非普遍推送的信息；我们可能让您参与有关按揭首付服务的调查，帮助我们改善现有服务或设计新服务；同时，我们可能将您的信息用于软件更新。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >您了解并同意，在收集您的信息后，我们将通过技术手段对数据进行去标识化处理，去标识化处理的信息将无法识别您的身份，在此情况下我们有权使用已经去标识化的信息，对用户数据库进行分析并予以商业化的利用。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >如果我们将您的信息用于本《隐私政策》中未载明的其他用途，会事先征求您同意。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >6</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >、征得授权同意的例外</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >根据相关法律法规规定，以下情形中收集您的信息无需征得您的授权同意：</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（<span lang="EN-US">1</span>）与国家安全、国防安全有关的；</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（<span lang="EN-US">2</span
            >）与公共安全、公共卫生、重大公共利益有关的；</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（<span lang="EN-US">3</span
            >）与犯罪侦查、起诉、审判和判决执行等有关的；</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（<span lang="EN-US">4</span
            >）出于维护信息主体或其他个人的生命、财产等重大合法权益但又很难得到您本人同意的；</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（<span lang="EN-US">5</span
            >）所收集的信息是您自行向社会公众公开的；</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（<span lang="EN-US">6</span
            >）从合法公开披露的信息中收集信息的，如合法的新闻报道、政府信息公开等渠道；</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（<span lang="EN-US">7</span>）根据您的要求签订合同所必需的；</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（<span lang="EN-US">8</span
            >）用于维护按揭首付服务的安全稳定运行所必需的，例如发现、处置产品或服务的故障；</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（<span lang="EN-US">9</span>）为合法的新闻报道所必需的；</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（<span lang="EN-US">10</span
            >）学术研究机构基于公共利益开展统计或学术研究所必要，且对外提供学术研究或描述的结果时，对结果中所包含的信息进行去标识化处理的；</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（<span lang="EN-US">11</span>）法律法规规定的其他情形。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <h1
          style="margin: 0cm; mso-pagination: widow-orphan; background: white"
        >
          <span
            style="
              font-size: 12.5pt;
              font-family: 'PingFang SC';
              mso-fareast-font-family: 'PingFang SC';
              mso-bidi-font-family: 'PingFang SC';
              color: #3a3232;
              background: white;
            "
            >三、我们可能分享、转让或披露的信息</span
          ><span
            lang="EN-US"
            style="
              font-size: 12.5pt;
              font-family: 'PingFang SC';
              mso-fareast-font-family: 'PingFang SC';
              mso-bidi-font-family: 'PingFang SC';
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </h1>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（一）分享</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >除以下情形外，未经您同意，我们不会与按揭首付之外的任何第三方分享您的信息：</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >1</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >、向您提供我们的服务以及维护和改善我们的服务。我们可能向合作伙伴及其他第三方分享您的信息，以实现您需要的核心功能或提供您需要的服务，并帮助我们为您提供更有针对性的服务；</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >2</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >、以下是我们使用的第三方<span lang="EN-US"> SDK </span
            >的情况，我们将不时地更新此清单，以更清晰地展示与第三方合作或使用第三方功能以完善产品和服务体验的情况。请您理解，即便我们尽可能地及时更新此清单，但在一定情况下仍可能会滞后于实际使用的情况。同时，为了对我们商业信息和技术手段保密，部分用于平台风控或特殊合作的<span
              lang="EN-US"
            >
              SDK </span
            >可能不在此清单中，但该等<span lang="EN-US"> SDK </span
            >如需获取你的重要隐私信息或设备权限时，我们会通过合理方式取得您的授权同意。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >SDK</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >名称：<span lang="EN-US">Bumptech</span>、<span lang="EN-US"
              >Glide</span
            ></span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >提供商及隐私政策：<span lang="EN-US">Sam Judd / </span>无</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >功能用途：图片加载功能</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >是否收集个人信息：否</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >个人信息类型：无</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >SDK</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >名称：小米推送<span lang="EN-US">sdk</span></span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >提供商及隐私政策：小米<span lang="EN-US">
              https://privacy.mi.com/all/zh_CN/</span
            ></span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >功能用途：读取设备型号；操作系统型号；个人常用设备信息；获取定位；获取设备应用安装列表</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >是否收集个人信息：是</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >个人信息类型：读取设备型号；操作系统型号；个人常用设备信息；获取定位；获取设备应用安装列表</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >SDK</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >名称：华为消息服务</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >提供商及隐私政策：华为<span lang="EN-US"
              >https://www.huawei.com/cn/privacy-policy/</span
            ></span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >功能用途：华为手机系统推送功能</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >是否收集个人信息：是</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >个人信息类型：读取设备型号；操作系统型号；个人常用设备信息；获取定位</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >SDK</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >名称：魅族推送<span lang="EN-US">sdk</span></span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >提供商及隐私政策：魅族科技<span lang="EN-US">
              https://i.flyme.cn/privacy</span
            ></span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >功能用途：魅族手机系统推送功能</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >是否收集个人信息：是</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >个人信息类型：读取设备型号；操作系统型号；个人常用设备信息；获取定位</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >SDK</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >名称：<span lang="EN-US">oppo</span>推送<span lang="EN-US"
              >sdk</span
            ></span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >提供商及隐私政策：欢太科技</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >https://www.oppo.com/cn/service/help/640?id=640&amp;name=</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >服务政策<span lang="EN-US">&amp;hdscreen=1</span></span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >功能用途：<span lang="EN-US">oppo</span>手机系统推送功能</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >是否收集个人信息：是</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >个人信息类型：读取设备型号；操作系统型号；个人常用设备信息；获取定位</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >SDK</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >名称：<span lang="EN-US">jpush </span>推送<span lang="EN-US">
              sdk</span
            ></span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >提供商及隐私政策：和讯华谷<span lang="EN-US">
              https://www.jiguang.cn/license/privacy</span
            ></span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >功能用途：普通手机系统推送功能</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >是否收集个人信息：是</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >个人信息类型：读取设备型号；操作系统型号；个人常用设备信息；获取定位</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >SDK</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >名称：新浪微博开放平台</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >提供商及隐私政策：新浪微博<span lang="EN-US">
              https://www.sina.com.cn/privacy/</span
            ></span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >功能用途：第三方登录<span lang="EN-US">-</span
            >微信、分享到微博功能</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >是否收集个人信息：是</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >个人信息类型：读取设备标识信息</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >SDK</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >名称：<span lang="EN-US">QQ</span>互联<span lang="EN-US">sdk</span
            >、微信分享<span lang="EN-US">sdk</span></span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >提供商及隐私政策：腾讯<span lang="EN-US">
              https://privacy.tencent.com</span
            ></span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >功能用途：第三方登录<span lang="EN-US">-qq</span>、分享到<span
              lang="EN-US"
              >qq</span
            >功能；第三方登录<span lang="EN-US">-</span
            >微信、分享到微信、分享到朋友圈、微信支付功能</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >是否收集个人信息：是</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >个人信息类型：读取设备标识信息</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >SDK</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >名称：友盟<span lang="EN-US">sdk</span></span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >提供商及隐私政策：友盟同欣<span lang="EN-US">
              https://www.umeng.com/policy</span
            ></span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >功能用途：应用程序故障收集和分析功能、用户访问数据统计功能</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >是否收集个人信息：是</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >个人信息类型：<span lang="EN-US">ACCESS_NETWORK_STATE</span
            >；系统发送统计数据权限；</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >网络权限；读取设备型号；操作系统型号；个人常用设备信息；获取定位</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >SDK</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >名称：<span lang="EN-US">phonenumber-auth sdk</span></span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >提供商及隐私政策：阿里云<span lang="EN-US">
              http://terms.aliyun.com/legal-agreement/terms/suit_bu1_ali_cloud/suit_bu1_ali_cloud201902141711_54837.html?spm=5176.13910061.J_9220772140.81.19e2336fMRVIao</span
            ></span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >功能用途：运营商一键登录功能申请接入</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >是否收集个人信息：是</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >个人信息类型：网络权限；<span lang="EN-US">ACCESS_WIFI_STATE</span
            >；<span lang="EN-US">ACCESS_NETWO RK_STATE</span>；<span
              lang="EN-US"
              >CHANGE_NETWORK_STATE</span
            ></span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >SDK</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >名称：<span lang="EN-US">Butterknife sdk</span></span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >提供商及隐私政策：<span lang="EN-US">JakeWharton</span></span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >功能用途：提高代码开发效率</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >是否收集个人信息：否</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >个人信息类型：无</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >SDK</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >名称：<span lang="EN-US">rxjava sdk</span></span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >提供商及隐私政策：<span lang="EN-US">ReactiveX</span></span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >功能用途：提高代码开发效率</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >是否收集个人信息：否</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >个人信息类型：无</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >SDK</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >名称：<span lang="EN-US">ksyplayer</span></span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >提供商及隐私政策：金山云<span lang="EN-US">
              https://docs.ksyun.com/documents/5230</span
            ></span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >功能用途：播放音视频功能</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >是否收集个人信息：是</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >个人信息类型：访问网络；<span lang="EN-US">WAKE_LOCK</span>；<span
              lang="EN-US"
              >ACCESS_NETWORK_STAT</span
            ></span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >EACCESS_NETWORK_STATE</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >；<span lang="EN-US">ACCESS_WIFI_STATE</span
            >；读取个人常用设备信息</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >SDK</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >名称：<span lang="EN-US">alipay sdk</span></span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >提供商及隐私政策：蚂蚁金服<span lang="EN-US">
              https://render.alipay.com/p/c/k2h4n8ug</span
            ></span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >功能用途：支付宝支付功能</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >是否收集个人信息：是</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >个人信息类型：访问网络；</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >SDK</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >名称：<span lang="EN-US">sqlbrite sdk</span></span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >提供商及隐私政策：<span lang="EN-US">squareup</span></span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >功能用途：访问数据库功能</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >是否收集个人信息：否</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >个人信息类型：无</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >3</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >、实现本《隐私政策》第二条“我们如何收集和使用信息”部分所述目的；</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >4</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >、履行我们在本《隐私政策》或我们与您达成的其他协议中的义务和行使我们的权利；</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >5</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >、向委托我们进行推广的合作伙伴等第三方共享，但我们仅会向这些委托方提供推广的覆盖面和有效性的信息，而不会提供可以识别您身份的信息，例如姓名电话号码或电子邮箱；或者我们将这些信息进行汇总，以便它不会识别您个人。比如我们可以告知该委托方有多少人看了他们的推广信息或在看到这些信息后购买了委托方的商品，或者向他们提供不能识别个人身份的统计信息，帮助他们了解其受众或顾客。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >6</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >、在法律法规允许的范围内，为了遵守法律、维护我们及我们的关联方或合作伙伴、您或其他按揭首付用户或社会公众利益、财产或安全免遭损害，比如为防止欺诈等违法活动和减少信用风险，我们可能与其他公司和组织交换信息。不过<span
              lang="EN-US"
              >,</span
            >这并不包括违反本《隐私政策》中所作的承诺而为获利目的出售、出租、共享或以其它方式披露的信息。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >7</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >、应您合法需求，协助处理您与他人的纠纷或争议；</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >8</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >、应您的监护人合法要求而提供您的信息；</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >9</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >、根据与您签署的单项服务协议（包括在线签署的电子协议以及相应的平台规则）或其他的法律文件约定所提供；</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >10</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >、基于学术研究而提供；</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >11</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >、基于符合法律法规的社会公共利益而提供。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >我们仅会出于合法、正当、必要、特定、明确的目的共享您的信息。对我们与之共享信息的公司、组织和个人，我们会与其签署严格的保密协定，要求他们按照我们的说明、本《隐私政策》以及其他任何相关的保密和安全措施来处理信息。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（二）转让</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >1</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >、<strong>随着我们业务的持续发展，我们有可能进行合并、收购、资产转让或类似的交易，而您的信息有可能作为此类交易的一部分而被转移。</strong>我们会要求新的持有您信息的公司、组织继续受本《隐私政策》的约束，否则<span
              lang="EN-US"
              >,</span
            >我们将要求该公司、组织重新向您征求授权同意。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >2</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >、在获得您的明确同意后，我们会向其他方转让您的信息。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（三）披露</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >我们仅会在以下情况下，且采取符合业界标准的安全防护措施的前提下，才会披露您的信息：</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >1</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >、根据您的需求，在您明确同意的披露方式下披露您所指定的信息；</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >2</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >、根据法律、法规的要求、强制性的行政执法或司法要求所必须提供您信息的情况下，我们可能会依据所要求的信息类型和披露方式披露您的信息。在符合法律法规的前提下，当我们收到上述披露信息的请求时，我们会要求接收方必须出具与之相应的法律文件，如传票或调查函。我们坚信，对于要求我们提供的信息，应该在法律允许的范围内尽可能保持透明。我们对所有的请求都进行了慎重的审查，以确保其具备合法依据，且仅限于执法部门因特定调查目的且有合法权利获取的数据。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <h1
          style="margin: 0cm; mso-pagination: widow-orphan; background: white"
        >
          <span
            style="
              font-size: 12.5pt;
              font-family: 'PingFang SC';
              mso-fareast-font-family: 'PingFang SC';
              mso-bidi-font-family: 'PingFang SC';
              color: #3a3232;
              background: white;
            "
            >四、我们如何保留、储存和保护信息</span
          ><span
            lang="EN-US"
            style="
              font-size: 12.5pt;
              font-family: 'PingFang SC';
              mso-fareast-font-family: 'PingFang SC';
              mso-bidi-font-family: 'PingFang SC';
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </h1>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >我们仅在本《隐私政策》所述目的所必需期间和法律法规要求的时限内保留您的信息</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >我们在中华人民共和国境内运营中收集和产生的信息，存储在中国境内，以下情形除外：</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >1</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >、法律法规有明确规定；</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >2</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >、获得您的授权同意；</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >3</span
          ><span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >、您使用的产品、服务涉及跨境，按揭首付需要向境外提供您的个人信息的。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >针对以上情形，我们会确保依据本政策及国家法律法规要求对您的个人信息提供足够的保护。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >我们将采取以下手段保护您的信息：</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（一）数据安全技术措施</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >我们会采用符合业界标准的安全防护措施，包括建立合理的制度规范、安全技术来防止您的信息遭到未经授权的访问使用、修改<span
              lang="EN-US"
              >,</span
            >避免数据的损坏或丢失。网络服务采取了多种加密技术，例如在某些服务中，我们将利用加密技术（例如<span
              lang="EN-US"
              >SSL</span
            >）来保护您的信息，采取加密技术对您的信息进行加密保存，并通过隔离技术进行隔离。
            在信息使用时，例如信息展示、信息关联计算，我们会采用多种数据脱敏技术增强信息在使用中安全性。采用严格的数据访问权限控制和多重身份认证技术保护信息，避免数据被违规使用。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（二）我们为保护信息采取的其他安全措施</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >我们通过建立数据分类分级制度、数据安全管理规范、数据安全开发规范来管理规范信息的存储和使用。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >我们通过信息接触者保密协议、监控和审计机制来对数据进行全面安全控制。加强安全意识。我们还会举办安全和隐私保护培训课程，加强员工对于保护信息重要性的认识。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（三）我们仅允许有必要知晓这些信息的按揭首付员工、合作伙伴访问您的信息，并为此设置了严格的访问权限控制和监控机制。我们同时要求可能接触到您的信息的所有人员履行相应的保密义务。如果未能履行这些义务，可能会被追究法律责任或被中止与按揭首付的合作关系。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（四）我们会采取一切合理可行的措施，确保未收集无关的信息。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（五）互联网并非绝对安全的环境，而且电子邮件、即时通讯、社交软件或其他服务软件等与其他用户的交流方式无法确定是否完全加密，我们建议您使用此类工具时请使用复杂密码，并注意保护您的信息安全。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（六）互联网环境并非百分之百安全，我们将尽力确保或担保您发送给我们的任何信息的安全性。如果我们的物理、技术、或管理防护设施遭到破坏，导致信息被非授权访问、公开披露、篡改、或毁坏，导致您的合法权益受损，我们将承担相应的法律责任。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（七）安全事件处置</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >在通过按揭首付服务与第三方进行沟通或购买商品及服务时，您不可避免的要向交易对方或潜在的交易对方披露自己的信息，如联络方式或者邮政地址等。请您妥善保护自己的信息，仅在必要的情形下向他人提供。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >为应对信息泄露、损毁和丢失等可能出现的风险，我们制定了多项制度，明确安全事件、安全漏洞的分类分级标准及相应的处理流程。我们也为安全事件建立了专门的应急响应团队，按照安全事件处置规范要求，针对不同安全事件启动安全预案，进行止损、分析、定位、制定补救措施、联合相关部门进行溯源和打击。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >在不幸发生信息安全事件后，我们将按照法律法规的要求，及时向您告知：安全事件的基本情况和可能的影响、我们已采取或将要采取的处置措施、您可自主防范和降低风险的建议、对您的补救措施等。我们同时将及时将事件相关情况以邮件、信函、电话、推送通知等方式告知您，难以逐一告知信息主体时，我们会采取合理、有效的方式发布公告。同时，我们还将按照监管部门要求，主动上报信息安全事件的处置情况。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >请您理解，由于技术的限制以及风险防范的局限，即便我们已经尽量加强安全措施，也无法始终保证信息百分之百的安全。您需要了解，您接入按揭首付服务所用的系统和通讯网络，有可能因我们可控范围外的情况而发生问题。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <h1
          style="margin: 0cm; mso-pagination: widow-orphan; background: white"
        >
          <span
            style="
              font-size: 12.5pt;
              font-family: 'PingFang SC';
              mso-fareast-font-family: 'PingFang SC';
              mso-bidi-font-family: 'PingFang SC';
              color: #3a3232;
              background: white;
            "
            >五、如何管理您的信息</span
          ><span
            lang="EN-US"
            style="
              font-size: 12.5pt;
              font-family: 'PingFang SC';
              mso-fareast-font-family: 'PingFang SC';
              mso-bidi-font-family: 'PingFang SC';
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </h1>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（一）访问、更新和删除</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >我们鼓励您更新和修改您的信息以使其更准确有效。您能通过按揭首付服务访问您的信息，并根据对应信息的管理方式自行完成或要求我们进行修改、补充和删除。我们将采取适当的技术手段，尽可能保证您可以访问、更新和更正自己的信息或使用按揭首付服务时提供的其他信息。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >在访问、更新、更正和删除前述信息时，我们可能会要求您进行身份验证，以保障信息安全。对于通过<span
              lang="EN-US"
              >COOKIES</span
            >收集的您的信息，我们还在本《隐私政策》第二条“<span lang="EN-US"
              >COOKIES</span
            >、日志档案和<span lang="EN-US">WEB BEACON</span
            >”部分说明了向您提供的选择机制。<strong
              >如您想查询、修改或删除您的部分信息，请登录按揭首付帐号中心或按照单项服务的具体指引进行操作。</strong
            ></span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（二）公开与分享</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >我们的多项服务可让您不仅与您的社交网络、也与使用该服务的所有用户公开分享您的相关信息，例如，您在按揭首付服务中所上传或发布的信息、您对其他人上传或发布的信息作出的回应，通过电子邮件或在按揭首付服务中不特定用户可见的公开区域内上传或公布您的个人信息，以及包括与这些信息有关的位置数据和日志信息。只要您不删除您所公开或共享的信息，有关信息可能一直留存在公众领域；即使您删除共享信息，有关信息仍可能由其他用户或不受我们控制的第三方独立地缓存、复制或储存，或由其他用户或该等第三方在公众领域保存。<strong
              >如您将信息通过上述渠道公开或共享，由此造成您的信息泄露，我们不承担责任。因此，我们提醒并请您慎重考虑是否通过上述渠道公开或共享您的信息。</strong
            ></span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（三）注销</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >在符合按揭首付单项服务的服务协议约定条件及国家相关法律法规规定的情况下，您的该项按揭首付服务帐号可能被注销或删除。当帐号注销或被删除后，与该帐号相关的、该单项服务项下的全部服务资料和数据将依照单项服务的服务协议约定删除或处理。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（四）改变您授权同意的范围</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >您总是可以选择是否披露信息。有些信息是使用按揭首付服务所必需的，但大多数其他信息的提供是由您决定的。您可以通过删除信息、关闭设备功能等方式改变您授权我们继续收集信息的范围或撤回您的授权。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >当您撤回授权后，我们无法继续为您提供撤回授权所对应的服务，也不再处理您相应的信息。但您撤回授权的决定，不会影响此前基于您的授权而开展的信息处理。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（五）有关敏感信息的提示</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >某些信息因其特殊性可能被认为是敏感信息，例如您的种族、宗教、个人健康和医疗信息等，以及身份证明文件、个人生物识别信息、财产信息、行踪轨迹、未成年人的信息等。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >请注意，您在按揭首付服务中所提供、上传或发布的内容和信息（例如有关您社交活动的照片或信息），可能会泄露您的敏感信息。您需要谨慎地考虑，是否使用按揭首付服务披露您的敏感信息。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >您同意您的敏感信息按本《隐私政策》所述的目的和方式来处理。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <h1
          style="margin: 0cm; mso-pagination: widow-orphan; background: white"
        >
          <span
            style="
              font-size: 12.5pt;
              font-family: 'PingFang SC';
              mso-fareast-font-family: 'PingFang SC';
              mso-bidi-font-family: 'PingFang SC';
              color: #3a3232;
              background: white;
            "
            >六、第三方服务</span
          ><span
            lang="EN-US"
            style="
              font-size: 12.5pt;
              font-family: 'PingFang SC';
              mso-fareast-font-family: 'PingFang SC';
              mso-bidi-font-family: 'PingFang SC';
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </h1>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >按揭首付服务可能链接至第三方提供的社交媒体或其他服务（包括网站或其他服务形式）。包括：</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（<span lang="EN-US">1</span
            >）您可利用“分享”键将某些内容分享到按揭首付服务，或您可利用第三方服务登录按揭首付服务。这些功能可能会收集您的信息（包括您的日志信息），并可能在您的电脑装置<span
              lang="EN-US"
              >COOKIES</span
            >，从而正常运行上述功能；</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（<span lang="EN-US">2</span
            >）我们通过广告或我们服务的其他方式向您提供链接，使您可以接入第三方的服务或网站；及</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >（<span lang="EN-US">3</span>）其他接入第三方服务的情形。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >该等第三方社交媒体或其他服务由相关的第三方负责运营。您使用该等第三方的社交媒体服务或其他服务（包括您向该等第三方提供的任何信息），须受第三方自己的服务条款及信息保护声明（而非本《隐私政策》）约束，您需要仔细阅读其条款。本《隐私政策》仅适用于我们所收集的任何信息，并不适用于任何第三方提供的服务或第三方的信息使用规则，而我们对任何第三方使用由您提供的信息不承担任何责任。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <h1
          style="margin: 0cm; mso-pagination: widow-orphan; background: white"
        >
          <span
            style="
              font-size: 12.5pt;
              font-family: 'PingFang SC';
              mso-fareast-font-family: 'PingFang SC';
              mso-bidi-font-family: 'PingFang SC';
              color: #3a3232;
              background: white;
            "
            >七、年龄限制</span
          ><span
            lang="EN-US"
            style="
              font-size: 12.5pt;
              font-family: 'PingFang SC';
              mso-fareast-font-family: 'PingFang SC';
              mso-bidi-font-family: 'PingFang SC';
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </h1>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >我们建议：<strong
              >任何未成年人参加网上活动应事先取得家长或其法定监护人（以下简称<span
                lang="EN-US"
                >&quot;</span
              >监护人<span lang="EN-US">&quot;</span>）的同意。</strong
            >我们将根据国家相关法律法规的规定保护未成年人的相关信息。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >我们鼓励父母或监护人指导未成年人使用按揭首付服务。我们建议未成年人鼓励他们的父母或监护人阅读本《隐私政策》，并建议未成年人在提交信息之前寻求父母或监护人的同意和指导。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <h1
          style="margin: 0cm; mso-pagination: widow-orphan; background: white"
        >
          <span
            style="
              font-size: 12.5pt;
              font-family: 'PingFang SC';
              mso-fareast-font-family: 'PingFang SC';
              mso-bidi-font-family: 'PingFang SC';
              color: #3a3232;
              background: white;
            "
            >八、通知和修订</span
          ><span
            lang="EN-US"
            style="
              font-size: 12.5pt;
              font-family: 'PingFang SC';
              mso-fareast-font-family: 'PingFang SC';
              mso-bidi-font-family: 'PingFang SC';
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </h1>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >我们可能适时修改本《隐私政策》的条款，该等修改构成本《隐私政策》的一部分。对于重大变更，我们会提供更显著的通知，您可以选择停止使用按揭首付服务；在该种情况下，如您仍然继续使用按揭首付服务的，即表示同意受经修订的本《隐私政策》的约束。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >任何修改都会将您的满意度置于首位。我们鼓励您在每次使用按揭首付服务时都查阅我们的隐私政策。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >我们可能在必需时（例如当我们由于系统维护而暂停某一项服务时）发出与服务有关的公告。您可能无法取消这些与服务有关、性质不属于推广的公告。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >最后，您必须对您的账号和密码信息负有保密义务。任何情况下，请小心妥善保管。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <h1
          style="margin: 0cm; mso-pagination: widow-orphan; background: white"
        >
          <span
            style="
              font-size: 12.5pt;
              font-family: 'PingFang SC';
              mso-fareast-font-family: 'PingFang SC';
              mso-bidi-font-family: 'PingFang SC';
              color: #3a3232;
              background: white;
            "
            >九、如何联系我们</span
          ><span
            lang="EN-US"
            style="
              font-size: 12.5pt;
              font-family: 'PingFang SC';
              mso-fareast-font-family: 'PingFang SC';
              mso-bidi-font-family: 'PingFang SC';
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </h1>

        <p
          class="MsoNormal"
          align="left"
          style="text-align: left; mso-pagination: widow-orphan"
        >
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>

        <p style="margin: 0cm; mso-pagination: widow-orphan; background: white">
          <span
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
              background: white;
            "
            >如您有关于网络信息安全的投诉和举报，或您对本《隐私政策》、您的信息的相关事宜有任何问题、意见或建议，以及有关本声明或按揭首付的隐私措施的问题请与按揭首付的协调人联系。地址是<span
              lang="EN-US"
              >kefu@hu1x1n.com</span
            >。</span
          ><span
            lang="EN-US"
            style="
              font-size: 10pt;
              font-family: '微软雅黑', sans-serif;
              mso-bidi-font-family: 微软雅黑;
              color: #3a3232;
            "
            ><o:p></o:p
          ></span>
        </p>

        <p class="MsoNormal">
          <span lang="EN-US"><o:p>&nbsp;</o:p></span>
        </p>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { getNavApi } from "@/apis/index.js";
export default {
  data() {
    return {
      dialogVisible: true,
      url: "",
    };
  },
  computed: {},
  methods: {
    closeChanPin() {
      this.$emit("closeChanPin");
    },
  },
  components: {},
  async created() {
    let reqdata = {
      type: "product",
    };
    const { data: res } = await getNavApi(reqdata);
    this.url = res.data.url;
  },
};
</script>
<style lang="scss" scoped>
.productIdrem {
  width: 100%;
  height: 547px;
}
</style>