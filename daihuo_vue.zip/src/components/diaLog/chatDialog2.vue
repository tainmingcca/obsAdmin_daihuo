<template>

<div class="drag-box flex_box" v-drag :class="isMax?'maxClass':'minClass'" ref="chatListWidth" id="drag" >
<div class="chatList"  @mousedown="returnDefault($event)"  > 
  <div class="new_search">
    <img src="@/assets/img/chat/chat_search.png" alt="">
    <input type="text"  placeholder="search" v-model="searchText" @input="filterChat">
  </div>
    <div  class="chat_box " :style="{height: isMax ? chatListHeight2 : chatListHeight}">
          <div class="chat_item" :class="chatInfo.id == item.id?'chat_current':''" v-for="(item, index) in filterChatList" :key="index" @click="changeChatList(item)">
            <el-badge :value="item.noReadCount" :hidden="item.noReadCount == 0" :max="99"><img :class="item.is_online == 0 ? 'grayImg' : ''" :src="item.head_img" alt="" ></el-badge>
            <div class="chat_item_info">
              <div class="nickname">{{item.nick_name}}</div>
              <div class="last_msg">{{item.sign}}</div>
            </div>
        </div>

    </div>


</div>
<div :class="isMax?'widthBox100':'widthBox'" >
  <div v-if="chatInfo.id">
        <div class="header" id="dragBox"  @mousedown="isMove($event)">
      <img :src="chatInfo.head_img" alt="">
      <div class="nick_name">{{chatInfo.nick_name}} <br>  <span style="color : green; font-size: 14px;font-weight: 400;">{{chatInfo.sign ? chatInfo.sign : 'Welcome to SGB Live. Nice to meet you again'}}</span> </div>
      <!-- <img class="poab1" style="height:20px;width:20px; cursor:pointer;"   src="@/assets/fontPng/min.png" alt=""> -->
      <i @click="$store.commit('getIsShowChat',false)" class="el-icon-close  poab1"></i>
    </div>
    <div  @mousedown="returnDefault($event)" @scroll="loadMoerMsg($event)" id="list" class="chat_main chatContent" :class="isMax?'':'chat_main_min'" ref="scrollContant" >
            <div v-for="(item, index) in historylist" :key="index"  class="pore" :class="item.send_uid == userInfo.id?' my_msg_detail ':' msg_detail   '">
            <img :src="item.send_uid != userInfo.id ? item.send_headimg  : userInfo.head_img" width="40px" height="40px" style="border-radius: 50%;">
            <!-- 文本 -->
         
              <div :class="item.send_uid == userInfo.id?' my_textbody ':' other_textbody  '" v-html="item.content.replace(/\#[\u4E00-\u9FA5]{1,3}\;/gi, emotion)" v-if="item.msg_type == 1" class="text_body"></div>
              <div class="nick_name_class" :class="item.send_uid == userInfo.id?' my_poab_nick_name ':'   poab_nick_name'" ><span>{{item.create_time}}</span> 
                <span  v-show="item.send_uid == userInfo.id" :class="item.send_uid != userInfo.id?' other_style':' my_style'"  class="wzdu_item" v-if="item.is_read== 0">unread</span>
                <span  v-show="item.send_uid == userInfo.id" :class="item.send_uid != userInfo.id?' other_style':' my_style'"  class="yidu_item"  v-else>read</span>
                {{item.send_nickname}} 
              </div>
            <!-- /文本 -->

            <!-- 图片 -->
            <div v-if="item.msg_type == 2" class="image_body">
                <el-image  @click="$bigImg(item.content)"  fit="scale-down" :src="item.content" @load="scrollBottom"></el-image>
            </div>
            <!-- /图片 -->

            <!-- 已读 未读 -->
            <!-- <div class="read_box" v-show="item.send_uid == userInfo.id">
                <span :class="item.send_uid != userInfo.id?' other_style':' my_style'"  class="wzdu_item" v-if="item.is_read== 0">未读</span>
                <span :class="item.send_uid != userInfo.id?' other_style':' my_style'"  class="yidu_item"  v-else>已读</span>
            </div> -->
            <!-- 已读 未读 -->


        </div>

    
    </div>
    <div  @mousedown="returnDefault($event)" class="chat_footer">
      <div class="fast_msg_list">
          <span @click="sendFastMsg(item,index)" v-for="(item, index) in fastMsgList" :key="index">{{item.title}}</span>
        </div>
      <div class="sendToll">
        <img  @click="isShowFace = !isShowFace" width="20" src="../../assets/img/chat/chat_biaoqing.png" chat_icon_tooll alt="">
        <el-upload v-if="userInfo.user_type == 1" :auto-upload="false" action="" :on-change="fileAdress" :show-file-list="false" accept="image/gif,image/jpeg,image/jpg,image/png">
            <img class="chat_icon_tooll" width="20" src="../../assets/img/chat/chat_img.png" alt="">
        </el-upload>
        <img v-if="userInfo.user_type == 1" width="20"   @click="showWelcomeDialog = true" class="chat_icon_tooll" src="../../assets/img/chat/chat_hi.png" alt="">
        <img @click="addFastMsg" width="20" class="chat_icon_tooll" src="../../assets/img/chat/chat_msg.png" v-if="userInfo.user_type == 1" alt="">
        <div class="poab_qq_face" v-show="isShowFace">
          <img class="imgBox" @click="closeqqFace(item.alt)" v-for="(item, index) in qqFaceList.emojiList" :key="index" :src="item.url" alt=""/>
        </div>
      </div>
      <div class="send_input_class" placeholder="please enter" @paste="getPritContend($event)" id="sendImInput" @keydown.enter.exact="sendMsg($event)"  ref="sendTextArea" contenteditable="true" style=""></div>
      <img @click="sendMsg($event)" class="poab" src="../../assets/img/chat/chat_send.png" alt="">
    </div>

  </div>
  <div class="select_friend_box" v-else>
    <img @mousedown="returnDefault($event)" :src="roomInfo.index_dialog_img" alt="">
    <i  @click="$store.commit('getIsShowChat',false)" class="el-icon-close clseo_btn"></i>
  </div>
</div>

<welcomeDiagLog  v-if="showWelcomeDialog&&userInfo.user_type == 1" @closeWelcome="showWelcomeDialog = false" />
<fastMsg v-if="showFastMsgDialog" @closeFastMsg="closeFastMsgs" />
</div>


</template>

<script>
import emojiList from "@/assets/js/emjoy";
import {sendImMsgApi,getHistoryMsgApi,getOssApi,getFastListgApi } from '@/apis/index'

import { EventBus } from "@/tools/EventBus";
EventBus.$on("updateHistoryMsgScroll", () => {
  setTimeout(() => {
    let scroll = document.getElementById("list");
    try {
      scroll.scrollTop = scroll.scrollHeight;
    } catch (error) {}
  }, 13);
});
export default {
	data(){
		return {
      isShowFace:false,
      searchText:"",
      flag:true,
      qqFaceList:emojiList,
      chatListHeight:"", // 常规高度
      chatListHeight2:"", // 加长高度
      isMax:false,
      sendLoading:false,
      showWelcomeDialog:false,
      showFastMsgDialog:false,
      fastMsgList:[]
		}
	},
  methods: {
    async sendFastMsg (item,index) {
      if (index == 4) return this.showFastMsgDialog = true

let content = item.content// 发送的内容
            if (!content) return this.$toast('The content cannot be empty')
                let msgData = {
              content,
              msg_type: 1,
              send_nickname: this.userInfo.nick_name,
              send_uid: this.userInfo.id,
              is_read:0
            }
            this.$store.commit('addHistoryMsg',msgData)
            this.$store.commit('topChatList',this.chatInfo)
            EventBus.$emit('updateHistoryMsgScroll')

                       let reqdata = {
              friend_id:this.chatInfo.id,
              content,
              msg_type : 1,
            }
           const {data:res} = await sendImMsgApi (reqdata)
      this.$emit("closeFastMsg");
           if (res.code !=200) return this.$toast(res.msg)
    },
    addFastMsg () {
      this.showFastMsgDialog = true
    },
    closeFastMsgs () {
      this.showFastMsgDialog = false
      this.getFastMsgList()
    },
    returnDefault (e) {
      e.stopPropagation()
      // e.preventDefault()
    },
    async getPritContend (e) {
            const cbd = e.clipboardData;
      const ua = window.navigator.userAgent;
      if (!(e.clipboardData && e.clipboardData.items)) return;
      if ( cbd.items && cbd.items.length === 2 && cbd.items[0].kind === "string" && cbd.items[1].kind === "file" && cbd.types && cbd.types.length === 2 && cbd.types[0] === "text/plain" && cbd.types[1] === "Files" && ua.match(/Macintosh/i) && Number(ua.match(/Chrome\/(\d{2})/i)[1]) < 49) return
      for (let i = 0; i < cbd.items.length; i++) {
        let item = cbd.items[i];
        if (item.kind == "file" ) {
          if (this.userInfo.user_type == 2) {
          e.preventDefault()
            return false
          }

          const blob = item.getAsFile();
      // const {data:res} = await getOssApi ('im')
          const formData = new FormData()
          // formData.append("policy", res.data.policy);
          // formData.append("OSSAccessKeyid", res.data.accessid);
          // formData.append("signature", res.data.signature);
          // formData.append("success_action_status", 200);
          // formData.append("key", res.data.dir + blob.lastModified+blob.name);
          formData.append("file", blob);
          formData.append("dir", 'im');
          document.getElementById('sendImInput').innerHTML = ""
          const {data:res} =  await  this.$upload.post('/upload', formData)
      let content = res.data.src
             let reqdata = {
              friend_id:this.chatInfo.id,
              content,
              msg_type : 2
            }
         await sendImMsgApi (reqdata)
          let msgData = {
              content,
              msg_type: 2,
              send_nickname: this.userInfo.nick_name,
              send_uid: this.userInfo.id,
              is_read:'0'
            }
        this.$store.commit('addHistoryMsg',msgData)
        this.$store.commit('topChatList',this.chatInfo)
        this.$nextTick(()=>{
            this.$refs.scrollContant.scrollTop = this.$refs.scrollContant.scrollHeight;
          document.getElementById('sendImInput').innerHTML = ""
        })
        }
      }
    },
   async fileAdress (file) {
      let content = await this.getOssSrc(file,'im')
             let reqdata = {
              friend_id:this.chatInfo.id,
              content,
              msg_type : 2
            }
           const {data:res2} = await sendImMsgApi (reqdata)
            let msgData = {
              content,
              msg_type: 2,
              send_nickname: this.userInfo.nick_name,
              send_uid: this.userInfo.id,
              is_read:'0'
            }
          this.$store.commit('addHistoryMsg',msgData)
            this.$store.commit('topChatList',this.chatInfo)
        this.$nextTick(()=>{
        this.$refs.scrollContant.scrollTop = this.$refs.scrollContant.scrollHeight;
        })
    },
          closeqqFace (item) {
            this.isShowFace = false
            this.$refs.sendTextArea.innerHTML += item;
          },
          filterChat () {
              console.log( this.filterChatList);
          },
          async changeChatList (item) {
            if (item.id == this.chatInfo.id) return
            //if (this.userInfo.user_type == 1) this.showWelcomeDialog = true
            this.$store.commit('getChatInfo',item)
            this.$store.dispatch('getHistoryMsgApi',item)
            if (this.fastMsgList.length == 0)  {
              this.getFastMsgList ()
            }
          },
          async getFastMsgList () {
                    getFastListgApi().then( ({data:res})=>{
                      let arr = []
                      if (res.data.length >4) {
                       this.fastMsgList = res.data.slice(0,4)
                       let obj = {
                        title:"more"
                       }
                       this.fastMsgList.push(obj)
                      }else {
                       this.fastMsgList = res.data
                      }
      } )
          },
          async sendMsg (event) {
            event.cancelBubble=true;
            event.preventDefault();
            event.stopPropagation();
            let content = this.$refs.sendTextArea.innerText// 发送的内容
            if (!content) return this.$toast('The content cannot be empty')
     
            this.$refs.sendTextArea.innerHTML= ""
            let msgData = {
              content,
              msg_type: 1,
              send_nickname: this.userInfo.nick_name,
              send_uid: this.userInfo.id,
              is_read:0
            }
            this.$store.commit('addHistoryMsg',msgData)
              let reqdata = {
              friend_id:this.chatInfo.id,
              content,
              msg_type : 1
            }
           const {data:res} = await sendImMsgApi (reqdata)
            if (res.code !=200) return this.$toast(res.msg)
            this.$store.commit('topChatList',this.chatInfo)
            this.$refs.sendTextArea.innerText= ""
            this.$nextTick(()=>{
                  this.$refs.scrollContant.scrollTop = this.$refs.scrollContant.scrollHeight;
              })
          },
          autoHeight () {
            this.isMax = !this.isMax
            this.$nextTick (()=>{
            let height =  this.$refs.chatListWidth.clientHeight - 58 + 'px'
            if (!this.chatListHeight2) {
              this.chatListHeight2  = height
            }
            if (this.isMax) {
              this.$refs.chatListWidth.style.left = 0
              this.$refs.chatListWidth.style.top = 0
            }
            }) 
          },
       async loadMoerMsg (e) {
           if (this.historylist.length == 0) return false
            let scrollTop =  e.target.scrollTop
            if (scrollTop == 0){
            let reqdata= {
                friend_id: this.chatInfo.id,
                last_time:this.historylist[0].last_time
            }
            if (!this.flag) return false
            this.flag = true
            const {data:res} =  await getHistoryMsgApi(reqdata)

            if (res.code != 200) return this.$toast(res.msg)
                if (res.data.length == 0) {
                    this.flag = false
                    // this.recordLoading = false
                }else{
                 let hst = e.target.scrollHeight;
                this.$store.commit('mergeHistTotyList',res.data.reverse())
                this.$nextTick(()=>{
                    e.target.scrollTop = e.target.scrollHeight - hst
                })
                }
     
            
            } 
        },
        scrollBottom () {
                this.$refs.scrollContant.scrollTop = this.$refs.scrollContant.scrollHeight;
                this.$nextTick(()=>{
                this.$refs.scrollContant.scrollTop = this.$refs.scrollContant.scrollHeight;
                })
        },
        isMove (e) {
          if (this.isMax) {
                e.stopPropagation()
          }else {
            return false
          }
        },
        // 测试发送时候回车问题
        testSend (e) {
        }
  },
  components:{
        welcomeDiagLog: ()=>import('@/components/diaLog/welcomeDiagLog.vue'),
        fastMsg: ()=>import('@/components/diaLog/fastMsg.vue')
  },
  computed: {

        filterChatList () {
          // let abc = [
          //   {
          //     is_online:1,
          //     id:1,
          //     head_img:require('../../assets/img/chat/default_man.png'),
          //     noReadCount:1,
          //     nick_name:"测试昵称",
          //     sign:'测试速度'
          //   }
          // ]         
          // return abc
          if (this.chatFriendList.length == 0) return []
          let onlineArr = [] // 在线的人
          let offlineArr = [] // 不在线的人
          let chatList = [] // 合并在线和不在线的人
          let arr = [] // 搜索到的人
          this.chatFriendList.forEach(item => {
            if (item.is_online == 1 || item.noReadCount > 0) {
              onlineArr.push(item)
            }else{
              offlineArr.push(item)
            }
          });
          chatList = onlineArr.concat(offlineArr)
          chatList.filter(item =>{
            if (item.nick_name.includes(this.searchText)){
                    arr.push(item)
            }
          })
                if (arr.length > 0) {
                return arr
            }else{
                return this.chatFriendList
            }
        }
  },

  mounted () {
      try {
                this.$refs.scrollContant.scrollTop = this.$refs.scrollContant.scrollHeight;
                this.$nextTick(()=>{
        this.$refs.scrollContant.scrollTop = this.$refs.scrollContant.scrollHeight;
        })
      } catch (error) {
        
      }
        this.chatListHeight = '550px'

  },
}

</script>

<style lang="scss" scoped>
.drag-box {
    border-radius: 5px;
    box-shadow: 0 4px 12px rgba(0,0,0,.15);
    z-index: 9999;
}
.clseo_btn {
  position: absolute;
  right: 20px;
  top: 20px;
  font-size: 25px;
  color: red;
}
.minClass{
  	position:absolute;
	top: 100px;
  left: 25%;
  // transform: translateX(-50%);
 	width:950px;
   z-index: 9999999999999;
}
.maxClass {
    width: 100%;
    left: 0;
    top: 0;
    z-index: 9999;
    position: absolute;
}
.widthBox100 {
  width: 100%;  
}

.header{
  height: 80px;
  width: 100%;
  display: flex;
  padding: 15px;
  position: relative;
  cursor: move;
  background-color: #fff;
  z-index: 3;
  box-shadow: 2px 2px 6px 1px rgba(0,0,0,0.08);
  img {
    width: 50px;
    height: 50px;
    border-radius: 50%;
  }
}
.chat_main{
  width: 100%;
  position: relative;
}

.chat_main_min {
  height: 400px;
}
.chatContent{
    box-sizing: border-box;
    padding: 20px;
    overflow: auto;
    background-color: #fff;
    // margin:  20px 0;
  //  文本css
    .text_body{
      max-width: 70%;
      border-radius: 5px;
      padding: 5px 10px;
      font-size: 15px;
      margin: 15px 10px;
      margin-bottom: 0;
      word-break: break-all;
      white-space: pre-wrap;
      display: flex;
       letter-spacing:2px;
      align-items: center;
    }




  // 图片css
  .image_body {
      max-width: 100px;
      max-height: 300px;
      min-width: 20px;
      background-color: #f7f6fc;
      margin: 20px 10px;
  .el-image,
  img {
      max-width: 100px;
      max-height: 300px;
  }
  }
  // 语音css

    .msg_detail{
        display: flex;
      align-items: flex-end;

    }
    .my_msg_detail{
      display: flex;
      align-items: flex-end;
      flex-flow: row-reverse;
    }

}
.read_box{
    display: flex;
}
.chat_footer{
  height: 120px;
  background-color: #FFFFFF;
  position: relative;
}

.nick_name{
  line-height: 25px;
  margin-left: 10px;
  color: #000;
  font-size: 18px;
  font-weight: 700;
}

.poab1{
  position: absolute;
  font-size: 25px;
  font-weight: 700;
  color: #000;
  top: 20px;
  right: 25px;
  cursor:pointer;
}
.poab2{
  position: absolute;
  top: 10px;
  right: 20px;
}
.sendToll{
  background: #fff;
  
  box-sizing: border-box;
  padding:10px 0 0 0;
  position: relative;
  display: flex;
  position: absolute;
  left: 20px;
  top: 5px;
  
}
.flex_box{
  display: flex;
  z-index: 9999;
  .widthBox{
    border-left: 1px solid #cccccc;
    width: 100%;
    }
  .chatList{
    width: 320px;
    background-color: #fff;
    box-sizing: border-box;
  }
  .chat_box{
    font-size: 14px;
    height: 550px;
    margin-top: 10px;
    overflow: auto;
    cursor: pointer;
  }
}
.chat_current{
    background-color: #ECF2FF;
    border-left: 5px solid #337AFF!important;
    .nickname{
      color: #333!important;
    }
    .last_msg{
      color: #333;
    }
}
.chat_item{
    display: flex;
    height: 60px;
    align-items: center;
    margin: 10px 0;
    width: 100%;
    position: relative;
    border-left:5px solid #FFFFFF ;
    img{
        width: 50px;
        height: 50px;
        margin-left: 10px;
    }

    .chat_item_info{
        margin-left: 10px;
        margin-top: 5px;
        .nickname{
            color: #000;
            width: 130px;
            white-space: nowrap;
            text-overflow: ellipsis;
            overflow: hidden;
            word-break: break-all;
        }
    }
    .chat_item_time{
    margin: 20px 10px 0 auto;
  color: #000;
    }
}

.last_msg{
  width: 130px;
  white-space: nowrap;
  text-overflow: ellipsis;
  overflow: hidden;
  word-break: break-all;
  color: #000;
}
.poab{
  position: absolute;
right: 14px;
    bottom: 15px;
    width: 50px;
}
.poab_qq_face{
  position: absolute;
  width: 360px;
  height: 150px;
  left: 18px;
  top: -146px;
  overflow: auto;
  background-color: #fff;
}
.grayImg {
filter: grayscale(100%);
filter: gray;
}
.select_friend_box {
  background-color: #fff;
  position: relative;
  width: 100%;
  height: 100%;
  color: #000;
  display: flex;
  text-align: center;
  img {
    margin-top:65px;
      width: 100%;
      height: 100%;
      opacity: .1;
  }
}
.pore {
  position: relative;
  margin-bottom: 40px;
}
.poab_nick_name{
    color: #000;
    position: absolute;
    left: 50px;
    bottom: -25px; 
    font-size: 15px!important;
    display: flex;
    align-items: center;
    flex-direction: row-reverse;
    span{
      margin-left: 20px;
    }
}
.my_poab_nick_name{
    position: absolute;
    font-size: 15px!important;
    right: 0px;
    bottom: -25px;
}
.wzdu_item{
    color:#000!important;
        display: flex;
    align-items: center;
}
.yidu_item{
    // color:#35CEAB!important;
    display: flex;
    align-items: center;
}
.chat_icon_tooll{
  display: inline-block;
  margin-left: 20px;
  color: #666;
  font-size: 18px;
}
.send_input_class{
  border: 1.5px solid #E5E5E5;
  border-radius: 10px;
  font-size: 16px;
  white-space:normal;
  word-break:break-all;
  word-wrap: break-word;
  border-radius: 22.5px;
  height: 115px;
  width: 100%;
  resize:none;
  padding:15px;
  background: #fff;
  outline:none;
  color:#000;
  overflow-x:auto;
  overflow-y: hidden;
  box-sizing: border-box;
  padding-top: 45px;
  // margin-top: 20px;
}
.nick_name_class{
  font-size: 12px;
  color: #999999;
  span{
    display: inline-block;
    margin-right: 10px;
  }
}

.new_search {
  position: relative;
  margin: 10px;
  img {
    position: absolute;
    left: 7px;
    top: 6px;
    width: 15px;
    height: 15px;
  }
  input {
    height: 30px;
    padding-left: 30px;
    border: none;
    outline: none;
    width: 298px;
    border: 1px solid #E0E0E0;
    border-radius: 15px;
  }
}

  .my_textbody {
    background-color: #337AFF;
    color: #fff;
  }
  .other_textbody {
    background-color: #E4E4E4;
    color: #333;
  }
  .fast_msg_list {
    position: absolute;
    left: 28px;
    top: -40px;
    display: flex;
    span {
      margin-right: 20px;
      background-color: #F7FAFF;
      border:1px solid #337AFF;
      width: 90px;
      overflow: hidden;
      text-overflow: ellipsis;

      color: #333;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 5px 12px;
      border-radius: 15px;
    }
  }

      .chat_item:hover{
        background-color: #ECF2FF!important;
        border-left: 5px solid #337AFF!important;
}
      // background-color:#5FB878;
      // color: #fff;


      #list .pore:last-child{
        margin-bottom: 52px;
      }
</style>