<template>
    <div class="">
        <el-dialog width="65%" @close="closeReg" custom-class="noheader" :close-on-click-modal="true" :show-close="false" :visible.sync="dialogVisible">
                      <div class="login_new">
                <img  height="320" src="@/assets/img/lr.png" alt="">
                <div class="form_login">
                    <p>Sign Up</p>
                    <section class="heade_input">
                        <div>
                            <span class="ml10">User name</span>
                            <input type="text" v-model="regForm.user_name" placeholder="Please enter the user name">
                        </div>
                        <div>
                            <span class="ml10">Nickname</span>
                            <input  v-model="regForm.nick_name" type="text" placeholder="Please enter a nickname">
                        </div>
                    </section>
                    <!-- <span class="ml10">mobile</span>
                    <div class="get_code">
                        <input type="text" v-model="regForm.mobile" placeholder="please input your mobile">
                        <span  @click="sendMsg" class="code_text">{{codeText}}</span>
                    </div>
                    <span class="ml10">verification code</span>
                    <input type="text" v-model="regForm.code" placeholder="Please enter the verification code"> -->
                    <span class="ml10" >Password</span>
                    <input type="password" v-model="regForm.passwd" placeholder="Please enter your password">
                    <span class="ml10">Confirm password</span>
                    <input type="password" v-model="regForm.repasswd" placeholder="Please confirm the password.">
                    <span class="ml10">Whatsapp</span>
                    <input type="text" v-model="regForm.user_qq" placeholder="Please confirm the Whatsapp.">
                    <div class="reg_tip">
                        <div @click="$emit('openLoginCloseReg')" class="go_login">Go log in</div>
                        <div  @click="regCount" class="go_reg">Register</div>
                    </div>
                    <!-- <section class="xieyi">Registration represents that you have read and agree to accept <span @click="goLink('/yhxx')" class="xieyi_link">terms of service</span> and <span   @click="goLink('/yszc')" class="xieyi_link">privacy policy</span></section> -->
                </div>
            </div>
        </el-dialog>
    </div>
</template>

<script>
import { regApi,sendCodeApi } from "@/apis/index.js";
export default {
    data() {
        return {
            dialogVisible: true,
            regForm: {
                user_name: "",
                nick_name: "",
                passwd: "",
                code:"",
                repasswd: "",
                mobile: "",
                invitation:"",
                user_qq: "",
            },
            lock: false,
            codeLock:false,
            codeTime:60,
            codeText:'get code',
            showregres:false, // 注册红包
            money:"", // 红包金额
            invcode:"", // 邀请吗
            invlink:"" //邀请链接
        };
    },
    computed: {},
    methods: {
        goLink (path) {
            this.$emit("closeReg");
            if (this.$route.path == path) return
            this.$router.push(path)
        },
        closeReg() {
            this.$emit("closeReg");
        },
        async regCount() {
            let reqdata = this.regForm;
            this.lock = true;
            const { data: res } = await regApi(reqdata);
            this.lock = false;
            this.$toast(res.msg);
            if (res.code == 200) {
                this.$store.commit("addUserToken", res.data);
                this.invlink = res.invitation
            } 
        },
        async sendMsg () {
          let reqdata = {mobile:this.regForm.mobile}
          if (!this.regForm.mobile) return  this.$toast('Please enter your mobile phone number');
          const {data:res} = await sendCodeApi(reqdata)
          if (res.code == 200) {
            if (this.codeLock == true) return
           this.codeLock = true
           this.startCountDown()
          }else {
                return this.$toast(res.msg);
          }
  
        },
        startCountDown () {
          var timer = setInterval(()=>{
              this.codeTime --
              this.codeText = `Try again in ${this.codeTime} seconds`
              if (this.codeTime == 0) {
                clearInterval(timer)
                this.codeTime = 60
                this.codeLock = false
                this.codeText = 'get code'
              }
          },1000)
        },
    },
    created() {},
    mounted() {},
};
</script>
<style lang="scss" scoped>
  .login_new {
    width: 100%;
    height: 580px;
    background-color: #F9FAFF;
    display: flex;
    align-items: center;
    justify-content: space-around;
    border-radius: 10px;
    background: linear-gradient(to right, #EBF0FF,#FCFDFF)
    
}
  
.form_login {
    display: flex;
    flex-direction: column;
    position: relative;
     p {
        font-size: 28px;
        font-weight: 600;
        color: #424243;
     }
     input {
        border: 1px solid #D1DBFF;
        background-color: #F7F9FF;
        height: 30px;
        padding-left: 10px;
        border-radius: 3px;
     }

     .reg_tip {
        display: flex;
        width: 100%;
        justify-content: space-between;
        margin-top: 10px;
        .go_login {
            width: 120px;
            height: 40px;
            background-color: #F9FBFF;
            border: 1px solid #C6C6C6;
            color: #666;
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
        }
        .go_reg {
            width: 120px;
            height: 40px;
            color: #fff;
            display: flex;
            background: linear-gradient(to bottom, #78A4FF,#2F56EE);
            justify-content: center;
            align-items: center; 
            cursor: pointer;
        }
     }
     .login_btn {
        width: 100%;
    background: linear-gradient(to bottom, #75A1FE,#335BEF);
    height: 40px;
    font-size: 18px;
    color: #fff;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 5px;
    cursor: pointer;
     }
     .xieyi {
        font-size: 12px;
        margin-top: 10px;
        .xieyi_link {
            cursor: pointer;
            margin: 0!important;
            text-decoration:underline
        }
     }
}
.pointer {
    cursor: pointer;
}
.ml10 {
    margin-left: 10px!important;
}
.heade_input {
    display: flex;
    justify-content: space-between;
    div {
        display: flex;
        flex-direction: column;
    }
    input {
        width: 215px;
    }
}
   span {
        margin: 8px 0;
     }
     .get_code {
        width: 100%;
        position: relative;
        .code_text {
            position: absolute;
            right: 10px;
            top: 5px;
            margin: 0;
            cursor: pointer;
            color: #2F56EE;
        }
        input {
            width: 274px;
            box-sizing: border-box;
            padding-right:120px ;
        }
     }
</style>