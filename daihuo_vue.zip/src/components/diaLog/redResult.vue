<template>
  <div class="">
      <el-dialog custom-class="noheader" :visible.sync="dialogVisible" @close="closeRegRes" center top="80px" width="850px">
        <div class="red_res">
             <img src="@/assets/img/reg_res.png" alt="">
             <span class="money">{{money}}</span>
             <span class="url" :title="invitation_url">{{invitation_url}}</span>
             <div class="btn">
              <el-button @click="copyUrl" type="danger" size="small">copy link</el-button>
             </div>
        </div>
      </el-dialog>
  </div>
</template>

<script>
import { Alert, MessageBox } from "element-ui";
import {getNavApi,createUserRedApi} from '@/apis/index.js'
export default {
  data() {
    return {
            dialogVisible:true,
    };
  },
  props:['invitation_url','money'],
  computed: {},
  methods: {
      closeRegRes () {
          this.$emit('closeRegRes')
      },
      copyUrl () {
              var input = document.createElement("input"); // 创建input对象
              input.value = this.invitation_url; // 设置复制内容
              document.body.appendChild(input); // 添加临时实例
              input.select(); // 选择实例内容
              document.execCommand("Copy"); // 执行复制
              this.$toast('Successful replication')
              if (this.$route.path == '/register') {
                window.location = '/'
              }
      }
 
  },
  components: {},

  mounted() {}
};
</script>
<style lang="scss" scoped>
.red_res {
  width: 850px;
  position: relative;
  img {
    width: 850px;
    height: 425px;
  }
  .money {
    position: absolute;
    left: 365px;
    top: 105px;
    width: 58px;
    text-align: center;
    color: red;
    font-size: 20px;
  }
  .url {
    position: absolute;
    left: 245px;
    bottom: 195px;
    color: red;
    width: 120px;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }
  .btn {
    position: absolute;
    right: 251px;
    bottom: 188px;
  }
}

</style>