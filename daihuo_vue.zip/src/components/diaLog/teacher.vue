<template>
    <div class="">
        <el-dialog
            center=""
            :visible.sync="dialogVisible"
            @close="closeTeacher"
            custom-class="width_dialog noheader"
            :show-close="false"
            top="80px"
        >
             <div class="close_icon" @click="closeTeacher">
                <i class="el-icon-close"></i>
            </div>
            <!-- <el-tabs type="card" @tab-click="handleClick">
                <el-tab-pane
                    :label="item.nick_name"
                    v-for="(item, index) in teacherList"
                    :key="index"
                >
                    <section class="teacher_box">
                        <div class="teach_image">
                            <img :src="item.head_img" alt="" />
                            <div @click="dianZan(item)" class="dianzan">
                                小伙伴点赞【{{ item.zan_nums }}】次
                            </div>
                        </div>
                        <div class="teacher_info">
                            <div class="teacher_item">
                                <span>名师名称：</span>
                                <span>{{ item.nick_name }}</span>
                            </div>
                            <div class="teacher_item">
                                <span>交易理念：</span>
                                <span>{{ item.jyln }}</span>
                            </div>
                            <div class="teacher_item">
                                <span>从业经历：</span>
                                <span>{{ item.cyjl }}</span>
                            </div>
                            <div class="teacher_item">
                                <span>擅长品种：</span>
                                <span> {{ item.scpz }} </span>
                            </div>
                            <div class="teacher_item">
                                <span>特色课件：</span>
                                <span>{{ item.tskj }}</span>
                            </div>
                        </div>
                    </section>
                </el-tab-pane>
            </el-tabs> -->


  <el-carousel :interval="5000" arrow="always" class="height_car">
    <el-carousel-item  v-for="(item, index) in teacherList"   :key="index">
        <img width="930px"  height="400px" :src="item.head_img" alt=""  />
        <!-- <img  src="@/assets/img/546.jpg" alt=""  /> -->
    </el-carousel-item>
  </el-carousel>


        </el-dialog>
    </div>
</template>

<script>
import { getTeacherListApi, zanTeacherApi } from "@/apis/index";
export default {
    data() {
        return {
            dialogVisible: true,
            activeName: "1",
            teacherList: [],
            reqLock: false,
        };
    },
    computed: {},
    methods: {
        closeTeacher() {
            this.$emit("closeTeacher");
        },
        handleClick(tab) {
        },
        async dianZan(item) {
            let reqdata = { id: item.id };
            if (this.reqLock) return;
            this.reqLock = true;
            const { data: res } = await zanTeacherApi(reqdata);
            this.reqLock = false;
            if (res.code == 200) {
                item.zan_nums = item.zan_nums + 1;
            }
            this.$toast(res.msg);
        },
    },
    components: {},
    async created() {
        const { data: res } = await getTeacherListApi();
        this.teacherList = res.data;
    },
    mounted() {},
};
</script>
<style lang="scss" scoped>
::v-deep.el-dialog__header{padding: 15px 0;}
.teacher_box {
    display: flex;
    padding:0 10px 10px;
    .teach_image {
        width: 40%;
        margin-right: 10px;
        img {
            width: 100%;
            height: 400px;
        }
        .dianzan {
            height: 50px;
            text-align: center;
            line-height: 50px;
            color: red;
            background-color: #a2d0fc;
            margin: 5px 0;
            margin-right: 0;
            border-radius: 5px;
            cursor: pointer;
        }
    }
    .teacher_info {
        width: 60%;
        .teacher_item {
            line-height: 35px;
            margin: 10px 0;
        }
        .teacher_item span:first-child {
            width: 70px;
            color: #000;
            font-weight: 700;
        }
    }
}
    .close_icon {
        z-index: 9;
        position: absolute;
        cursor: pointer;
        right: -5px;
        top: -5px;
        width: 30px;
        height: 30px;
        border-radius: 100%;
        background-color: #757B78;
        border: 2px solid #fff;
        color: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        font-size: 20px;
        cursor: pointer;
    }
</style>