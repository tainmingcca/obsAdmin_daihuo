<template>
  <div class="">
    <el-dialog :visible.sync="dialogVisible" title="Sign in record" center="" @close="closeRecord" width="800px">
      <el-table :data="tableData" border style="width: 100%;margin-top:30px;" >
        <el-table-column align="center" prop="create_time" label="period" ></el-table-column>
        <el-table-column align="center" prop="nick_name" label="username" ></el-table-column>
        <el-table-column align="center" prop="value" label="prize"> </el-table-column>
      </el-table>
      <div  class="elpa">
      <el-pagination :total="count" @current-change="currentChange" background layout="prev, pager, next" ></el-pagination>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { userSingListApi } from "@/apis/index.js";
export default {
  data() {
    return {
      dialogVisible: true,
      page:1,
      count:1,
       tableData: []
    };
  },
  computed: {},
  methods: {
    closeRecord() {
      this.$emit("closeRecord");
    },
    currentChange (page) {
      this.getSignList(page)
    },
    async getSignList (page) {
      let reqdata = {page:page || 1}
        const {data:res} = await userSingListApi(reqdata)
        this.count = res.data.count 
        this.tableData = res.data.list
    }
  },
  components: {
    
  },
  created() {},
  mounted() {
    this.getSignList ()
  },
};
</script>
<style lang="scss" scoped>
.elpa {
  margin: 20px  0;
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 50px;
}
</style>