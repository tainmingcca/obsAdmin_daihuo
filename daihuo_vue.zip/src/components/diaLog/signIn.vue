<template>
  <div class="sign">
    <div class="mask" @click.self="closeSign"></div>
    <!-- <div class="bg_title"></div> -->
    <div class="content">
        <div @click="signIn(item,index)" v-for="(item,index) in signInList" :key="index" class="item">
          <div>{{item.name}}</div>
          <div class="prize">{{item.value}}</div>
          <img v-show="item.id <= countTimes" src="../../assets/img/yiqmdao.png" class="yiqiandao" alt="">
          <div class="qd_btn">Click to sign in</div>
          <div v-show="item.id <= countTimes" class="mask2"></div>
        </div>
        <div class="item flex_end">
          <div class="text">After registering as a member, you can click Sign in for 7 consecutive days to get the corresponding privileges and gifts. Please contact the platform customer service to verify and receive the corresponding gifts after successful sign in. Each person only has one chance.</div>
          <div class="record" @click="showRecord = true">Sign in record</div>
        </div>
    </div>
    <div class="qiandao_success" v-show="showSignSuccess">
      <div class="close" @click="closeQiandao">close</div>
    </div>
    <SignInRecord v-if="showRecord" @closeRecord="showRecord = false" />
  </div>
</template>

<script>
import { Alert, MessageBox } from "element-ui";
import { EventBus } from "@/tools/EventBus";
import { SingListApi,createSignApi,getUserSignCountApi } from "@/apis/index.js";
export default {
  data() {
    return {
      signInList:[],
      countTimes:0,
      showSignSuccess:false,
      showRecord:false
    };
  },
  computed: {},
  methods: {
    async signIn (item) {
      if (this.userInfo.isYk) {
      return  MessageBox.alert("Please sign in after login", "Tips", {
          confirmButtonText: "Go log in",
          callback:  () => {
              EventBus.$emit('openLogin')
          },
        });
      } 
      if (item.id <= this.countTimes) return
      let reqdata = {term:item.term,id:item.id}
      const {data:res} = await createSignApi(reqdata)     
      if (res.code == 200) {
        this.showSignSuccess = true
        this.countTimes= this.countTimes +1
      }else {
        this.$toast(res.msg)
      }

    },
 
   async getSignList () {
      const {data:res}   = await SingListApi()
       if (res.code == 200) {
        const term =  res.data.list[0].term
        this.getUserSignCount(term)
        this.signInList =res.data.list
        for(var i=0; i<this.signInList.length-1; i++){
	//每一轮比较要比多少次
          for(var j=0; j<this.signInList.length-1-i; j++){
              //如果第一个比第二个大，就交换他们两个位置
              if(this.signInList[j].id>this.signInList[j+1].id){
                  var temp = this.signInList[j]
                  this.signInList[j]= this.signInList[j+1]
                  this.signInList[j+1] = temp;
              }
          }    
        }
      }else {
        this.$toast(res.msg);
      }
    },
    closeSign () {
        this.$emit('closeSign')
    },
    closeQiandao () {
      this.showSignSuccess = false
    },
    async getUserSignCount (term) {
      let reqdata = {term}
      const {data:res} = await getUserSignCountApi(reqdata)
       this.countTimes = res.data.count
    }
  },
  components: {
    SignInRecord:()=> import('./signInRecord.vue')
  },
  created() {
    this.getSignList()
  },
  mounted() {}
};
</script>
<style lang="scss" scoped>
.mask {
    position: fixed;
    top: 0;
    left: 0;
    overflow: auto;
    margin: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,.3);
}
.content {
    width: 1000px;
    height: 700px;
    padding-top: 50px;
    // background-color: #44CEF6;
    background: url('../../assets/img/skin/ys_6_1.jpg') no-repeat;
    background-size: 100% 100%;
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%,-50%);
    display: flex;
    flex-wrap: wrap;
    justify-content: space-around;
    .item {
        width: 220px;
        height: 300px;
        position: relative;
        background: linear-gradient(to bottom,  rgb(255, 233, 133),rgb(249, 212, 35));
        box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04);
        border-radius: 15px;
        display: flex;
        flex-direction: column;
        align-items: center;
        box-sizing: border-box;
        padding: 10px;
        color: red;
        font-size: 18px;
        cursor: pointer;
        .yiqiandao {
          position: absolute;
          left: 30px;
          bottom: 0;
          width: 140px;
          z-index: 2;
        }
        .mask2 {
          width: 220px;
          height: 300px;
          left: 0;
          top: 0;
          border-radius: 15px;
          position: absolute;
          background-color: rgba(255, 255, 255,.5);
        }
    }
}
// .sign {
//     position: relative;
//     width: 100%;
//     height: 100%;
// }
.content .item:last-child{
  background: linear-gradient(to bottom,  rgb(249, 212, 35),rgb(255, 233, 133));

        // background: transparent;
        // box-shadow: none;
}
.prize {
  margin-top: 100px;
  font-size: 30px;
}
.qiandao_success {
  position: absolute;
  width: 350px;
  height: 200px;
  left: 50%;
  top: 50%;
  transform: translate(-50%,-50%);
  background: url('../../assets/img/qdig.png') no-repeat;
    background-size: 100% 100%;
    display: flex;
    justify-content: flex-end;
    flex-direction: column;
    box-sizing: border-box;
    padding-bottom: 60px;
    .close {
      width: 150px;
      height: 30px;
      display: flex;
      justify-content: center;
      align-items: center;
      margin-left: 100px;
      background-color: #FEE46C;
      color: #fff;
      text-align: center;
      cursor: pointer;
    }
}
.flex_end {
  display: flex;
  justify-content: space-around;
  flex-direction: column;
  // background-color: #b8a344!important;
  // align-items: flex-end; 
  .text{
    color: #000;
    font-size: 16px;
  }
  .record {
    color:#FEE46C!important;
    background-color: red;
    padding: 10px 20px;
    border-radius: 5px;
  }
}
.bg_title {
  background: url('../../assets/img/title.png') no-repeat;
    background-size: 100% 100%;
  position: absolute;
    left: 50%;
  top: 50%;
  z-index: 1;
  transform: translate(-50%,-50%);
  width: 470px;
  height: 420px;
}
.qd_btn {
  position: absolute;
  bottom: 30px;
  left: 50%;
  transform: translateX(-50%);
  width: 150px;
  height: 60px;
  background-color: rgb(193, 41, 41);
  border-radius: 10px;
  color: #fff;
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>