<template>
  <div class="">
      <el-dialog title="service system"
                 :visible.sync="dialogVisible"
                 center
                 @close="closeSever"
                 top="80px"
                >
  <img :src="url" alt="" style="width :100%;">
      </el-dialog>
  </div>
</template>

<script>
import {getNavApi} from '@/apis/index.js'
export default {
  data() {
    return {
      dialogVisible:true,
      url:"",
    };
  },
  computed: {},
  methods: {
      closeSever () {
          this.$emit('closeSever')
      }
  },
  components: {},
  async created() {
    let reqdata = {
      type:"service"
    }
    const {data:res} = await getNavApi(reqdata)
    this.url= res.data.url
  },
  mounted() {}
};
</script>
<style lang="scss" scoped>
::v-deep.el-dialog__header{padding: 15px 0;}
::v-deep.el-dialog{width:700px;}
</style>