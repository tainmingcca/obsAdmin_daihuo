<template>
    <div class="">
        <el-dialog width="60%" @close="closeLogin" custom-class="noheader" :close-on-click-modal="true" :show-close="false" :visible.sync="dialogVisible">
            <div class="login_new">
                <img  height="320" src="@/assets/img/lr.png" alt="">
                <div class="form_login">
                    <p>Log In</p>
                    <span class="ml10">Mobile</span>
                    <input type="text" v-model="loginForm.user_name" placeholder="Please enter the account number.">
                    <span class="ml10">Password</span>
                    <input type="password" v-model="loginForm.passwd" placeholder="Enter your password">
                    <div class="reg_tip">
                        <span class="ml10">No account yet</span>
                        <span @click="$emit('openRegCloseLogin')" class="reg_btn">Sign up right away</span>
                    </div>
                    <div class="login_btn" @click="login">Login</div>
                    <!-- <section class="xieyi">Registration represents that you have read and agree to accept <span @click="goLink('/yhxx')" class="xieyi_link">terms of service</span> and <span   @click="goLink('/yszc')" class="xieyi_link">privacy policy</span></section> -->
                </div>
            </div>
        </el-dialog>
    </div>
</template>

<script>
import { loginApi } from "@/apis/index.js";
export default {
    data() {
        return {
            dialogVisible: true,
            loginForm: {
                user_name: "",
                passwd: "",
            },
        };
    },
    computed: {},
    methods: {
                goLink (path) {
            this.$emit("closeLogin");
            if (this.$route.path == path) return
            this.$router.push(path)
        },
        closeLogin() {
            this.$emit("closeLogin");
        },
        async login() {
        for (const key in this.loginForm) {
            if (!this.loginForm[key]) return this.$toast("Please enter full information");
        }
        const { data: res } = await loginApi(this.loginForm);
        this.$toast(res.msg);
        if (res.code == 200) {
            this.$store.commit("addUserToken", res.data);
            location.reload()
        }
        },
    },
    components: {},
    created() {},
    mounted() {},
};
</script>
<style lang="scss" scoped>
.login_new {
    width: 100%;
    height: 450px;
    background-color: #F9FAFF;
    display: flex;
    align-items: center;
    justify-content: space-around;
    border-radius: 10px;
    background: linear-gradient(to right, #EBF0FF,#FCFDFF)
    
}
.form_login {
    display: flex;
    flex-direction: column;
     p {
        font-size: 28px;
        font-weight: 600;
        color: #424243;
     }
     input {
        border: 1px solid #D1DBFF;
        background-color: #F7F9FF;
        height: 30px;
        padding-left: 10px;
        border-radius: 3px;
     }
     span {
        margin: 10px 0;
     }
     .reg_tip {
        display: flex;
        width: 100%;
        justify-content: space-between;
        .reg_btn {
            color: #2F56EE;
            cursor: pointer;
            text-decoration:underline
        }
     }
     .login_btn {
        width: 100%;
    background: linear-gradient(to bottom, #75A1FE,#335BEF);
    height: 40px;
    font-size: 18px;
    color: #fff;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 5px;
    cursor: pointer;
     }
     .xieyi {
        margin-top: 10px;
        font-size: 12px;
        .xieyi_link {
            cursor: pointer;
            margin: 0!important;
            text-decoration:underline
        }
     }
}
.pointer {
    cursor: pointer;
}
.ml10 {
    margin-left: 10px!important;
}
</style>