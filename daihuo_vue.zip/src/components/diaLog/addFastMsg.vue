<template>
  <div class="">
    <el-dialog
      :visible.sync="dialogVisible"
      @close="closeAddFast"
      :center="false"
      width="320px"
      custom-class="new_addmsg"
    >
 
    <template>
      <slot name="title">
        <div class="title_new" >Shortcut message</div>
      </slot>
    </template>
      <div class="textarea_class">
        <input type="text"  placeholder="Please enter remarks" v-model="remark">
        <textarea v-model="welMsg" name="" id="" cols="30" rows="10"></textarea>
      </div>

      <span slot="footer" class="dialog-footer">
        <el-button @click="closeAddFast">cancel</el-button>
        <el-button type="primary" @click="setWel">confirm</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import { editFastListgApi, addFastListgApi } from "@/apis/index.js";
export default {
  data() {
    return {
      dialogVisible: true,
      welMsg: "",
      remark:""
    };
  },
  props:{
    editData: {
      type: Object,
      required:false
    },
    isEdit: {
      type :Boolean,
      required:false
    }
  },
  computed: {},
  methods: {
    closeAddFast() {
      this.$emit("closeAddFast");
    },
  async  setWel() {
      if (!this.remark) return this.$toast('The remarks cannot be empty');
      let reqdata = {
        content: this.welMsg,
        title:this.remark,
        id:this.editData.id || ""
      };

      if (this.isEdit) {
        const {data:res} = await editFastListgApi(reqdata)
        if (res.code == 200) {
            this.$toast(res.msg);
            this.$emit('refreshMsg')
        }
      }else {
        const {data:res} = await addFastListgApi(reqdata)
        if (res.code == 200) {
            this.$toast(res.msg);
            this.$emit('refreshMsg')
        }
      }
 

    },
  },
  components: {},

  mounted() {
    if (this.isEdit) {
      this.welMsg = this.editData.content
      this.remark = this.editData.title
    }else {
      this.welMsg = ""
      this.remark = ""
    }
  },
};
</script>
<style lang="scss" scoped>
.textarea_class {
  width: 100%;
  padding: 20px;
  input {
    width: 280px;
    outline: none;
    border: 1px solid #ccc;
    border-radius: 10px;
    padding: 5px;
    height: 40px;
    margin-bottom: 30px;

  }
  textarea {
    outline: none;
    border: 1px solid #ccc;
    padding: 5px;
    border-radius: 10px;
    resize: none;
    width: 280px;
  }
}
.title_new {
  font-weight: 700;
  margin-left: 20px;
  font-size: 18px;
}
</style>
