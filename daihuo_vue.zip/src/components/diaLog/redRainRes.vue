<template>
  <div class="">
        <el-dialog   class="noheader" :visible.sync="dialogVisible" :close-on-click-modal="true" @close="closeRedRainres" center top="80px" width="450px">
            <section class="red_res">
                  <img src="@/assets/img/red_nums.png" alt="">
                   <div class="red_box">
                      <div class="red_box_span" v-for="(item, index) in redNum" :key="index"> 
                        <span class="fuhao">￥</span> 
                        <span>{{item}}</span>
                      </div>
                   </div>
            </section>
      </el-dialog>
  </div>
</template>

<script>
import { mapState } from 'vuex';
export default {
  data() {
    return {
      dialogVisible:true
    };
  },
  computed: {
    ...mapState(['catchRedNum']),
    redNum () {
      let arr = []
      this.catchRedNum.forEach(item => {
        if (arr.length ==10) return
        arr.push(item)
      });
      return arr
    }
  },
  methods: {
    closeRedRainres () {
      let data = {type : 2}
        this.$emit('closeRedRainres')
      this.$store.commit('getCatchRedNum',data)
    }
  },
  components: {},
  created() {},
  mounted() {}
};
</script>
<style lang="scss" scoped>
.red_res {
    width: 450px;
    img {
    width: 450px;
    height: 600px;
    position: absolute;
    }
    .red_box {
        position: absolute;
        right: 0;
        width: 250px;
        height: 600px;
        display: flex;
        flex-direction: column;
        box-sizing: border-box;
        padding: 60px 0 50px 0;
        .red_box_span {
          color: #FAB804;
          font-size: 25px;
          display: flex;
          align-items: center;
          margin-top: 19px;
          justify-content: flex-end;
          box-sizing: border-box;
          padding-right: 30px ;
          position: relative;
          .fuhao {
            position: absolute;
            left: 130px;
            top: -5px;
          }
        }
    }
}
</style>