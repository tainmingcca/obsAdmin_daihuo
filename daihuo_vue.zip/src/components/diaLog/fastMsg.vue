<template>
  <div class="">
    <el-dialog
      :show-close="false"
      :visible.sync="dialogVisible"
      @close="closeFastMsg"
      :center="false"
      width="650px"
    >

    <template>
      <slot name="title">
        <div class="title_new_fast">
          <span>Shortcut message</span>
          <el-button @click="showAddDialog" type="primary"  size="mini">add</el-button>
        </div>
      </slot>
    </template>

      <div class="textarea_class">
        <el-table :data="tableData" style="width: 100%">
          <el-table-column label="Quick phrase" width="180">
            <template slot-scope="scope">
                <p>{{ scope.row.content }}</p>
            </template>
          </el-table-column>
          <el-table-column label="remark" width="180">
            <template slot-scope="scope">
                <span>{{ scope.row.title }}</span>
            </template>
          </el-table-column>
          <el-table-column width="250" label="operation">
            <template slot-scope="scope">
              <el-button size="mini" @click="sendFastMsg(scope.row)" >send</el-button>
              <el-button size="mini" type="danger" @click="delFast(scope.row)" >delete</el-button>
              <el-button size="mini" type="success" @click="editFast(scope.row)" >edit</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </el-dialog>
    <addFastMsg v-if="showAddFast" :editData ="editData" :isEdit="isEdit" @refreshMsg="refreshFastMsg" @closeAddFast="showAddFast =false"/>
  </div>
</template>

<script>
import {sendImMsgApi,getFastListgApi,addFastListgApi,delHistoryMsgApi} from "@/apis/index.js";
import { EventBus } from "@/tools/EventBus";
export default {
  data() {
    return {
      dialogVisible: true,
      showAddFast:false,
      isEdit:false,
      editData:{},
      fastMsg: "",
       tableData: []
    };
  },
  computed: {},
  methods: {
    closeFastMsg() {
      this.$emit("closeFastMsg");
    },
    refreshFastMsg () {
      this.showAddFast = false
      this.getFastList()
    },
    async sendFastMsg (item) {
            let content = item.content// 发送的内容
            if (!content) return this.$toast('The content cannot be empty')
 
                        let msgData = {
              content,
              msg_type: 1,
              send_nickname: this.userInfo.nick_name,
              send_uid: this.userInfo.id,
              is_read:0
            }
            this.$store.commit('addHistoryMsg',msgData)
            this.$store.commit('topChatList',this.chatInfo)
            EventBus.$emit('updateHistoryMsgScroll')

                       let reqdata = {
              friend_id:this.chatInfo.id,
              content,
              msg_type : 1,
            }
           const {data:res} = await sendImMsgApi (reqdata)
      this.$emit("closeFastMsg");
           if (res.code !=200) return this.$toast(res.msg)


    },
    async addFastMsg () {

      let reqdata = {
          content: this.fastMsg
      }
      const {data:res} = await addFastListgApi(reqdata)
      if (res.code == 200) {
        this.$emit("closeWelcome");
        this.getFastList()
      }
    },
    showAddDialog () {
      // this.$emit("openAdd");
      this.isEdit =false
      this.showAddFast = true
    },
    editFast (item) {
      this.isEdit= true,
      this.editData = item
      this.showAddFast= true
    },
    delFast (item) {
        let reqdata= {
            id :item.id
        }
       delHistoryMsgApi(reqdata).then(({data:res})=>{
           if (res.code == 200) this.getFastList()
       })
    },
    getFastList () {
        getFastListgApi().then( ({data:res})=>{
            this.tableData = res.data
      } )
    }
  },
  components: {
    addFastMsg:()=>import('@/components/diaLog/addFastMsg.vue'),
  },
  created() {
    this.getFastList()
  },
  mounted() {},
};
</script>
<style lang="scss" scoped>
.textarea_class {
  width: 100%;
  padding: 20px;
  textarea {
    outline: none;
    padding: 5px;
  }
}
.taxtar{
      width: 100%;
  padding: 20px;
    textarea {
    outline: none;
    padding: 5px;
  }
}
.title_new_fast {
  display: flex;
  justify-content: space-between;
  padding: 0 30px;
  span {
    font-weight: 700;
  }
}
</style>