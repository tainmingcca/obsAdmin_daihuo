<template>
  <div class="">
    <el-dialog :visible.sync="dialogVisible" custom-class="noheader" :show-close="false"  @close="closeKuaidi" width="380px">
        <section class="kuai_section">
            <div class="kuai_header">
                <div class="title">Express Check</div>
                <i @click="closeKuaidi"  class="el-icon-close"></i>
            </div>
            <div class="kuaidi_content">
                <div class="search_input">
                    <input v-model="yunDanCode" class="kuai_di" type="text" placeholder="Please enter the tracking number">
                    <i @click="searchKyuaiDi" style="cursor: pointer;" class="el-icon-search"></i>
                </div>
                <img v-show="isKong" src="@/assets/img/kong.png" alt="">
            </div>
            <section class="lujing" v-if="isKong == false">
<!--                <div class="content">
                    <span class="title">客户信息：</span>
                    <span class="val">电话 1992362184 锦绣花园小广锦绣花园小广锦绣花园小广锦绣花园小广锦绣花园小广</span>
                </div> -->
                <div class="content">
                    <span class="title">{{kuaidiData.expName}}：</span>
                    <span class="val">{{kuaidiData.number}}</span>
                </div>
                <div class="content">
                    <span class="title">Express telephone number：</span>
                    <span class="val">{{kuaidiData.expPhone}}</span>
                </div>
                <div class="content">
                    <span class="title">recent updates：</span>
                    <span class="val">{{kuaidiData.updateTime}}</span>
                </div>
                <div class="content">
                    <span class="title">Total duration：</span>
                    <span class="val">{{kuaidiData.takeTime || '-----'}}</span>
                </div>
            </section>

            <section class="setup" v-if="isKong == false">
                <div class="time" v-for="(item,index) in kuaidiData.list"   :key="index">
                    <div class="round" :class="index == 0 ? 'current' : ''">
                        <span class="round2"></span>
                    </div>
                    <div class="detail">
                        <span style="margin-top:2px;">{{item.time}}</span>
                        <span class="detail_text">{{item.status}}</span>
                    </div>
                </div>
   <!--             <div class="time">
                    <div class="round">
                        <span class="round2"></span>
                    </div>
                    <div class="detail">
                        <span style="margin-top:2px;">2023-02-13 12:14:23</span>
                        <span class="detail_text">已签收，签收人凭取货码签收，如您未收到此</span>
                    </div>
                </div> -->
            
            </section>
        </section>
    </el-dialog>
  </div>
</template>

<script>
	import {logiSticsApi} from '@/apis/index'
export default {
  data() {
    return {
      dialogVisible: true,
      yunDanCode:"",
	  kuaidiData:new Object,
      isKong:true
    };
  },
  computed: {},
  methods: {
    closeKuaidi() {
      this.$emit("closeKuaidi");
    },
	async searchKyuaiDi () {
		let reqdata = {order_no :this.yunDanCode}
		if (!this.yunDanCode) return this.$toast('Please enter the correct waybill number')
		const {data :res} = await logiSticsApi(reqdata)
		if (res.code == 200) {
			this.isKong = false
			this.kuaidiData = res.data.list
		}else {
			this.isKong = true
			return this.$toast(res.msg)
		}
		
	}

  },	
  components: {},
  created() {},
  mounted() {

  },
};
</script>
<style lang="scss" scoped>


  .kuai_section {
    padding: 10px;
	max-height: 420px;
	overflow: auto;
    .kuaidi_content {
        display: flex;
        flex-direction: column;
        align-items: center;
        .search_input {
            position: relative;
            i {
                position: absolute;
                top: 20px;
				right: 0px;
				color: #fff;
                font-size: 16px;
				height: 30px;
				width: 35px;
				display: flex;
				justify-content: center;
				align-items: center;
				background-color: #6FC080;
				border-radius: 0 15px 15px 0;
            }
        }
    .kuai_di {
        border: 1px solid #D1DBFF;
        height: 30px;
        width: 280px;
        padding-left: 10px;
        border-radius: 15px;
        margin: 20px 0;
        padding-right: 35px;
    }
    img {
        width: 260px;
    }
    }

    }
  .kuai_header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 20px;
    .title {
        color: #000;
        font-size: 16px;
    }
    i {
        color: #000!important;
        font-size: 16px;
        cursor: pointer;
    }
  }
  .lujing {
    padding: 0 56px;
    .content {
        display: flex;
        margin-bottom: 10px;
        .title {
            width: 70px;
            flex-shrink: 0;
            color: #878787;
        }
        .val{
            color: #333;
        }
    }
  }
  .setup {
    margin-top: 20px;
    padding: 0 56px;
    .time {
        display: flex;
        align-items: center;
        margin-bottom: 20px;
        .current {
            background-color: #C1CDFA!important;
            .round2 {
                background-color: #2F56EE!important;
            }
        }
        .round {
            width: 20px;
            height: 20px;
            background-color: #EAEAEA;
            position: relative;
            border-radius: 100%;
            margin-right: 15px;
            flex-shrink: 0;
            align-self: baseline;
            margin-bottom: 5px;
            .round2 {
                display: flex;
                width: 12px;
                height:12px;
                background-color: #BABABA;
                position: absolute;
                left: 50%;
                top: 50%;
                z-index: 2;
                transform: translate(-50%,-50%);
                border-radius: 100%;
            }
        }
        .detail {
            display: flex;
            flex-direction: column;
            .detail_text {
                color: #333;
                margin-top: 10px;
            }
        }
    }
  }
  // .el-icon-search {
	 //  height: 30px;
  // }
</style>