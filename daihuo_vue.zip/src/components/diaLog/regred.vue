<template>
  <div class="">
      <el-dialog custom-class="noheader" :show-close="false" :visible.sync="dialogVisible" :close-on-click-modal="false" @close="closeRegRed" center top="80px" width="350px">
            <div class="close_icon" @click="closeRegRed">
                <i class="el-icon-close"></i>
            </div>
           <img src="../../assets/img/regred.gif" alt="" style="width:350px;">
      </el-dialog>
  </div>
</template>

<script>
import { Alert, MessageBox } from "element-ui";
import {getNavApi,createUserRedApi} from '@/apis/index.js'
export default {
  data() {
    return {
            dialogVisible:true,

    };
  },

  computed: {},
  methods: {
      closeRegRed () {
          this.$emit('closeRegRed')
      },
    
  },
  components: {},

  mounted() {}
};
</script>
<style lang="scss" scoped>
.tac {
  text-align: center;
}
::v-deep.el-dialog{width:750px;}
::v-deep.el-dialog__header{padding: 15px 0;}
    .close_icon {
        position: absolute;
        right: -10px;
        top: -10px;
        width: 30px;
        height: 30px;
        border-radius: 100%;
        background-color: #757B78;
        border: 2px solid #fff;
        color: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        font-size: 20px;
        cursor: pointer;
    }
</style>