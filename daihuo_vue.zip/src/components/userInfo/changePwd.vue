<template>
  <div class="">
    <el-dialog
      title="change password"
      center
      :visible.sync="dialogVisible"
      @close="closePwd"
      width="440px"
    >
<el-form class="changePwd_form"  label-width="100px" :model="changePwdForm" size="mini">
  <el-form-item label="original password">
    <el-input v-model="changePwdForm.pwd"></el-input>
  </el-form-item>
  <el-form-item label="new password">
    <el-input type="password" v-model="changePwdForm.pwd1"></el-input>
  </el-form-item>
  <el-form-item label="Confirm new password">
    <el-input type="password" v-model="changePwdForm.pwd2"></el-input>
  </el-form-item>
  <el-form-item>
      <el-button class="save_pwd_btn" @click="changePwd" type="primary" >Confirm </el-button>
  </el-form-item>
</el-form>
    </el-dialog>
  </div>
</template>

<script>
import {editPwdApi} from '@/apis/index.js'
export default {
  data() {
    return {
      dialogVisible: true,
      changePwdForm:{
          pwd:"",
          pwd1:"",
          pwd2:"",
      }
    };
  },
  computed: {},
  methods: {
      closePwd () {
          this.$emit('closePwd')
      },
      async changePwd () {
        for (const key in this.changePwdForm) {
            if (!this.changePwdForm[key]) return this.$toast(res.msg)
        }
        let reqdata= this.changePwdForm
        const {data:res} = await editPwdApi(reqdata)
          this.$toast(res.msg)
        if (res.code== 200) {
          this.$store.dispatch('logOutApi')
        }
        
      }
  },
  components: {},
  created() {},
  mounted() {},
};
</script>
<style lang="scss" scoped>
.changePwd_form {
    height: 265px;
    margin-top: 30px;
    background: url('../../assets/img/center.jpg') no-repeat;
    background-size: contain;
}
 ::v-deep.el-input {
     width: 260px;
 }
 .save_pwd_btn {
     margin-left: 50px;
 }
</style>