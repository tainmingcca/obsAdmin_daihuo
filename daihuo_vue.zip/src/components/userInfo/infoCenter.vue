<template>
    <div class="">
        <el-dialog
            title="information center"
            center
            :visible.sync="dialogVisible"
            @close="closeInfoCenter"
            width="430px"
        >
            <section class="info_center">
                <div class="info_img">
                    <img src="/static/default/head_img.png" alt="" />
                </div>
                <div class="info_detail">
                    <div class="flex_item">
                        <span>nickname ：</span>
                        <span>{{ userInfo.nick_name }}</span>
                    </div>
                    <!-- <div class="flex_item">
                             <span>分组 ：</span>
                             <span>IM客服</span>
                         </div> -->
                    <div class="flex_item">
                        <span>sex ：</span>
                        <span>
                            <el-select
                                size="mini"
                                v-model="userInfo.user_sex"
                                placeholder="please select"
                            >
                                <el-option label="male" :value="1"></el-option>
                                <el-option label="female" :value="2"></el-option>
                            </el-select>
                        </span>
                    </div>
                    <div class="flex_item">
                        <span>Q  Q ：</span>
                        <span>
                            <el-input
                                size="mini"
                                v-model="userInfo.user_qq"
                                placeholder="Please enter the QQ"
                            ></el-input>
                        </span>
                    </div>
                    <div>lastlogin ：{{ userInfo.update_time }}</div>
                    <el-button
                        class="save_user_info"
                        @click="saveData"
                        type="primary"
                        >Confirm</el-button
                    >
                </div>
            </section>
        </el-dialog>
    </div>
</template>

<script>
import { profileApi } from "@/apis/index";
export default {
    data() {
        return {
            dialogVisible: true,
            sex: "",
            qqNum: "",
        };
    },
    computed: {},
    methods: {
        closeInfoCenter() {
            this.$emit("closeInfoCenter");
        },
        async saveData() {
            let reqdata = {
                user_sex: this.userInfo.user_sex,
                user_qq: this.userInfo.user_qq,
            };
            if (this.userInfo.user_sex == 2) {
                reqdata.user_sex = "female";
            } else if (this.userInfo.user_sex == 1) {
                reqdata.user_sex = "male";
            } else {
                reqdata.user_sex = "";
            }

            const { data: res } = await profileApi(reqdata);
            this.$toast(res.msg);
            this.$emit("closeInfoCenter");
        },
    },
    components: {},
    created() {},
    mounted() {},
};
</script>
<style lang="scss" scoped>
.info_center {
    display: flex;
    height: 256px;
    background: url("../../assets/img/center.jpg") no-repeat;
    // background-position-y: 67px;
    .info_img {
        display: flex;
        align-items: center;
        img {
            margin-left: 40px;
            width: 45px;
        }
    }
    .info_detail {
        margin-top: 30px;
        margin-left: 10px;
        .flex_item {
            display: flex;
            margin-bottom: 10px;
        }
    }
    .el-input {
        width: 200px;
    }
}
::v-deep.el-select .el-input.is-focus .el-input__inner {
    border-color: #dcdfe6;
}
::v-deep.el-select .el-input__inner:focus {
    border-color: #dcdfe6;
}
::v-deep.el-input.is-active .el-input__inner,
.el-input__inner.el-input__inner:focus {
    border-color: #dcdfe6;
    outline: none;
}

.save_user_info {
    margin-top: 30px;
    margin-left: 50px;
}
</style>