<template>
  <div id="J_prismPlayer"></div>
</template>

<script>
export default {
  data() {
    return {

    };
  },
  props: {
    source: {
      type: String,
      required: true
    }
  },
  computed: {},
  methods: {
    initAliVideo() {
      let that = this
      this.$nextTick(()=>{
        var player = new Aliplayer({
        id: 'J_prismPlayer',
        autoplay:true,
        source: that.source,//播放地址，可以是第三方直播地址，或阿里云直播服务中的拉流地址。
        isLive: true,//是否为直播播放。
      }, function (player) {
        console.log('The player is created.')
      });
      })
   
    }
  },
  components: {},
  created() {

  },
  mounted() {
    this.initAliVideo()
  }
};
</script>
<style lang="scss" scoped></style>