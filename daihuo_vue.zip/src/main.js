import Vue from "vue";
import App from "./App.vue";
import router from "./router";
import store from "./store";
import 'element-ui/lib/theme-chalk/index.css';
import "./assets/css/global.scss";
import "./assets/css/global_media.scss";

import "./assets/layui/layui.css";
import "./assets/fonts/iconfont.css";

import mixins from "@/tools/mixins";
import Toasts from "@/components/Toast/toast.vue";
import upload from '@/tools/upload'
import '@/tools/drag.js'
upload.defaults.baseURL='/api'

// import axios from './tools/http'
// if (process.env.NODE_ENV != 'development') axios.defaults.baseURL = 'https://xxx.com'
// upload.defa

Vue.prototype.$upload = upload
const Toast = {
  install: function (Vue) {
    // 创建一个Vue的“子类”组件
    const ToastConstructor = Vue.extend(Toasts);
    // 创建一个该子类的实例,并挂载到一个元素上
    const instance = new ToastConstructor();
    // 将这个实例挂载到动态创建的元素上,并将元素添加到全局结构中
    instance.$mount(document.createElement("div"));
    document.body.appendChild(instance.$el);

    // 在Vue的原型链上注册方法，控制组件
    Vue.prototype.$toast = (msg, duration = 1500) => {
      instance.message = msg;
      instance.visible = true;
      setTimeout(() => {
        instance.visible = false;
      }, duration);
    };
  },
};
import viewImg from '@/components/Toast/bigImg.vue'
const viewImgs = {
  install: function (Vue) {
    // 创建一个Vue的“子类”组件
    const viewImgConstructor = Vue.extend(viewImg);
    // 创建一个该子类的实例,并挂载到一个元素上
    const instance = new viewImgConstructor();
    // 将这个实例挂载到动态创建的元素上,并将元素添加到全局结构中
    instance.$mount(document.createElement("div"));
    document.body.appendChild(instance.$el);
    // 在Vue的原型链上注册方法，控制组件
    Vue.prototype.$bigImg = (src) => {
      instance.img = src;
      instance.visible = true;
    };
  },
};
import VueLuckyCanvas from '@lucky-canvas/vue'
Vue.use(VueLuckyCanvas)
// Vue.components('LuckyWheel', LuckyWheel)
// import '@/assets/fonts/iconfont.css'
import {
  Carousel,
  CarouselItem,
  Upload,
  Button,
  Image,
  Icon,
  Badge,
  Dialog,
  Tabs,
  TabPane,
  Form,
  FormItem,
  Input,
  Select,
  Option,
  Loading,
  Table,
  TableColumn,
  Pagination,
  Tag
} from "element-ui"; // 按需引入element-ui
Vue.use(Carousel);
Vue.use(CarouselItem);
Vue.use(Upload);
Vue.use(Button);
Vue.use(Icon);
Vue.use(Image); // 图片
Vue.use(Badge); // 图片
Vue.mixin(mixins);
Vue.use(Toast);
Vue.use(Dialog);
Vue.use(Tabs);
Vue.use(TabPane);
Vue.use(Form);
Vue.use(FormItem);
Vue.use(Input);
Vue.use(Select);
Vue.use(Option);
Vue.use(Loading);
Vue.use(Table);
Vue.use(TableColumn);
Vue.use(Tag);
Vue.use(Pagination);
Vue.use(viewImgs);

Vue.config.productionTip = false;

new Vue({
  router,
  store,
  render: (h) => h(App),
}).$mount("#app");
