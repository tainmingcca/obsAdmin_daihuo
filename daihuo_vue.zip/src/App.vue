<template>
  <div id="app">
    <CommonHeader />
    <router-view />
    <FrireWork v-if="showFireWoek" />
    <RedRain v-if="showRedRain" />
    <RedRainRes v-if="showRedRainRes"  @closeRedRainres = "closeRedDialog"/>
  </div>
</template>

<script>
import { indexApi , createRedRainApi} from "@/apis/index.js";
import { EventBus } from "@/tools/EventBus";
EventBus.$on("sendDanMu", (data) => {
  let marquee = document.createElement("marquee");
  marquee.setAttribute("id", "danmu");
  marquee.className = "Barrage";
  marquee.setAttribute("direction", "left");
  marquee.setAttribute("scrollamount", "10");
  marquee.setAttribute("loop", "2");
  marquee.innerHTML = data;
  marquee.addEventListener("onfinish", () => {});
  document.getElementById("app").append(marquee);
});
export default {
  data() {
    return {
      showFireWoek:false,
      showRedRain:false,
      jscode:null,
      showRedRainRes:false
    }
  },
  methods: {
    closeRedDialog () {
      this.showRedRainRes = false
    },
    getClientType() {
      var sUserAgent = navigator.userAgent.toLowerCase();
      var bIsIpad = sUserAgent.match(/ipad/i) == "ipad";
      var bIsIphoneOs = sUserAgent.match(/iphone os/i) == "iphone os";
      var bIsMidp = sUserAgent.match(/midp/i) == "midp";
      var bIsUc7 = sUserAgent.match(/rv:1.2.3.4/i) == "rv:1.2.3.4";
      var bIsUc = sUserAgent.match(/ucweb/i) == "ucweb";
      var bIsAndroid = sUserAgent.match(/android/i) == "android";
      var bIsCE = sUserAgent.match(/windows ce/i) == "windows ce";
      var bIsWM = sUserAgent.match(/windows mobile/i) == "windows mobile";
      if (
        bIsIpad ||
        bIsIphoneOs ||
        bIsMidp ||
        bIsUc7 ||
        bIsUc ||
        bIsAndroid ||
        bIsCE ||
        bIsWM
      ) {
        this.$store.commit("getBodyWidth", 750);
        this.$store.commit("getClientType", "app");
      } else {
        this.$store.commit("getBodyWidth", 1080);
        this.$store.commit("getClientType", "pc");
      }
    },
    getKefuDialog () {
 let body = document.getElementsByTagName("body")[0]
      this.jscode= this.jscode.substr(8)
        this.jscode= this.jscode.substr(0, this.jscode.length-9);
        let scriptTag = document.createElement("script");
        scriptTag.innerHTML = this.jscode
       body.append(scriptTag)
    }
  },
  mounted() {
    this.getClientType();
    let that = this;
    window.onresize = function () {
      let bodyWidth = document.getElementById("app").clientWidth;
      that.$store.commit("getBodyWidth", bodyWidth);
    };
    EventBus.$on("toast", (msg) => {
      this.$toast(msg);
    });
         EventBus.$on('sendFireWork',(msg)=>{
      if ( this.showFireWoek== true) {
        return false // 防止重复播放烟花
      }else {
        this.showFireWoek = true
        setTimeout(()=>{
        this.showFireWoek = false
        },10000)
      }
    })


         EventBus.$on('sendRedRain',(msg)=>{
      if ( this.showRedRain== true) {
        return false // 
      }else {
        this.showRedRain = true
        setTimeout( async()=>{
        this.showRedRain = false
        let data = this.$store.state.catchRedNum
        if (data.length != 0) {
           let num = 0
            data.forEach(item=>{
            num= num+=Number(item)
            })
            let reqdata = {
              money:num.toFixed(2)
            }
  
          const {data:res } = await createRedRainApi(reqdata)
          if (res.code == 200) {
            this.showRedRainRes = true
          }
        }
        },10*1000)
      }
    })



  },
  components:{
    FrireWork: ()=>import('@/components/FrireWork.vue'),
    RedRain: ()=>import('@/components/RedRain.vue'),
    RedRainRes: ()=>import('@/components/diaLog/redRainRes.vue'),
    CommonHeader: ()=>import('@/components/commonHeader.vue')
  },
  created() {

    indexApi().then(({ data: res }) => {
      if (res.code == 200) {
		  console.log('请求index成功',res.data);
        EventBus.$emit('openVideo',res.data.roomInfo )
        this.$store.dispatch('getQQApi')
		  if (res.data.goodsInfo) {
		  		 res.data.goodsInfo.status = 1
		  }
        this.$store.commit("addYkToken", res.data);
         require("@/tools/socket");
        this.$store.commit("getDjsTime", res.data.userInfo.djs_time);
        this.$store.dispatch("getFriendList");
        document.title = res.data.roomInfo.room_name;
        let meta1 = document.createElement("meta");
        meta1.setAttribute("name", "description");
        meta1.setAttribute("content", `${res.data.roomInfo.room_keywords}`);
        document.getElementsByTagName("head")[0].append(meta1);
        let meta2 = document.createElement("meta");
        meta2.setAttribute("name", "keywords");
        meta2.setAttribute("content", `${res.data.roomInfo.room_desc}`);
        document.getElementsByTagName("head")[0].append(meta2);
        if (res.data.roomInfo.js_code) {
        this.jscode = res.data.roomInfo.js_code
        this.getKefuDialog()
        }
      }
    });
    
  },

};
</script>

<style lang="scss">
#app {
  width: 100%;
  height: 100%;
}
</style>
