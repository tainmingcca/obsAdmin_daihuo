import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'index2',
    component: () => import(/* webpackChunkName: "index2" */ '@/views/index2.vue')
  },
  {
    path: '/login',
    name: 'login',
    component: () => import(/* webpackChunkName: "login" */ '@/views/login.vue')
  },
  {
    path: '/register',
    name: 'register',
    component: () => import(/* webpackChunkName: "register" */ '@/views/register.vue')
  },
  {
    path: '/yssm',
    name: 'yssm',
    component: () => import(/* webpackChunkName: "yssm" */ '@/views/yssm.vue')
  },
  {
    path: '/yszc',
    name: 'yszc',
    component: () => import(/* webpackChunkName: "yszc" */ '@/views/yszc.vue')
  },
  {
    path: '/yhxx',
    name: 'yhxx',
    component: () => import(/* webpackChunkName: "yhxx" */ '@/views/yhxx.vue')
  },

]

const router = new VueRouter({
  routes
})

export default router
