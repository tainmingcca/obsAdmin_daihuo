import axios from '@/tools/http'
export const indexApi = () => {return axios.get('/api/index')} 
export const getOnlineInfoApi = () => {return axios.get('/api/getOnlineUser')} 
export const getHdMsgApi = () => {return axios.get('/api/get_hdmsg')} 
export const getFriendListApi = () => {return axios.get('/api/im_friendList')} 
export const getHistoryMsgApi = (data) => {return axios.get('/api/im_historyMsg', {params: data})} 
export const sendHdMsgApi = (data) => {return axios.post('/api/send_hdMsg',data)}  // content robotId isDanmu
export const sendImMsgApi = (data) => {return axios.post('/api/im_sendMsg',data)}  // friend_id content msg_type
export const loginApi = (data) => {return axios.post('/api/login',data)}  // friend_id content msg_type
export const regApi = (data) => {return axios.post('/api/reg',data)}  // friend_id content msg_type
export const logOutApi = () => {return axios.get('/api/logOut')}
export const getOssApi = (path) => {return axios.post(`/api/get_oss_policy/${path}`)}  // friend_id content msg_type
export const getNavApi = (data) => {return axios.get('/api/get_nav', {params: data})} //  kcb product service caijing
export const getTeacherListApi = (data) => {return axios.get('/api/teacherList', {params: data})} //  kcb product service caijing
export const zanTeacherApi = (data) => {return axios.get('/api/zanTeacher', {params: data})} //  kcb product service caijing
export const editPwdApi = (data) => {return axios.post(`/api/editPass`,data)}  // pwd pwd1 pwd2
export const profileApi = (data) => {return axios.post(`/api/profile`,data)}  // pwd pwd1 pwd2
export const contextMenuApi = (data) => {return axios.post(`/api/contextMenu`,data)}  // jinyan pingb del pass
export const getWelcomeMsgApi = () => {return axios.get('/api/im_setWelcomeMsg')}
export const setWelcomeMsgApi = (data) => {return axios.post(`/api/im_setWelcomeMsg`,data)}  //content
export const getFastListgApi = () => {return axios.get('/api/im_getKjhf')}
export const addFastListgApi = (data) => {return axios.post(`/api/im_addKjhf`,data)}  //content
export const delHistoryMsgApi = (data) => {return axios.get('/api/im_delKjhf', {params: data})}  // id
export const getTurnTableInfoApi = (data) => {return axios.get('/api/getTurnTableInfo')}  // 获取大转盘信息
export const luckDrawApi = (data) => {return axios.post(`/api/luckDraw`,data)}  //content
export const getQQApi = () => {return axios.get('/api/getQQ')}
export const sendBalloonApi = (data) => {return axios.get('/api/sendBalloon', {params: data})} //  更新用户积分
export const sendCodeApi = (data) => {return axios.get('/api/sendSms', {params: data})} //  获取验证码
export const sendMusicApi = (data) => {return axios.get('/api/sendMusic', {params: data})} //  发送语音
export const SingListApi = (data) => {return axios.get('/api/SingList', {params: data})} //  签到列表
export const getUserSignCountApi = (data) => {return axios.get('/api/getUserSignCount', {params: data})} //  签到列表
export const createSignApi = (data) => {return axios.post(`/api/createSign`,data)}  //本期签到次数
export const userSingListApi = (data) => {return axios.get('/api/userSingList', {params: data})} // 签到记录
export const createUserRedApi = (data) => {return axios.get('/api/createUserRed', {params: data})} // 获取注册红包
export const sendRedRainApi = (data) => {return axios.get('/api/sendRedRain', {params: data})} // 发布红包雨
export const createRedRainApi = (data) => {return axios.post(`/api/createRedRain`,data)}  //本期签到次数
export const getGoodsDetailApi = (data) => {return axios.get('/api/get_goods', {params: data})} // 商品详情
export const logiSticsApi = (data) => {return axios.post(`/api/logiStics`,data)}  //快递WW
export const editFastListgApi = (data) => {return axios.post(`/api/im_editKjhf`,data)}  //content
export const sendGroupMsgApi = (data) => {return axios.post(`/api/sen_group_msg`,data)}  // 群发
// robotId
// content