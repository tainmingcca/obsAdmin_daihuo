// 引入 axios
import axios from 'axios'
import store from '@/store/index'
const service = axios.create(
  {
    headers: {
      // 使用 ; 分割处理后台无法处理多部分请求的原因
      'Content-Type': 'multipart/form-data; boundary = ----WebKitFormBoundaryqWXfAiLxupfbwiVb'
    }
  }
)
//请求拦截器
service.interceptors.request.use(
  config => {
    // 阻止 axios 自动将 数据转换成 JSON
    transformRequest: [function (data) { return data }]
    if (store.state.utoken) {
      config.headers.common.usertoken = store.state.utoken
  } else {
      config.headers.common.usertoken = store.state.yktoken
  }

    return config
  },
  error => {
    return Promise.reject(error)
  }
)

// 将 封装好的请求方法暴露出去 供 main 文件使用
export default service