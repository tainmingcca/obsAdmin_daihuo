import { mapMutations, mapState } from "vuex";
import {
  getOssApi,
} from "@/apis/index.js";
const mixin = {
  computed: {
    ...mapState(["bodyWidth", "mobileChat", "utoken", "yktoken", "isScroll", "userData", "hdMsgList", "chatFriendList", "chatInfo", "historylist", "isShowChat", "onLineData","qqList"]),
    bannerList() {
      return this.userData.bannerList ? this.userData.bannerList : new Array();
    },
    goodsInfo() {
      return this.userData.goodsInfo || null;
    },
    robotList() {
      return this.userData.robotList ? this.userData.robotList : new Array();
    },
    token() {
      return this.utoken ? this.utoken : this.yktoken;
    },
    roomInfo() {
      return this.userData.roomInfo ? this.userData.roomInfo : new Object();
    },
    userInfo() {
      return this.userData.userInfo ? this.userData.userInfo : new Object();
    },
  },

  methods: {
    examineFileType(file) {
      var temp = file.raw.size / (1024 * 1024);
      temp = temp.toFixed(2);
      const fileType = file.raw.type;
      if (!fileType.includes("image"))
        return this.$toast(this.$t("违规格式") + `${file.raw.name}`);
      if (temp > 10) return this.$toast(this.$t("照片大小限制为10M"));
    },
    emotion(res) {
      let word = res.replace(/\#|\;/gi, "");
      const list = ["微笑", "撇嘴", "色", "发呆", "得意", "流泪", "害羞", "闭嘴", "睡", "大哭", "尴尬", "发怒", "调皮", "龇牙", "惊讶", "难过", "酷", "囧", "抓狂", "吐", "偷笑", "愉快", "白眼", "傲慢", "饿", "困", "惊恐", "汗", "憨笑", "悠闲", "努力", "骂", "疑问", "嘘", "晕", "疯", "衰", "骷髅", "敲打", "再见", "擦汗", "抠鼻", "鼓掌", "糟糕", "坏笑", "左哼哼", "右哼哼", "打哈欠", "鄙视", "委屈", "快哭了", "阴险", "亲亲", "吓", "可怜", "菜刀", "西瓜", "啤酒", "篮球", "乒乓", "咖啡", "美食", "动物", "鲜花", "凋谢", "示爱", "爱心", "心碎", "生日", "闪电", "炸弹", "刀", "足球", "瓢虫", "便便", "月亮", "太阳", "礼物", "拥抱", "赞", "踩", "握手", "胜利", "抱拳", "勾引", "拳头", "差劲", "爱你", "NO", "OK", "情侣", "飞吻", "蹦哒", "颤抖", "怄气", "跳舞", "磕头", "回头", "跳绳", "挥手",
      ];
      let index = list.indexOf(word);
      let src = require(`../assets/emoji/${index}.gif`);
      return `<img src=${src} align="middle" alt="">`;
    },
    async getOssSrc(file, type) {
      // const { data: res } = await getOssApi(type);
      const formData = new FormData();
      formData.append("file", file.raw);
      formData.append("dir", type);
      const { data: res } = await this.$upload.post('/upload', formData);
      return res.data.src;
      // formData.append("policy", res.data.policy);
      // formData.append("OSSAccessKeyid", res.data.accessid);
      // formData.append("signature", res.data.signature);
      // formData.append("success_action_status", 200);
      // formData.append("key", res.data.dir + file.name);
      // formData.append("file", file.raw);
      // await this.$upload.post(res.data.host, formData);
      // return res.data.host + "/" + res.data.dir + file.name;
    }
  },
};
export default mixin;
