import axios from 'axios'
// 序列化 发送请求的数据
import qs from 'qs'
// 引入 路由
import router from '@/router/index'
// 引入store中的数据
import store from '@/store/index'



axios.interceptors.request.use(config => {
    // 通过在请求头内加入Content-Type解决后台接收不到数据问题
    // config.headers['Content-Type'] = 'application/x-www-form-urlencoded'
    config.transformRequest = data => qs.stringify(data)
    if (store.state.utoken) {
        config.headers.common.usertoken = store.state.utoken
    } else {
        config.headers.common.usertoken = store.state.yktoken
    }
    // 请求统一传递参数
    return config
}, error => {
    console.log(error.message)
    return Promise.reject(error)
})

// axios设置响应拦截器
axios.interceptors.response.use(config => {
    return config // 拦截处理响应结果，直接返回需要的数据
}, err => {
    // 给出提示 询问是否跳转登录页
    if (err.response.status === 401) {
        localStorage.clear()
        location.reload()
    }
    if (err.response.status === 404) {
        localStorage.clear()
        location.href = 'https://www.baidu.com/'
    }
})
// 向外暴露 二次封装的 axios
export default axios