import Vue from 'vue'
import Vuex from 'vuex'
Vue.use(Vuex)
import { getHdMsgApi, getFriendListApi, getHistoryMsgApi, logOutApi, contextMenuApi, getQQApi } from '@/apis/index.js'
import { EventBus } from "@/tools/EventBus";

export default new Vuex.Store({
  state: {
    bodyWidth: 1080,
    mobileChat: false,
    welcomePng: require('@/assets/img/welcome.png'),
    isShowChat: false, // 聊天窗口
    audioSrc: require('@/assets/audio/messageAlert.mp3'), // 消息提示音
    yktoken: localStorage.getItem('yktoken') || "",
    utoken: localStorage.getItem('utoken') || "",
    isScroll: false, // 来消息是否滚动
    onLineData: new Object, // 在线人数
    userData: new Object,
    hdMsgList: [], // 互动消息记录
    chatFriendList: [], // 会话列表
    historylist: [], // 历史消息记录
    chatInfo: { id: 0 },
    djs_time: "",
    qqList:[],
    clientType: "pc",
    catchRedNum:[], // 缓存红包
  },
  mutations: {
    clearHdMsgList(state) {
      state.hdMsgList = []
    },
    // 获取body宽度
    getBodyWidth(state, widht) {
      state.bodyWidth = widht
    },
    // 获取客户端类型
    getClientType(state, type) {
      state.clientType = type
    },
    // 更新红包个数
    getCatchRedNum (state,data) {
      if (data.type == 1) {
        state.catchRedNum.push(data.item)
      }else {
        state.catchRedNum = []
      }
    },
	// 更新商品信息 
	upDateGoods (state,data) {
		state.userData.goodsInfo = data
	},

    // 是否滚动
    changeScroll(state) {
      state.isScroll = !state.isScroll
    },
    // 展示移动端聊天
    showMobileChat(state, status) {
      state.mobileChat = status
    },
    // 聊天弹窗
    getIsShowChat(state, status) {
      state.isShowChat = status;
    },
    // 登录后获取token 持久化动态存储token
    addUserToken(state, data) {
      state.utoken = data
      window.localStorage.setItem('utoken', state.utoken)
      //location.reload()
    },
    // 登录后获取token 持久化动态存储token
    addYkToken(state, data) {
      if (!state.utoken) {
        state.yktoken = data.userInfo.sess_id
        window.localStorage.setItem('yktoken', state.yktoken)
      }
      state.userData = data
    },
    changeTeacherImg(state, data) {
      state.userData.teacherImg = data;
    },
    getDjsTime(state, data) {
      state.djs_time = data
    },
    // 退出登录
    clearLocal(state) {
      localStorage.removeItem("utoken");
      location.reload()
      state.utoken = ""
    },
    // 获取互动历史消息
    getHdMsgList(state, data) {
      state.hdMsgList = data
      EventBus.$emit('updateHdMsgScroll') // 更新滚动条
    },
    // 动态添加互动消息
    addHdMsg(state, data) {
      state.hdMsgList.push(data)
    },
    // 动态添加历史消息
    addHistoryMsg(state, data) {
      state.historylist.push(data)
    },

    readMsg(state, data) {
      let mySendList = state.historylist.filter(item => item.send_uid != data.send_uid)
      if (mySendList.length > 0) {
        mySendList.forEach(item => item.is_read = 1)
      }
    },


    // 获取会话列表
    getChatFriendList(state, data) {
      state.chatFriendList = data
    },
    // 获取聊天对象
    getChatInfo(state, data) {
      state.chatInfo = data
      let chatData = state.chatFriendList.find(item => item.id == data.id)
      if (chatData) chatData.noReadCount = 0
    },
    // 获取历史消息
    getHistorylist(state, data) {
      state.historylist = data
      EventBus.$emit('updateHistoryMsgScroll') // 更新滚动条
      if (state.clientType == 'app') {
        EventBus.$emit('updateHistoryMsgScrollByApp') // 更新滚动条
      }
    },
    mergeHistTotyList(state, data) {
      state.historylist = [...data, ...state.historylist]
    },
    // 动态添加更新会话列表
    addChatFriendList(state, data) {
      let chatData = state.chatFriendList.find(item => item.id == data.send_uid)
      if (!chatData) {
        let chatObj = new Object
        chatObj.head_img = data.send_headimg
        chatObj.noReadCount = 1
        chatObj.id = data.send_uid
        chatObj.is_online = 1
        chatObj.sign = ""
        chatObj.nick_name = data.send_nickname
        state.chatFriendList.unshift(chatObj)
      } else {
        let index = state.chatFriendList.findIndex(item => item.id == data.send_uid)
        // 如果会话列表存在 判断有没和他聊天 如果没有在聊天增加红点
        if (chatData.id != state.chatInfo.id) {
          chatData.noReadCount = chatData.noReadCount + 1
        }
        state.chatFriendList.splice(index, 1)
        state.chatFriendList.unshift(chatData)
      }
    },
    // 会话列表指定
    topChatList(state, data) {
      let index = state.chatFriendList.findIndex(item => item.id == data.id)
      let chatData = state.chatFriendList.find(item => item.id == data.id)
      state.chatFriendList.splice(index, 1)
      state.chatFriendList.unshift(chatData)
    },
    //  更新在线离线
    updateChatlist(state, data) {
      let chatData = state.chatFriendList.find(item => item.id == data.id)
      if (chatData) {
        chatData.is_online = data.is_online
      }

      let index = state.onLineData.list.findIndex(item => item.id == data.id)
      if (!data.is_online) {
        state.onLineData.totalUser = state.onLineData.totalUser - 1
        if (index !== 1) {
          state.onLineData.list.splice(index, 1)
        }
      } else {
        let randomNum = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
        state.onLineData.totalUser = state.onLineData.totalUser + randomNum(1,11)
        let onLineItem = state.onLineData.list.find(item => item.id == data.id)
        if (onLineItem) {
          state.onLineData.list.splice(index, 1)
          state.onLineData.list.unshift(onLineItem)
        } else {
          state.onLineData.list.unshift(data)
        }

      }


    },
    getOnlineData(state, data) {
      state.onLineData = data
    },
    // 从互动消息列表删除
    delMsgFromHistorylist(state, data) {
      let index = state.hdMsgList.findIndex(item => item.id == data)
      state.hdMsgList.splice(index, 1)
    },
    passMsgFn(state, data) {
      let chatItem = state.hdMsgList.find(item => item.id == data.id)
      chatItem.status = 1
    },
    // 获取客服列表
    getqqList (state,data) {
      // console.log(data);
      console.log(data);
      state.qqList = data
    }
  },
  actions: {
    async getHdMsgListApi({ commit }) {
      const { data: res } = await getHdMsgApi()
      commit("getHdMsgList", res.data);
    },
    async getFriendList({ state, commit, dispatch }) {
      const { data: res } = await getFriendListApi()
      commit('getChatFriendList', res.data)
      if (state.userData.userInfo.user_type == 2) {
        commit('getChatInfo', res.data[0]);
        dispatch('getHistoryMsgApi', res.data[0])
      }
    },
    async getHistoryMsgApi({ commit }, item) {
      let reqdata = {
        friend_id: item.id,
        last_time: ''
      }
      const { data: res } = await getHistoryMsgApi(reqdata)
      // 添加历史消息记录
      commit('getHistorylist', res.data.reverse())

    },
    async getHistoryMsgApiByPositioner({ commit, state }, data2) {
      let reqdata = {
        friend_id: data2.chatInfo.id,
        last_time: ''
      }
      const { data: res } = await getHistoryMsgApi(reqdata)
      // 添加历史消息记录
      if (res.code == 200) {
        commit('getHistorylist', res.data.reverse())
        commit('addHistoryMsg', data2.msgData)
      }
    },
    async logOutApi({ commit }) {
      const { data: rse } = await logOutApi()
      commit('clearLocal')
    },
    async delMsg({ commit }, data) {
      let reqdata = {
        id: data.id,
        type: "del"
      }
      const { data: res } = await contextMenuApi(reqdata)
    },
    async passMsg({ commit }, data) {
      let reqdata = {
        id: data.id,
        type: "pass"
      }
      const { data: res } = await contextMenuApi(reqdata)
      if (res.code !== 200) return false
      commit('passMsgFn', data)

    },
    async getQQApi({commit}) {
      const { data: res } = await getQQApi()
      if (res.code == 201) return EventBus.$emit('toast', res.msg)
      commit('getqqList',res.data)
    }
  },
  getters: {
    redcount(state) {
      let num = 0
      state.chatFriendList.forEach(item => {
        num += item.noReadCount
      })
      return num
    }
  },
  modules: {
  }
})
