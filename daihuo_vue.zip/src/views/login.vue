<template>
  <div class="login_view">
    <div class="login_div">
      <div class="login_header">Account login</div>
      <el-input class="wid_input" placeholder="Please enter the account number." v-model="loginForm.user_name">
        <i slot="prefix" class="el-input__icon el-icon-user"></i>
      </el-input>
      <el-input
        type="password"
        class="wid_input"
        placeholder="enter your passwd"
        v-model="loginForm.passwd"
      >
        <i slot="prefix" class="el-input__icon el-icon-lock"></i>
      </el-input>
      <div class="btn_group">
        <div @click="$router.push('/')" class="login_back">Return to the studio</div>
        <div @click="login" class="login_btn">login</div>
      </div>
    </div>
  </div>
</template>

<script>
import { loginApi,indexApi } from "@/apis/index.js";
export default {
  data() {
    return {
      loginForm: {
        user_name: "",
        passwd: "",
      },
    };
  },
  computed: {},
  methods: {
    async login() {
      for (const key in this.loginForm) {
        if (!this.loginForm[key]) return this.$toast("Please enter full information");
      }
      const { data: res } = await loginApi(this.loginForm);
      this.$toast(res.msg);
      if (res.code == 200) {
        this.$store.commit("addUserToken", res.data);
        window.location.href="/";
      }
    },
  },
  components: {},
  created() {},
  mounted() {},
};
</script>
<style lang="scss" scoped>
.login_view {
  height: 100vh;
  background: url("../assets/img/login.jpg") no-repeat center center;
  position: relative;
  .login_div {
    width: 500px;
    height: 350px;
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    background-color: #fff;
    padding: 20px;
    .login_header {
      text-align: center;
      font-size: 18px;
      height: 60px;
    }
    .btn_group {
      width: 70%;
      display: flex;
      margin-left: 75px;
      justify-content: space-between;
      .login_back,
      .login_btn {
        width: 120px;
        height: 50px;
        font-size: 18px;
        line-height: 50px;
        cursor: pointer;
        text-align: center;
        color: #292836;
        border: 1px solid #292836;
      }
      .login_btn {
        background-color: #292836;
        color: #fff;
        font-weight: 700;
        display: flex;
        justify-content: space-around;
      }
    }
    .wid_input {
      width: 70%;
      margin-bottom: 30px;
      margin-left: 75px;
    }
  }
}
</style>
