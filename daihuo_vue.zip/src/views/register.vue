<template>
  <div class="login_view">
    <div class="login_div">
      <div class="login_header">Account registration</div>
      <el-input class="wid_input" placeholder="Login Account (Required)" v-model="regForm.user_name"></el-input>
      <el-input class="wid_input" placeholder="Personal Nickname (Required)" v-model="regForm.nick_name"></el-input>
      <el-input class="wid_input" v-if="roomInfo.is_open_sms == 0"  placeholder="Mobile phone number (required)" v-model="regForm.mobile"></el-input>
      <el-input v-if="roomInfo.is_open_sms == 1" class="wid_input" placeholder="Mobile phone number (required)" v-model="regForm.mobile">
        <template #suffix>
          <div class="send" @click="sendMsg"> {{codeText}}</div>
        </template>
      </el-input>
      <el-input class="wid_input"  v-if="roomInfo.is_open_sms == 1" placeholder="Verification code (Required)" v-model="regForm.code"></el-input>
      <el-input class="wid_input" placeholder="QQ (Required)" v-model="regForm.user_qq"></el-input>
    
      <el-input class="wid_input" type="password" placeholder="Password (Required)" v-model="regForm.passwd"></el-input>
      <el-input class="wid_input" type="password" placeholder="Confirm Password (Required)" v-model="regForm.repasswd"></el-input>
      <el-input class="wid_input redpla" placeholder="Invitation Code (optional)" v-model="regForm.invitation"></el-input>
      <div class="btn_group">
       <div @click="$router.push('/')" class="login_back">Return to the studio</div>
       <div @click="regCount" class="login_btn">register</div>
      </div>
    </div>
     <reg-red @click.native="showregres = true" @closeRegRed="showRegRedDialog = false" v-if="showRegRedDialog"></reg-red>
     <redResult :invitation_url="invlink" :money="money"  v-if="showregres" @close="showregres = false" />
  </div> 
</template>

<script>
import { regApi,sendCodeApi } from "@/apis/index.js";
import RegRed from '@/components/diaLog/regred.vue'

export default {
    data() {
        return {
            regForm: {
                user_name: "",
                nick_name: "",
                passwd: "",
                code:"",
                repasswd: "",
                mobile: "",
                invitation:"",
                user_qq: "",
            },
            lock: false,
            codeLock:false,
            codeTime:60,
            codeText:'send',
            showRegRedDialog:false, // 注册成功展示红包
            showregres:false, // 注册红包
            money:"", // 红包金额
            invcode:"", // 邀请吗
            invlink:"" //邀请链接
        };
    },
    computed: {},
    methods: {
        async regCount() {
           
            // for (const key in this.regForm) {
            //     if (!this.regForm[key])
            //         return this.$toast("请输入完整信息");
            // }
            let reqdata = this.regForm;
            this.lock = true;
            const { data: res } = await regApi(reqdata);
            this.lock = false;
            this.$toast(res.msg);
            if (res.code == 200) {
                this.$store.commit("addUserToken", res.data);
                this.invlink = res.invitation
                this.money = res.money
                this.showRegRedDialog  = true
                // this.showRegRedDialog  = true
            } 
        },
        async sendMsg () {
          let reqdata = {mobile:this.regForm.mobile}
          if (!this.regForm.mobile) return  this.$toast('Please enter your mobile phone number');
          const {data:res} = await sendCodeApi(reqdata)
          if (res.code == 200) {
            if (this.codeLock == true) return
           this.codeLock = true
           this.startCountDown()
          }else {
                return this.$toast(res.msg);
          }
  
        },
        startCountDown () {
          var timer = setInterval(()=>{
              this.codeTime --
              this.codeText = `Resend the message ${this.codeTime} seconds later`
              if (this.codeTime == 0) {
                clearInterval(timer)
                this.codeTime = 60
                this.codeLock = false
                this.codeText = 'send'
              }
          },1000)
        },
    
    },
    components: {
      RegRed,
         redResult: () => import("@/components/diaLog/redResult.vue"),
    },
    created() { },
    mounted() { 
      // console.log();
      this.regForm.invitation = this.$route.query.invitation
    },
};
</script>
<style lang="scss" scoped>
.login_view {
  height: 100vh;
  background: url("../assets/img/register.jpg") no-repeat center center;
  position: relative;
  .login_div {
    width: 500px;
    height: 750px;
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    background-color: #fff;
    padding: 20px;
    .login_header {
      text-align: center;
      font-size: 18px;
      height: 60px;
    }
    .btn_group {
        width: 70%;
        display: flex;
        margin-left: 75px;
        justify-content: space-between;
        .login_back,
        .login_btn{
            width: 120px;
            height: 50px;
            font-size: 16px;
            line-height: 50px;
            cursor: pointer;
            text-align: center;
            color: #292836;
            border: 1px solid #292836;
        }
        .login_btn {
            background-color: #292836;
            color: #fff;
            font-weight: 700;
            display: flex;
            justify-content: space-around;
        }
    }
    .wid_input {
        width: 70%;
        margin-bottom: 30px;
        margin-left: 75px;
    }
  }
}
.send {
  background-color: #292836;
  color: #fff;
  height: 40px;
  margin-right: -8px;
  width: 100px;
  display: flex;
  justify-content: center;
  align-items: center;
  cursor: pointer;
}

</style>