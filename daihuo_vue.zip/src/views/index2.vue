<template>
  <div class="bg_imgs" ref="bgImg" :style="{ background: '#22232D', }">


    <div id="main">
      <div class="main_left">
        <!-- <div class="main_left_top"> -->
        <!-- 视频模块开始 -->
        <div id="shiping_box" class="pore" style="height: 100%;">
          <!-- v-if=" != '' && roomInfo.is_sp_img != 1" -->
          <!-- 阿里播放器 -->
          <ali-player  style="height:100%;" ref="aliPlayer" v-if="showPlayer" :source="zhiboLink"  format="fiv"></ali-player>

          <!-- fiv原生播放器  -->
          <!-- <video class="videosmall" ref="videosmallone" preload="auto" muted autoplay type="rtmp/flv">
            <source src="" />
          </video> -->

          <div v-if="roomInfo.video_url && roomInfo.is_sp_img == 1" style="height: 100%;" id="shiping" :style="{
              background: `url(${roomInfo.shiping_img}) center center / 100% 100% no-repeat `,
            }"></div>

          <div v-if="!roomInfo.video_url" id="shiping" style="height: 100%;">
            <div class="jieshu_tip">
              <img src="../assets/img/xx.png" alt="">
              <span>Dear tourist friends, sorry, your experience class time is over! It is recommended that you click
                login or register to continue listening to the class immediately, so as not to affect your income!
              </span>
            </div>
          </div>

        </div>
        <!-- </div> -->

        <!-- 商品 -->
        <div class="goods" @click="showGoodsDetail = true" v-if="goodsInfo != null && goodsInfo.status != 0">
          <div class="goods_info">

            <img :src="goodsInfo.img" alt="">
            <span class="goods_title">{{ goodsInfo.title }}</span>
            <span class="tips">Explanation on the Way </span>
          </div>
          <div class="price_goods">

            <span class="price">￥{{ goodsInfo.price }}</span>
            <span class="price_gouwu">
              <img src="@/assets/img/gouwu.png" alt="">
            </span>
          </div>
        </div>
      </div>

      <goodsDetail :goodsId="goodsInfo.id" v-if="showGoodsDetail" @closeGoodsDetail="showGoodsDetail = false" />

      <!-- 聊天模块开始 -->
      <chat @openSig="openSign" @openDaZhuanPa="openDaZhuanPan" />
      <!-- /聊天模块结束 -->
    </div>

    <!--5分钟提醒-->
    <div class="marsk" v-if="isShowMask"></div>
    <div class="dialog5minute" v-if="isLoignTip">
      <img src="@/assets/img/qzzc.png" alt="" />
      <div class="absolute">
        <div @click="regMethods" class="item dialog5minute_reg"></div>
        <div @click="loginMethdos" class="item dialog5minute_login"></div>
      </div>
    </div>

    <div id="welcome"></div>

    <!-- 聊天对话框 -->
    <!-- <transition name="bounce"></transition> -->
    <chatDialog :class="isShowChat ? '' : 'bottom_index'" v-if="clientType == 'pc'" />
    <!-- 最小化聊天 -->

    <!-- 首页广告 -->
    <indexDialog v-if="showIndexAd && clientType == 'pc' && userInfo.user_type != 1" @closeIndex="showIndexAd = false" />
    <!-- 签到 -->
    <signIn v-if="showSignIn" @closeSign="showSignIn = false" />
    <!-- 大转盘 -->
    <turnTable @closeTurnTable="closeTurnTables" v-if="showZhuanPan" class="zhuna_pai" />
    <!-- 邀请红包 -->
    <redResult :money="userInfo.red_num" :invitation_url="userInfo.invitation_url" v-if="showRegRedDialog"
      @closeRegRes="showRegRedDialog = false" />

  </div>
</template>

<script>
import { Notification } from "element-ui";
import flvjs from "flv.js";
import { getOnlineInfoApi, getTurnTableInfoApi } from "@/apis/index.js";
import vueSeamlessScroll from 'vue-seamless-scroll'
import { Alert, MessageBox } from "element-ui";
import { mapGetters, mapState } from "vuex";
import { EventBus } from "@/tools/EventBus";
export default {
  data() {
    return {
      isLoignTip: false, // 登录提示
      isShowMask: false, // 遮罩层
      isShowSkin: false, // 换肤
      showPlayer:false,
      showZhuanPan: false,
      showGoodsDetail: false,// 商品详情
      lookTimeEnd: true,
      showRegRedDialog: false,
      showIndexAd: true,
      showSignIn: false,
      zhiboLink:"",
      look_times: "",
      bgc: require("@/assets/img/bg.jpg"),
      time: "",
      look_day: "",
      look_hour: "",
      look_minute: "",
      look_second: "",
      player:null,
    };
  },
  computed: {
    ...mapState(["djs_time", "clientType"]),
    ...mapGetters(["redcount"]),
    skinList() {
      let arr = [];
      for (var i = 1; i < 7; i++) {
        let obj = new Object();
        obj.src = require(`@/assets/img/skin/ys_${i}.jpg`);
        obj.value = require(`@/assets/img/skin/ys_${i}_1.jpg`);
        arr.push(obj);
      }
      return arr;
    },
    defaultOption() {
      return {
        step: 0.2, // 数值越大速度滚动越快
        limitMoveNum: 2, // 开始无缝滚动的数据量 this.dataList.length
        hoverStop: true, // 是否开启鼠标悬停stop
        direction: 1, // 0向下 1向上 2向左 3向右
        openWatch: true, // 开启数据实时监控刷新dom
        singleHeight: 0, // 单步运动停止的高度(默认值0是无缝不停止的滚动) direction => 0/1
        singleWidth: 0, // 单步运动停止的宽度(默认值0是无缝不停止的滚动) direction => 2/3
        waitTime: 1000 // 单步运动停止的时间(默认值1000ms)
      }
    }
  },
  methods: {

    playVido() {
      console.log('testplay');
    },
    init(val) { //这个val 就是一个地址，
        var videoElement = this.$refs.videosmallone; // 获取到html中的video标签
        if (flvjs.isSupported()) {
          this.player = flvjs.createPlayer( //创建直播流，加载到DOM中去
            {
              type: "flv",
              url: val, //你的url地址
              isLive: true, //数据源是否为直播流
              hasAudio: true, //数据源是否包含有音频
              hasVideo: true, //数据源是否包含有视频
              enableStashBuffer: true, //是否启用缓存区
            },
            {
              enableWorker: false, //不启用分离线程
              enableStashBuffer: false, //关闭IO隐藏缓冲区
              autoCleanupSourceBuffer: true, //自动清除缓存
              lazyLoad: false,
            }
          );
          this.player.attachMediaElement(videoElement); //放到dom中去
          this.player.load();//准备完成
          //!!!!!!这里需要注意，有的时候load加载完成不一定可以播放，要是播放不成功，用settimeout 给下面的this.player.play() 延时几百毫秒再播放
          var that = this
          setTimeout(() => {
            that.player.play();//播放
          }, 800);
        }
    },

    // 关闭红包
    closeRedRegs() {
      this.showRegRedDialog = false;
    },

    // 关闭抽奖
    closeTurnTables() {
      this.showZhuanPan = false;
    },
    // 打开签到
    openSign() {
      this.showSignIn = true;
    },
    // 打开大转盘
    async openDaZhuanPan() {
      if (this.userInfo.isYk) {
        MessageBox.alert("Register to participate in the lucky draw", "Tips", {
          confirmButtonText: "Contact us",
          callback: async () => {
            this.$store.dispatch("getQQApi");
          },
        });
      } else {
        const { data: res } = await getTurnTableInfoApi();
        if (res.code == 201) return this.$toast(res.msg);
        this.showZhuanPan = true;
      }
    },


    // 聊天弹窗
    showChatMethods() {
      this.isShowChat = true;
    },

    openRegDialog() {
      if (this.roomInfo.is_open_reg == 0) {
        MessageBox.alert("Please contact customer service to register", "Tips", {
          confirmButtonText: "confirm",
          showClose: false,
          callback: (action) => {
            this.lookTimeEnd = false;
          },
        });
      } else {
        EventBus.$emit('opReg')
      }
    },
    // 重载页面
    reloadPage() {
      window.location.reload();
    },
    // 换肤
    checkSkin(value) {
      // this.$nextTick (()=>{
      // this.$refs.bgImg.style.backgroundImage = value
      // })
      this.bgc = value;
    },
    // 以下方法都是弹窗操作

    // 展示注册红包收益弹窗

    // 修改密码


    getLookTime(seconds) {
      let [day, hour, minute, second] = ["00", "00", "00", "00"];
      var timer = setInterval(() => {
        if (seconds < 0) {
          this.roomInfo.video_url = "";
          clearInterval(timer);
        } else {
          day = Math.floor(seconds / (60 * 60 * 24));
          if (day < 10) day = `0${day}`;
          hour = Math.floor(seconds / (60 * 60)) - day * 24;
          if (hour < 10) hour = `0${hour}`;
          minute = Math.floor(seconds / 60) - day * 24 * 60 - hour * 60;
          if (minute < 10) minute = `0${minute}`;
          second =
            Math.floor(seconds) -
            day * 24 * 60 * 60 -
            hour * 60 * 60 -
            minute * 60;
          if (second < 10) second = `0${second}`;
          this.look_day = day
          this.look_hour = hour
          this.look_minute = minute
          this.look_second = second
          // this.look_times = `您可以观看时长：${day}天 <div class="red_div">${hour}</div> : <div>${minute}</div> :<div>${second}</div>`;
          seconds--;
        }
      }, 1000);
    },
  },
  components: {
    chatDialog: () => import("@/components/diaLog/chatDialog2.vue"),
    chat: () => import("@/components/chat2.vue"),
    userInfo: () => import("../components/userInfo/userInfo.vue"),
    turnTable: () => import("../components/turnTable.vue"),
    indexDialog: () => import("../components/diaLog/indexDialog.vue"),
    signIn: () => import("../components/diaLog/signIn.vue"),
    goodsDetail: () => import("../components/diaLog/goodsDetail.vue"),
    RegRed: () => import("@/components/diaLog/regred.vue"),
    redResult: () => import("@/components/diaLog/redResult.vue"),
    aliPlayer:()=>import('@/components/videoPlayer.vue'),
    vueSeamlessScroll,
  },
  created() {
    this.bgc = this.roomInfo.default_bg
      ? this.roomInfo.default_bg
      : require("@/assets/img/bg.jpg");
    getOnlineInfoApi().then(({ data: res }) => {
      this.$store.commit("getOnlineData", res.data);
      if (res.code == 200) {
        this.$store.dispatch("getHdMsgListApi");
      }
    });
  },
  mounted() {


    if (!this.utoken && this.clientType == "pc") {
      MessageBox.confirm("Log in for more information. Are you logged in now", "Tips", {
        confirmButtonText: "confirm",
        cancelButtonText: "cancel",
        type: "warning",
      }).then(() => {

        EventBus.$emit('openLogin')

      });
    }

    EventBus.$on('openVideo', (roomInfo) => {

if (roomInfo.video_url != "" && roomInfo.is_sp_img != 1) {
  // if (this.clientType != 'pc') {
  //   this.zhiboLink =   roomInfo.video_url.slice(0,roomInfo.video_url.length - 3) + 'm3u8'  
  // }else {
  //   this.zhiboLink  =  roomInfo.video_url
  // }
  this.zhiboLink  =  roomInfo.video_url

  console.log('直播URL', this.zhiboLink );
  this.showPlayer = true
}

})



  },
  watch: {
    "$store.state.djs_time": function (newVal, oldVal) {
      if (newVal) {
        this.getLookTime(newVal);
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.goods_info {
  position: relative;

  .tips {
    position: absolute;
    left: 10px;
    top: 10px;
    background-color: #FF3030;
    color: #fff;
    width: 60px;
    height: 30px;
    border-radius: 5px;
    display: flex;
    justify-content: center;
    align-items: center;
    cursor: pointer;
  }
}

.goods_title {
  width: 235px;
  height: 40px;
  background: linear-gradient(to bottom, rgba(0, 0, 0, 0), rgba(0, 0, 0, .8));
  position: absolute;
  left: 0;
  bottom: 0;
  padding-top: 10px;
  color: #fff;
  text-align: center;
}

.pulse {
  animation: pulse 0.7s linear infinite;
}

@keyframes pulse {
  0% {
    transform: scale(1);
  }

  90% {
    transform: scale(0.8);
  }

  100% {
    transform: scale(1);
  }
}

.youke {
  width: 50px;
  height: 50px;
  margin-top: -10px;
  margin-right: 10px;
}

.scroll_styles::-webkit-scrollbar {
  width: 7px;
  height: 7px;
  background-color: #f5f5f5;
}

.pore {
  position: relative;
}

/*定义滚动条轨道 内阴影+圆角*/
.scroll_styles::-webkit-scrollbar-track {
  box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
  -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
  border-radius: 10px;
  background-color: #f5f5f5;
}

/*定义滑块 内阴影+圆角*/
.scroll_styles::-webkit-scrollbar-thumb {
  border-radius: 10px;
  box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);
  -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);
  background-color: #c8c8c8;
}

.marsk {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100vh;
  background: rgba(0, 0, 0, 0.5);
  z-index: 99;
}

.dialog5minute {
  width: 624px;
  height: 600px;
  position: absolute;
  top: 15vh;
  left: 30%;
  z-index: 100;
}

.dialog5minute .absolute {
  position: absolute;
  left: 0;
  bottom: 0;
  width: 100%;
}

.dialog5minute .absolute .item {
  width: 50%;
  height: 85px;
  float: left;
}

.drag {
  width: 100px;
  height: 100px;
  position: absolute;
  top: 0;
  left: 0;
  background-color: red;
}


.bg_list {
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  position: relative;
}

.bg_list .item {
  margin: 10px;
  cursor: pointer;
}

.bg_list .item img {
  width: 70px;
  height: 35px;
}

.closeBtn {
  background: #fff;
  font-family: Georgia, "Times New Roman", Times, serif;
  font-size: 20px;
  width: 30px;
  height: 30px;
  display: inline-block;
  border-radius: 50%;
  text-align: center;
  line-height: 30px;
  color: #666;
  position: absolute;
  right: -18px;
  top: -16px;
  cursor: pointer;
}

.flex_box {
  cursor: pointer;
  background-color: #222d31;
  color: #fff;

  img {
    width: 45px;
    height: 45px;
    margin-right: 30px;
  }

  .item {
    padding: 10px;
    border-bottom: 1px solid #3c4049;
    display: flex;
    align-items: center;
    padding-left: 10px;
  }
}

.login_reg {
  width: 95px !important;
  height: 30px !important;
}

.save_desktop {
  font-size: 18px;
  text-align: center;
  cursor: pointer;
  color: #fff;
  font-weight: 600;

  .icon-yunzhuomian {
    font-size: 25px;
    vertical-align: middle;
  }
}

.fn35 {
  font-size: 35px;
  margin-right: 30px;
}

.is_login_f_right {
  color: white;
  display: block;
  width: auto;
  display: flex;
  /* justify-content: space-around; */
  justify-content: flex-end;
  padding-top: 20px;
  padding-right: 35px;
}

.zhuna_pai {
  position: absolute;
  left: 20%;
  top: 22%;
  z-index: 10;
}

.prze_close {
  position: absolute;
  left: 55%;
  top: 25%;
  font-size: 28px;
  color: red;
}

.bottom_index {
  z-index: -99999 !important;
}

.new_header {
  width: 100%;
  background-color: #263049;
  color: #fff;
  height: 30px;
  display: flex;
  justify-content: space-between;
  box-sizing: border-box;
  padding: 0 20px;
  align-items: flex-end;

  .right {
    display: flex;

    .text {
      margin-right: 10px;

    }

    .line {
      margin: 0 10px;
    }
  }
}

.banner_title {
  width: 100%;
  background-color: #1B3F4B;
  height: 30px;
  color: #567CD6;
  display: flex;
  align-items: center;
  border-bottom: 1px solid #E9EAF0;
  box-sizing: border-box;
  padding-left: 10px;
}

.banner_connent {
  display: flex;
  background-color: #1B3F4B;
  height: calc(100% - 30px);

  .text {
    padding: 10px;
    color: #ECE8E8;
    overflow: hidden;
  }

}

#all {
  overflow: auto;
  height: calc(100vh - 334px);
}

#all::-webkit-scrollbar {
  width: 0 !important
}

.user_line_list {
  display: flex;
  align-items: center;
  box-sizing: border-box;
  padding-left: 10px;
}

.user_line {
  display: flex;

  // margin-bottom:10px ;
  .nick_name {
    padding: 5px 10px;
    background: #F36D0E;

  }

  .user_center {
    padding: 5px 10px;
    background: #DD952B;
    cursor: pointer;
  }

}

.times_look {
  display: flex;
  align-items: center;

  .bgc_red_text {
    background-color: #C4412D;
    color: #fff;
    margin: 0 5px;
    width: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    height: 24px;
  }
}

.jieshu_tip {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;

  img {
    width: 150px;
  }

  span {
    color: #AB5938;
    font-size: 18px;
    width: 410px;
  }
}

.img_list {
  width: 200px;
  flex-shrink: 0;
  box-sizing: border-box;
  padding-top: 15px;

  .top {
    display: flex;
    width: 100%;
    justify-content: space-around;
  }

  .bottom {
    display: flex;
    width: 100%;
    justify-content: space-around;
    margin-top: 20px;
  }
}


.goods {
  width: 250px;
  height: 340px;
  border: 2px solid #FF2D2D;
  position: absolute;
  z-index: 99;
  right: 86px;
  bottom: 90px;
  padding: 5px;
  background-color: #fff;

  img {
    width: 235px;
    height: 280px;
  }

  .price_goods {
    margin-top: 15px;
    display: flex;
    align-items: center;
    justify-content: space-between;

    .price {
      color: #FF2D2D;
      font-size: 26px;
      font-weight: 600;
    }

    .price_gouwu {
      width: 30px;
      height: 30px;
      background-color: #FF6363;

      border-radius: 50%;
      position: relative;

      img {
        width: 18px;
        height: 18px;
        position: absolute;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
      }
    }
  }
}
</style>
