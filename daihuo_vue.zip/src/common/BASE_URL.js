export const requstUrl = 'https://zbdhcc.xyz' // 请求URL
export const imgUrl = 'https://zbdhcc.xyz' // 图片 URL
export const getSocketUrl =   ()=> {
    var ishttps = 'https:' == document.location.protocol ? true : false;
    let socketUrl = ""
    let yuming = document.domain
    if (ishttps) {
      socketUrl = `wss://${yuming}/socket.io`;
    } else {
      socketUrl = `ws://${yuming}/socket.io`;
    }
    if (process.env.NODE_ENV === "development") {
      return `wss://zbdhcc.xyz/socket.io`; // 本地调试socket域名
    } else {
      return socketUrl;
    }
}


