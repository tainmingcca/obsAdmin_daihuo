<?php
return [
    'accessid' =>'' ,
    'accesskey' => '',
    'Bucket' => '',
    //'Endpoint' => 'oss-accelerate.aliyuncs.com',
    'Endpoint' => 'oss-cn-zhangjiakou.aliyuncs.com',
    'baseDir'=>'minzhong',
];