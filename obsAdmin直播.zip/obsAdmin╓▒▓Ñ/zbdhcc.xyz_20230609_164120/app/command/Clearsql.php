<?php
declare (strict_types=1);

namespace app\command;

use app\model\ChatMsg;
use app\model\ImMsg;
use app\model\Room;
use app\model\User;
use think\console\Command;
use think\console\Input;
use think\console\input\Argument;
use think\console\input\Option;
use think\console\Output;

class Clearsql extends Command
{
    protected function configure()
    {
        // 指令配置
        $this->setName('clearsql')->setDescription('clearsql');
    }

    //cd /www/wwwroot/admin/ &&  php think clearsql
    protected function execute(Input $input, Output $output)
    {
        //$day = (new Room())->where(['id'=>1])->value('ykbc_day');
        //$day=$day-1;
        $s_date = date("Y-m-d", strtotime("-1day"));
        //清理无效游客
        $userNum = (new User())->whereTime('create_time', '<', $s_date)
            ->where([
                ['user_type', '=', 2],
                ['group_id', '=', 1],
                ['is_robot', '=', 0],
            ])->delete();
        $output->writeln("清除{$s_date}之前无效游客：{$userNum}");

        //清理互动数据
        $chatNum = (new ChatMsg())->whereTime('create_time', '<', $s_date)->delete();
        $output->writeln("清除{$s_date}之前无效互动数据：{$chatNum}");

        //清理聊天数据
        $imNum = (new ImMsg())->whereTime('create_time', '<', $s_date)->delete();
        $output->writeln("清除{$s_date}之前无效聊天数据：{$imNum}");
        
        //重置在线数据
        $res=(new User())->where(true)->update(['is_online'=>0]);
        $output->writeln("重置在线数据:{$res}");
    }


    public function writeLog($file, $data)
    {
        $path = root_path() . 'logs_cli/' . $file;
        $dir = dirname($path);
        if (!is_dir($dir)) {
            mkdir($dir, 0777, true);
        }
        file_put_contents($path, str_repeat("=====", 40) . "\n", FILE_APPEND);
        file_put_contents($path, date("Y-m-d H:i:s") . "\n", FILE_APPEND);
        file_put_contents($path, var_export($data, true) . "\n", FILE_APPEND);
        file_put_contents($path, str_repeat("=====", 40) . "\n\n", FILE_APPEND);
    }
}
