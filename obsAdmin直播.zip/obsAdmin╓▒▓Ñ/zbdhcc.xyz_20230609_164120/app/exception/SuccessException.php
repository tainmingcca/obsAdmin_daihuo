<?php
/**
 * Created by PhpStorm.
 * Driver: 七月
 * Date: 2017/2/12
 * Time: 18:29
 */

namespace app\exception;

/**
 * Class SuccessException
 * 通用参数类异常错误
 */
class SuccessException extends BaseException
{
    public $statusCode = 200;            //  httpCode
    public $errorCode = 0;
    public $msg = "success";
}