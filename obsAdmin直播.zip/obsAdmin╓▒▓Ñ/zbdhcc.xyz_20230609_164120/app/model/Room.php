<?php


namespace app\model;
use think\Model;

class Room extends Model
{
    //public function getLogo
}