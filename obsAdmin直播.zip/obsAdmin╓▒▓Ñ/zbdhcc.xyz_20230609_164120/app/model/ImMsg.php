<?php


namespace app\model;
use think\Model;

class ImMsg  extends Model
{

}