<?php


namespace app\model;

use think\Model;


class User extends Model
{
    public static function onBeforeUpdate($data)
    {
        $modelName = __CLASS__;
        $oldData = $modelName::find($data->id);
        if (strpos($oldData->head_img, 'http') === false && $oldData->head_img != $data->head_img && strpos($oldData->head_img,'head_img.png') === false) @unlink(".{$oldData->head_img}");
    }
    
    
    public function checkToken($token)
    {
        //p($token);
        if (!empty(trim($token))) {
            $userinfo = $this->where(['room_no' => env('room_no'),'sess_id' => $token])->order('id asc')->find();
            if(!empty($userinfo)) return $userinfo;
        }
        //检测同设备5秒内防止重复注册游客
        $userinfo = $this->where([
            'user_type'=>2,
            'group_id'=>1,
            'reg_ip'=>getRealIP(),
            'from_url'=>request()->domain(true),
        ])->whereBetween('create_time',[time()-5,time()])->order('id asc')->find();
        if(!empty($userinfo)) return $userinfo;
        return $this->registerYouKe();
    }
    /**
     * 注册游客
     */
    public function registerYouKe()
    {
        //$roomInfo = (new Room())->where(['room_no' => env('room_no')])->field('room_no,default_bg')->find();
        
        // $usernameCheck = true;
        // do {
        //     $sj = random_int(3333333, 9999999);
        //     $user_name = "guest_" . $sj;
        //     $count = $this->where(['user_name' => $user_name])->count();
        //     if ($count <= 0) $usernameCheck = false;
        // } while ($usernameCheck);
        $sj = getRandCode();
        $nick_name = $sj;
        $user_name = "guest_" . $sj;
        //获取im客服id
        $imInfo = $this->getNextIm();
        $imUid = !empty($imInfo) ? $imInfo->id : 1;
        $qqInfo = $this->getNextQQ();
        $bind_qq = !empty($qqInfo) ? $qqInfo->qq_account : '';
        $userGroupInfo = (new UserGroup())->where(['group_name' => '游客'])->find();
        $clientIp = getRealIP();
        $data = [
            'room_no' => env('room_no'),
            'user_bg' => '',//$roomInfo->default_bg,
            'admin_uid' => $imUid,
            'user_name' => $user_name,
            'nick_name' => $nick_name,
            'head_img' => "/static/default/head_img.png",
            'user_type' => '2',
            'group_id' => $userGroupInfo->id,
            'group_name' => $userGroupInfo->group_name,
            'group_icon' => $userGroupInfo->group_icon,
            'look_time' => time() + $userGroupInfo->look_time * 60,
            'from_url' => request()->domain(true),
            'login_time' => time(),
            'login_ip' => $clientIp,
            'reg_ip' => $clientIp,
            'is_online' => 1,
            'sess_id' => createToken($user_name),
            'bind_qq' => $bind_qq,
            'user_status' => 1,
            'can_sendmsg'=>1,
            'is_robot'=>0
        ];
        $this->save($data);


        //绑定im客服
        //$imInfo = $this->getNextIm();
        //$imUid = !empty($imInfo) ? $imInfo->id : 1;
        if (!empty($imInfo)) (new User())->where(['id' => $imUid])->update(['jd_sort' => $this->id]);
        $this->admin_uid = $imUid;


        //绑定qq客服
        //$qqInfo = $this->getNextQQ();
        //$bind_qq = !empty($qqInfo) ? $qqInfo->qq_account : '';
        if (!empty($qqInfo)) $qqInfo->save(['jd_sort' => $this->id]);
        $this->bind_qq = $bind_qq;
        return $this;
    }

    /**
     * 获取IM客服id
     */
    public function getNextIm()
    {
        $imInfo = $this->where([
            "room_no" => env('room_no'),
            "user_type" => 1,
            "group_id" => 2,
            "user_status" => 1,
            //"is_online" => 1,
            "im_auth" => 1,
        ])->field("id,nick_name,head_img")
            ->order("jd_sort asc,id asc")
            ->find();
            //p($imInfo);
        if (empty($imInfo)) {
            $imInfo = $imInfo = $this->where([
                "room_no" => env('room_no'),
                "user_type" => 1,
                "group_id" => 1,
            ])
                ->cache(true)
                ->field("id,nick_name,head_img")
                ->find();
        }
        return !empty($imInfo) ? $imInfo : [];
    }

    /**
     * 获取qq客服id
     */
    public function getNextQQ()
    {
        $qqInfo = (new Qqkf())
            ->where(["room_no" => env('room_no'), 'is_yx' => 1])
            ->order("jd_sort asc,id asc")
            ->find();
        return !empty($qqInfo) ? $qqInfo : [];
    }
      /**
     * 投注后向上级分润
     * @param int $user_id
     * @param int $money   投注金额
     * @return bool
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function parentCommission($user_id = 1, $money = 0)
    {
        $userInfo = $this->where(['id' => $user_id,'room_no'=>env('ROOM_NO')])->field('id,pid,mobile')->find();
        $pid1['pid']=0;
        $pid2['pid']=0;
        $data = ['type' => 1,'room_no'=>env('ROOM_NO')];
        if (!empty($userInfo['pid'])) {
            $pid1 = $this->where(['id' => $userInfo['pid'],'room_no'=>env('ROOM_NO')])->field('id,pid,red_money,nick_name,mobile')->find();  //上级用户
            $commissionMoney = bcmul($money,0.5,2);
            $data['uid'] = $pid1['id'];
            $data['money'] = $commissionMoney;
            $data['nick_name'] = $pid1->nick_name;
            $data['mobile'] = $pid1->mobile;
            $data['send_mobile'] = $userInfo->mobile;
            $pid1->red_money = bcadd($pid1->red_money,$commissionMoney,2);
            (new BalanceLog())->save($data);
            $pid1->save();
            if ($pid1['pid'] > 0) {
                $pid2 = $this->where(['id' => $pid1['pid'], 'room_no'=>env('ROOM_NO')])->field('id,pid,red_money,nick_name,mobile')->find();  //上上级用户
                $commissionMoney = bcmul($money,0.3,2);
                $data['uid'] = $pid2['id'];
                $data['money'] = $commissionMoney;
                $data['nick_name'] = $pid2->nick_name;
                $data['mobile'] = $pid2->mobile;
                $data['send_mobile'] = $userInfo->mobile;
                $pid2->red_money = bcadd($pid2->red_money,$commissionMoney,2);
                (new BalanceLog())->save($data);
                $pid2->save();
            }
            if ($pid2['pid'] > 0) {
                $pid3 = $this->where(['id' => $pid2['pid1'], 'room_no'=>env('ROOM_NO')])->field('id,pid,red_money,nick_name,mobile')->find();   ///3级用户
                $commissionMoney = bcmul($money,0.2,2);
                $data['uid'] = $pid3['id'];
                $data['money'] = $commissionMoney;
                $data['nick_name'] = $pid3->nick_name;
                $data['mobile'] = $pid3->mobile;
                $data['send_mobile'] = $userInfo->mobile;
                $pid3->red_money = bcadd($pid3->red_money,$commissionMoney,2);
                (new BalanceLog())->save($data);
                $pid3->save();
            }
            return true;
        }
        return true;
    }
}