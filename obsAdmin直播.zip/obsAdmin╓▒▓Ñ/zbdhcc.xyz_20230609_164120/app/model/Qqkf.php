<?php


namespace app\model;

use think\Model;

class Qqkf extends Model
{
    public static function onBeforeUpdate($data)
    {
        $modelName = __CLASS__;
        $oldData = $modelName::find($data->id);
        if (strpos($oldData->qq_icon, 'http') === false && $oldData->qq_icon != $data->qq_icon) @unlink(".{$oldData->qq_icon}");
    }
}