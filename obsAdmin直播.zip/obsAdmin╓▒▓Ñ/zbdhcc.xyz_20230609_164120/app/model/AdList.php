<?php


namespace app\model;


use think\Model;

class AdList extends Model
{
    public static function onBeforeUpdate($data)
    {
        $modelName = __CLASS__;
        $oldData = $modelName::find($data->id);
        if (strpos($oldData->ad_url, 'http') === false && $oldData->ad_url != $data->ad_url) @unlink(".{$oldData->ad_url}");
    }
}