<?php


namespace app\model;


use think\Model;

class BalanceLog extends Model
{
    public function getTypeAttr($val){
        $data =[
            1=>'下级分佣',2=>'领取红包雨',3=>'领取邀请红包'
        ];
        return $data[$val];
    }

}