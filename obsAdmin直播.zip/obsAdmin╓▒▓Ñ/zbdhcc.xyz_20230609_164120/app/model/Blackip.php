<?php


namespace app\model;
use think\Model;

class Blackip extends Model
{

}