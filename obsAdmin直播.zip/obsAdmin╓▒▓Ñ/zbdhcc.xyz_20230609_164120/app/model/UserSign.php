<?php


namespace app\model;


use think\Model;

class UserSign extends Model
{

}