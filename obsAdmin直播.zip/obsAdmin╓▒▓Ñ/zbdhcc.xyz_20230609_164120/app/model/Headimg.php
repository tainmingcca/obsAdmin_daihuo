<?php


namespace app\model;
use think\Model;

class Headimg  extends Model
{
    public static function onBeforeUpdate($data)
    {
        $modelName = __CLASS__;
        $oldData = $modelName::find($data->id);
        if (strpos($oldData->img_url, 'http') === false && $oldData->img_url != $data->img_url) @unlink(".{$oldData->img_url}");
    }
}