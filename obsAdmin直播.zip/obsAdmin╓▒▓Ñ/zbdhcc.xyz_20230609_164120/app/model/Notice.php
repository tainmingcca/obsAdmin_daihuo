<?php


namespace app\model;
use think\Model;

class Notice extends Model
{

}