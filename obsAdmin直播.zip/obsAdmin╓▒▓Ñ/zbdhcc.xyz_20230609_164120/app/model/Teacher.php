<?php


namespace app\model;
use think\Model;

class Teacher  extends Model
{
    public static function onBeforeUpdate($data)
    {
        $modelName = __CLASS__;
        $oldData = $modelName::find($data->id);
        if (strpos($oldData->head_img, 'http') === false && $oldData->head_img != $data->head_img) @unlink(".{$oldData->head_img}");
    }
}