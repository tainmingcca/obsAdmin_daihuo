<?php


namespace app\model;
use think\Model;

class Imkjhf extends Model
{

}