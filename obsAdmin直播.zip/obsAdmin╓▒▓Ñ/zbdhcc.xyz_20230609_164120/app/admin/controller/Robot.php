<?php

namespace app\admin\controller;

use app\model\Headimg;
use app\model\User;
use app\model\UserGroup;
use think\facade\View;

class Robot extends Base
{
    public function __construct(User $userModel)
    {
        parent::__construct();
        $this->_model = $userModel;
    }

    public function index()
    {
        if (request()->isAjax()) {
            $data = request()->param();
            $where = $this->_createWhere();
            $count = $this->_model->where($where)->count();
            $list = $this->_model->where($where)->page($data['page'], $data['limit'])->order('id desc')->select();
            foreach ($list as $item) {
                $item['admin_uid'] = $this->_model->where(['id' => $item['admin_uid']])->value('user_name');
            }
            return json(['code' => 0, 'msg' => '', 'data' => $list, 'count' => $count]);
        }
        return View::fetch();
    }

    private function _createWhere()
    {
        $where = [
            ['room_no', '=', $this->room_no],
            ['is_robot', '=', 1]
        ];
        $data = request()->param();
        if (!empty($data['keyword'])) {
            $where[] = ["nick_name|group_name|login_ip", 'like', "%{$data['keyword']}%"];
        }
        return $where;
    }


    public function edit()
    {
        $id = request()->param('id', 0, 'intval');
        $user_info = $this->_model->where(['id' => $id])->find();
        if (request()->isPost()) {
            $data = request()->post();
            $group_info=(new UserGroup())->where(['id'=>$data['group_id']])->find();
            if(!empty($data['head_img_up'])){
                $data['head_img'] = $data['head_img_up'];
            }
            $data['group_name']=$group_info['group_name'];
            $data['group_icon']=$group_info['group_icon'];
            $res = $user_info->save($data);
            if ($res) {
                cache("robotList{$user_info->admin_uid}",null);
                return json(['code' => 200, 'msg' => '添加成功']);
            }
            return json(['code' => 201, 'msg' => '添加失败']);
        }
        $user_group = (new UserGroup())->where(['room_no' => $this->room_no])->select();
        $head_img = (new Headimg())->where(['room_no' => $this->room_no])->select();
        View::assign(['user_info' => $user_info, 'user_group' => $user_group, 'head_img' => $head_img]);
        return View::fetch();
    }

}