<?php


namespace app\admin\controller;


use app\model\UserSign;
use think\facade\View;
use think\Model;

class Sign extends Base
{
    public function __construct()
    {
        parent::__construct();
        $this->_model = new \app\model\Sign();

    }

    public function index(){
        if (request()->isAjax()) {
            $data = request()->param();
            $where = $this->_createWhere();
            $count = $this->_model->where($where)->count();
            $list = $this->_model->where($where)->page($data['page'], $data['limit'])->order('id desc')->select();
            return json(['code' => 0, 'msg' => '', 'data' => $list, 'count' => $count]);
        }
        return View::fetch();
    }
    /*
    * 签到编辑
    */
    public function edit()
    {
        $id = request()->param('id', 0,'intval');
        $info = $this->_model->where(['id' => $id])->find();
        if (request()->isPost()) {
            $data = request()->post();
            $info = $this->_model->where(['id' => $data['id']])->find();
            $res = $info->save($data);
            if ($res) {
                return json(['code' => 200, 'msg' => '修改成功']);
            }
            return json(['code' => 201, 'msg' => '修改失败']);
        }
        View::assign(['info' => $info]);
        return View::fetch();
    }

    public function signList(){
        if (request()->isAjax()) {
            $data = request()->param();
            $where = $this->_createWhere();
            $count = (new UserSign())->where($where)->count();
            $list = (new UserSign())->where($where)->page($data['page'], $data['limit'])->order('id desc')->select();
            return json(['code' => 0, 'msg' => '', 'data' => $list, 'count' => $count]);
        }
        return View::fetch();
    }
    public function dels(){
        $id = request()->post('ids/d',0);
        $res=(new UserSign())->where(['id'=>$id])->delete();
        if ($res) return json(['code' => 200, 'msg' => '删除成功']);
        return json(['code' => 201, 'msg' => '删除失败']);
    }
    private function _createWhere()
    {
        $where = [
            ['room_no', '=', $this->room_no],
        ];
        return $where;
    }
}