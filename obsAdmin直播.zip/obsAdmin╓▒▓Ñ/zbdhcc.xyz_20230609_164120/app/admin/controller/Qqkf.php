<?php


namespace app\admin\controller;


use app\exception\ErrorException;
use think\facade\View;

class Qqkf extends Base
{
    public function __construct(\app\model\Qqkf $qqkfModel)
    {
        parent::__construct();
        $this->_model = $qqkfModel;
    }

    /*
     * qq列表
     */
    public function index()
    {
        if (request()->isAjax()) {
            $data = request()->param();
            $where = $this->_createWhere();
            $count = $this->_model->where($where)->count();
            $list = $this->_model->where($where)->page($data['page'], $data['limit'])->order('id desc')->select();
            return json(['code' => 0, 'msg' => '', 'data' => $list, 'count' => $count]);
        }
        return View::fetch();
    }

    private function _createWhere()
    {
        $where = [
            ['room_no', '=', $this->room_no],
        ];
        return $where;
    }

    /*
     * 添加qq
     */
    public function add()
    {
        if (request()->isPost()) {
            $data = request()->post();
            $count = $this->_model->where(['qq_account' => $data['qq_account']])->count();
            if ($count > 0) {
                throw new ErrorException(['mgg' => '该客服已经存在!']);
            }
            $data['room_no']=$this->room_no;
            $res = $this->_model->save($data);
            if ($res) {
                return json(['code' => 200, 'msg' => '添加成功']);
            }
            return json(['code' => 201, 'msg' => '添加失败']);
        }
        return View::fetch();
    }

    /*
     * QQ编辑
     */
    public function edit()
    {
        $id = request()->param('id', 0,'intval');
        $qq_info = $this->_model->where(['id' => $id])->find();
        if (request()->isPost()) {
            $data = request()->post();
            $qq_info = $this->_model->where(['id' => $data['id']])->find();
            $res = $qq_info->save($data);
            if ($res) {
                return json(['code' => 200, 'msg' => '修改成功']);
            }
            return json(['code' => 201, 'msg' => '修改失败']);
        }
        View::assign(['qq_info' => $qq_info]);
        return View::fetch();
    }
    /*
     * QQ在线
     */
    public function changeOnline()
    {
        $id = request()->get('id', 0,'intval');
        $qq_info = $this->_model->where(['id' => $id])->find();
        if($qq_info->is_online){
            $qq_info->is_online=0;
        }else{
            $qq_info->is_online=1;
        }
        //$qq_info->is_online = !$qq_info->is_online;
        $res = $qq_info->save();
        if ($res) {
            return json(['code' => 200, 'msg' => '修改成功']);
        }
        return json(['code' => 201, 'msg' => '修改失败']);
    }
}