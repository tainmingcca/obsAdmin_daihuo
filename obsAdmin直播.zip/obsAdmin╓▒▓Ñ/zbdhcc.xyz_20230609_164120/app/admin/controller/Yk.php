<?php
/**
 * 游客控制器
 */

namespace app\admin\controller;


use app\model\User;
use think\facade\View;
use GatewayClient\Gateway;

class Yk extends Base
{
    public function __construct(User $userModel)
    {
        parent::__construct();
        $this->_model = $userModel;
        Gateway::$registerAddress = config('gateway_worker.registerAddress');
    }

    /*
     * 游客列表
     */
    public function index()
    {
        if (request()->isAjax()) {
            $data = request()->param();
            $where = $this->_createWhere();
            $query = $this->_model->where($where);
            if (!empty($data['date'])) {
                if ($data['date'] == 'today') {
                    $query->whereDay("create_time", "today");
                } else {
                    $date_time = explode('~', $data['date']);
                    $start_time = $date_time[0];
                    $end_time = $date_time[1];
                    $query->whereBetweenTime('create_time', $start_time, $end_time);
                }
            }
            $count = $query->count();
            $list = $query->page($data['page'], $data['limit'])->order('id desc')->select();
            foreach ($list as $k => $item) {
                $item->look_time = date("Y-m-d H:i:s", $item->look_time);
            }
            return json(['code' => 0, 'msg' => '', 'count' => $count, 'data' => $list]);
        }
        return View::fetch();
    }

    /*
     * 我的游客
     */
    public function myYk()
    {
        $admin_id = session('user_id');
        if (request()->isAjax()) {
            $data = request()->param();
            $where = $this->_createWhere();
            $where[] = ['admin_uid', '=', session('user_id')];
            $query = $this->_model->where($where);
            if (!empty($data['date'])) {
                if ($data['date'] == 'today') {
                    $query->whereDay("create_time", "today");
                } else {
                    $date_time = explode('~', $data['date']);
                    $start_time = $date_time[0];
                    $end_time = $date_time[1];
                    $query->whereBetweenTime('create_time', $start_time, $end_time);
                }
            }
            $count = $query->count();
            $list = $query->page($data['page'], $data['limit'])->order('id desc')->select();
            foreach ($list as $k => $item) {
                $item->look_time = date("Y-m-d H:i:s", $item->look_time);
            }
            return json(['code' => 0, 'msg' => '', 'count' => $count, 'data' => $list]);
        }
        return View::fetch('index');
    }

    private function _createWhere()
    {
        $where = [
            ['room_no', '=', $this->room_no],
            ['user_type', '=', 2],
            ['group_id', '=', 1],
            ['is_robot', '=', 0]
        ];
        $data = request()->param();
        if (!empty($data['keyword'])) {
            $where[] = ["nick_name|user_name|create_time|group_name|login_ip", 'like', "%{$data['keyword']}%"];
        }
        
        if (!empty($data['from_url'])) {
            $where[] = ["from_url", 'like', "%{$data['from_url']}%"];
        }
        return $where;
    }

    /*
     * 在线客户
     */
    public function onlineUser()
    {
        if (request()->isAjax()) {
            $data = request()->param();
            $uidList = Gateway::getAllUidList();
            $uids = array_values($uidList);
            // echo "<pre>";print_r($uids);exit;
            $where = [
                ['room_no', '=', $this->room_no],
                ['id', 'in', $uids],
                ['is_robot','=',0],
            ];
            if (!empty($data['keyword'])) $where[] = ["nick_name|user_name|create_time|group_name|login_ip", 'like', "%{$data['keyword']}%"];
        
            $count = $this->_model->where($where)->count();
            $list = $this->_model->where($where)->page($data['page'], $data['limit'])->order('id desc')->select();
            foreach ($list as $item) {
                $item->login_time = date("Y-m-d H:i:s", $item->login_time);
            }
            return json(['code' => 0, 'msg' => '', 'data' => $list, 'count' => $count]);
        }
        return View::fetch();
    }

    /**
     * 禁言开关
     * @return mixed
     */
    public function changeJinyan()
    {
        $id = request()->get('id', 0, 'intval');
        $user_info = $this->_model->where(['id' => $id])->field('id,can_sendmsg')->find();
        if ($user_info->can_sendmsg) {
            $user_info->can_sendmsg = 0;
        } else {
            $user_info->can_sendmsg = 1;
        }
        $res = $user_info->save();
        if ($res) {
            return json(['code' => 200, 'msg' => '修改成功']);
        }
        return json(['code' => 201, 'msg' => '修改失败']);
    }


    /**
     * 强制下线
     */
    public function killUser()
    {
        $id = request()->get('id', 0, 'intval');
        $user_info = $this->_model->where(['id' => $id])->field('id,sess_id')->find();
        $user_info->sess_id = '';
        $user_info->is_online = '0';
        $res = $user_info->save();
        if ($res) {
            Gateway::sendToUid($id,json_encode([
                'type' => 'kill',
                'data' => []
            ]));
            return json(['code' => 200, 'msg' => '已经强制下线']);
        }
        return json(['code' => 201, 'msg' => '操作失败']);
    }
}