<?php


namespace app\admin\controller;
use app\model\BalanceLog;
use think\facade\View;

class Balance extends Base
{
    public function __construct()
    {
        parent::__construct();
        $this->_model = new BalanceLog();

    }
    public function index()
    {
        if (request()->isAjax()) {
            $data = request()->param();
            $where = $this->_createWhere();
            $count = $this->_model->where($where)->count();
            $list = $this->_model->where($where)->page($data['page'], $data['limit'])->order('id desc')->select();
            return json(['code' => 0, 'msg' => '', 'data' => $list, 'count' => $count]);
        }
        return View::fetch();

    }
    private function _createWhere()
    {
        $where = [
            ['room_no', '=', $this->room_no],
        ];
        if (!empty($data['keyword'])) {
            $where[] = ["nick_name|mobile", 'like', "%{$data['keyword']}%"];
        }
        return $where;
    }

}