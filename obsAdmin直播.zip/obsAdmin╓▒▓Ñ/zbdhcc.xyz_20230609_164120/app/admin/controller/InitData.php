<?php


namespace app\admin\controller;


class InitData
{
    public $room_no=1001;
    public function index(){
        $this->initAdList();
        $this->initNotice();
        $this->initQQkf();
        $this->initRoom();
        $this->initTeacher();
        $this->initTurntable();
        $this->initAdminUser();
    }

    //初始化广告表
    public function initAdList(){
        $list = (new \app\model\AdList())->select();
        foreach ($list as $k=>$item){
            $item->room_no=$this->room_no;
            unset($item->id);
            unset($item->create_time);
            (new \app\model\AdList())->save($item->toArray());
        }
    }

    //初始化公告
    public function initNotice(){
        $list = (new \app\model\Notice())->select();
        foreach ($list as $k=>$item){
            $item->room_no=$this->room_no;
            unset($item->id);
            unset($item->create_time);
            unset($item->update_time);
            (new \app\model\Notice())->save($item->toArray());
        }
    }

    //初始化QQ客服
    public function initQQkf(){
        $list = (new \app\model\Qqkf())->select();
        foreach ($list as $k=>$item){
            $item->room_no=$this->room_no;
            unset($item->id);
            unset($item->create_time);
            unset($item->update_time);
            (new \app\model\Qqkf())->save($item->toArray());
        }
    }
    //初始化房间信息
    public function initRoom(){
        $list = (new \app\model\Room())->select();
        foreach ($list as $k=>$item){
            $item->room_no=$this->room_no;
            unset($item->id);
            unset($item->create_time);
            unset($item->update_time);
            (new \app\model\Room())->save($item->toArray());
        }
    }

    //初始化讲师
    public function initTeacher(){
        $list = (new \app\model\Teacher())->select();
        foreach ($list as $k=>$item){
            $item->room_no=$this->room_no;
            unset($item->id);
            unset($item->create_time);
            unset($item->update_time);
            (new \app\model\Teacher())->save($item->toArray());
        }
    }

    //初始化大转盘
    public function initTurntable(){
        $list = (new \app\model\Turntable())->select();
        foreach ($list as $k=>$item){
            $item->room_no=$this->room_no;
            unset($item->id);
            unset($item->create_time);
            unset($item->update_time);
            (new \app\model\Turntable())->save($item->toArray());
        }
    }

    //初始化管理员
    public function initAdminUser(){
        $list = (new \app\model\User())->where(['user_type'=>1])->select();
        foreach ($list as $k=>$item){
            $item->room_no=$this->room_no;
            unset($item->id);
            unset($item->create_time);
            unset($item->update_time);
            (new \app\model\User())->save($item->toArray());
        }
    }
}