<?php


namespace app\admin\controller;


use think\facade\Session;
use think\facade\View;
use GatewayClient\Gateway;
class Goods extends Base
{
    public function __construct()
    {
        parent::__construct();
        $this->_model = new \app\model\Goods();
        Gateway::$registerAddress = config('gateway_worker.registerAddress');
    }
    public function index(){
        if (request()->isAjax()) {
            $data = request()->param();
            $where = $this->_createWhere();
            $count = $this->_model->where($where)->count();
            $list = $this->_model->where($where)->page($data['page'], $data['limit'])->order('id desc')->select();
            return json(['code' => 0, 'msg' => '', 'data' => $list, 'count' => $count]);
        }
        return View::fetch();
    }
    public function add(){
        if (request()->isPost()){
            $data = request()->post();
            $data['room_no']=$this->room_no;
//            $data['content']=htmlentities($data['content']);
            $res = $this->_model->save($data);
            if ($res) {
                return json(['code' => 200, 'msg' => '添加成功']);
            }
            return json(['code' => 201, 'msg' => '添加失败']);
        }
        return View::fetch();
    }
    public function edit(){
        $id = request()->param('id', 0, 'intval');
        $goodsInfo = $this->_model->where(['id' => $id])->find();
        if (request()->isPost()) {
            $data = request()->post();
//            $data['content']=htmlentities($data['content']);
            $res = $goodsInfo->save($data);
            if ($res) {
                return json(['code' => 200, 'msg' => '修改成功']);
            }
            return json(['code' => 201, 'msg' => '修改失败']);
        }

        View::assign(['goodsInfo' => $goodsInfo]);
        return View::fetch();
    }

    /*
     * 商品上架推送
     */
    public function getStatus(){
        $id=request()->get('id/d',0);
        $userId = Session::get('user_id');
        $userInfo = (new \app\model\User())->where(['id'=>$userId])->field('id,user_type,group_id')->find();
        if ($userInfo->user_type == 1){
            $goodsInfo=$this->_model->where(['id'=>$id])->field('id,status,title,img,price')->find();

            if ($goodsInfo->status==1){
                $goodsInfo->status=0;
            }else{
                $goodsInfo->status=1;
            }
            $res=$goodsInfo->save();
            if ($res) {
                Gateway::sendToAll(json_encode([
                    'type' => 'isGoods',
                    'data' => [
                        'goods'=>$goodsInfo,
                    ]
                ]));
                return json(['code' => 200, 'msg' => '修改成功']);
            }
            return json(['code' => 201, 'msg' => '修改失败']);
        }
        return json(['code' => 201, 'msg' => '您当前没用权限，请刷新重试']);
    }

    private function _createWhere()
    {
        $where = [
            ['room_no', '=', $this->room_no]
        ];
        return $where;
    }

}