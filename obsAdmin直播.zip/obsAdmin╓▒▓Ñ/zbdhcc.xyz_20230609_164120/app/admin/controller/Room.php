<?php


namespace app\admin\controller;


use app\exception\ErrorException;
use think\facade\View;

class Room extends Base
{
    public function index(){
        $cacheKey = "room_info{$this->room_no}";
        $room_info=(new \app\model\Room())->where(['room_no'=>$this->room_no])->cache($cacheKey,24 * 3600)->find();
        if (request()->isPost()){
            $data=request()->post();
            unset($data['file']);
            $res=$room_info->where(['room_no'=>$this->room_no])->cache($cacheKey)->update($data);
            if ($res!==false){
                cache($cacheKey,null);
                return json(['code'=>200,'msg'=>'保存成功']);
            }
            throw new ErrorException(['msg'=>'保存失败']);
        }
        View::assign(['room'=>$room_info]);
        return View::fetch();
    }

    /**
     * 课程安排
     */
    public function kecheng(){
        $kcb_url = (new \app\model\Room())->where(['room_no'=>$this->room_no])->value('kcb_url');
        View::assign('kcb_url',$kcb_url);
        return view();
    }
    //成交数据
    public function tradeData(){
        if(request()->isPost()){
            $trade_data=request()->param('trade_data');
            $res = (new \app\model\Room())->where(['room_no'=>$this->room_no])->update(['trade_data'=>$trade_data]);
            if ($res) {
                cache("room_info{$this->room_no}", null);
                return json(['code' => 200, 'msg' => '修改成功']);
            }
            return json(['code' => 201, 'msg' => '修改失败']);
        }
        $trade_data = (new \app\model\Room())->where(['room_no'=>$this->room_no])->value('trade_data');
        View::assign('trade_data',$trade_data);
        return view();
    }
    public function ranKing(){
        if(request()->isPost()){
            $ran_king=request()->param('ran_king');
            $res = (new \app\model\Room())->where(['room_no'=>$this->room_no])->update(['ran_king'=>$ran_king]);
            if ($res) {
                cache("room_info{$this->room_no}", null);
                return json(['code' => 200, 'msg' => '修改成功']);
            }
            return json(['code' => 201, 'msg' => '修改失败']);
        }
        $ran_king = (new \app\model\Room())->where(['room_no'=>$this->room_no])->value('ran_king');
        View::assign('ran_king',$ran_king);
        return view();
    }
}