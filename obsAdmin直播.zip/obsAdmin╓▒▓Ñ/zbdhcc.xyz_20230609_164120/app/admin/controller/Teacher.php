<?php

namespace app\admin\controller;

use app\model\AdminGroup;
use app\exception\ErrorException;
use think\facade\View;
use GatewayClient\Gateway;

class Teacher extends Base
{
    public function __construct(\app\model\Teacher $teacherModel)
    {
        parent::__construct();
        $this->_model = $teacherModel;
        Gateway::$registerAddress = config('gateway_worker.registerAddress');
    }

    public function index()
    {
        if (request()->isAjax()) {
            $where = $this->_createWhere();
            $list = $this->_model->where($where)->order('id desc')->select();
            return json(['code' => 0, 'msg' => '','count'=>count($list), 'data' => $list]);
        }
        return View::fetch();
    }
    private function _createWhere()
    {
        $where = [
            ['room_no', '=', $this->room_no]
        ];
        return $where;
    }


    /*
     * 添加讲师
     */
    public function add()
    {
        if (request()->isPost()) {
            $data = request()->post();
            if (empty($data['passwd']) || empty($data['passwd2'])) {
                throw new ErrorException(['msg' => '请填写密码']);
            }
            if (md5($data['passwd']) != md5($data['passwd2'])) {
                throw new ErrorException(['msg' => '两次输入密码不一致,请重新输入']);
            }
            $count = (new \app\model\User())->where(['user_name' => $data['user_name']])->count();
            if ($count > 0) {
                throw new ErrorException(['msg' => '账号已经存在']);
            }
            $admin_group = (new AdminGroup())->where(['id' => 3])->find();
            $res = (new \app\model\User())->save([
                'room_no'=>$this->room_no,
                'user_name' => $data['user_name'],
                'nick_name' => $data['nick_name'],
                'passwd' => md5($data['passwd']),
                'user_type' => 1,
                'group_id' => $admin_group->id,
                'group_name' => $admin_group->group_name,
                'group_icon' => $admin_group->group_icon,
                'user_qq' => $data['user_qq'],
                'end_time' => $data['end_time'] ? $data['end_time'] : '0000-00-00',
                'admin_fenpei' => $data['admin_fenpei'],
                'head_img'=>'/static/default/head_img.png'
            ]);
            $res2 = $this->_model->save(['user_name' => $data['user_name'], 'nick_name' => $data['nick_name'],'room_no'=>$this->room_no]);
            if ($res && $res2) {
                return json(['code' => 200, 'msg' => '添加成功,请编辑讲师资料']);
            }
            throw new ErrorException(['msg' => '添加失败']);
        }
        return View::fetch();
    }

    public function edit()
    {
        $id = request()->param('id', 0, 'intval');
        $teacher_info = $this->_model->where(['id' => $id])->find();
        
        if (request()->isPost()) {
            $data = request()->post();
           
            $data['user_name'] = $data['nick_name'];
            $data['sl']=(int)$data['sl'];
            $data['zan_nums']=(int)$data['zan_nums'];
            $res = $teacher_info->save($data);
           
            if ($res) {
                cache("teacher{$this->room_no}",null);
                if($teacher_info->is_recommend==1) Gateway::sendToAll(json_encode([
                    'type' => 'teacher_img',
                    'data' => [
                        'room_no'=>env('room_no'),
                        'img' => $data['head_img'],
                    ]
                ]));
                return json(['code' => 200, 'msg' => '修改成功']);
            }
            return json(['code' => 201, 'msg' => '修改失败']);
        }
       
        View::assign(['teacher_info' => $teacher_info]);
        return View::fetch();
    }


    public function changeStatus(){
        $id = request()->get('id', 0,'intval');
        $teacherInfo = $this->_model->where(['id' => $id,'room_no'=>env('room_no')])->find();
        if($teacherInfo->is_recommend==1){
            $teacherInfo->is_recommend=0;
        }else{
            $teacherInfo->is_recommend=1;
            //$this->_model->where('id','<>',$id)->update(['is_recommend'=>0]);
        }
        $res = $teacherInfo->save();
        if ($res) {
            cache("teacher{$this->room_no}",null);
            if($teacherInfo->is_recommend==1) Gateway::sendToAll(json_encode([
                'type' => 'teacher_img',
                'data' => [
                    'room_no'=>env('room_no'),
                    'img' => $teacherInfo->head_img,
                ]
            ]));
            return json(['code' => 200, 'msg' => '修改成功']);
        }
        return json(['code' => 201, 'msg' => '修改失败']);
    }
}