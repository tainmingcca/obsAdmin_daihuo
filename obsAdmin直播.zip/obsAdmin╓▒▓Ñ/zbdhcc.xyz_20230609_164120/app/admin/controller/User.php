<?php


namespace app\admin\controller;

use app\model\User as UserModel;
use app\model\UserGroup;
use app\exception\ErrorException;
use app\service\Excel;
use think\facade\View;

class User extends Base
{
    public function __construct(UserModel $userModel)
    {
        parent::__construct();
        $this->_model = $userModel;
    }

    public function index()
    {
        if (request()->isAjax()) {
            $data = request()->param();
            $where = $this->_createWhere();
            $query = $this->_model->where($where);
            if (!empty($data['date'])) {
                if ($data['date'] == 'today') {
                    $query->whereDay("create_time", "today");
                } else {
                    $date_time = explode('~', $data['date']);
                    $start_time = $date_time[0];
                    $end_time = $date_time[1];
                    $query->whereBetweenTime('create_time', $start_time, $end_time);
                }
            }
            //p($where);
            $count = $query->count();
            $list = $query->page($data['page'], $data['limit'])->order('id desc')->fetchSql(false)->select();
            //p($list);
            foreach ($list as $k => $item) {
                $item->look_time = date("Y-m-d H:i:s", $item->look_time);
                $item->p_mobile = $this->_model->where(['id'=>$item['pid']])->value('mobile');
            }
            return json(['code' => 0, 'msg' => '', 'count' => $count, 'data' => $list]);
        }
        View::assign("addAct", url('add'));
        return View::fetch();
    }

    /**
     * 我的会员
     */
    public function myUser()
    {
        if (request()->isAjax()) {
            $data = request()->param();
            $where = $this->_createWhere();
            $where[] = ['admin_uid', '=', $this->admin_info->id];
            $query = $this->_model->where($where);
            if (!empty($data['date'])) {
                if ($data['date'] == 'today') {
                    $query->whereDay("create_time", "today");
                } else {
                    $date_time = explode('~', $data['date']);
                    $start_time = $date_time[0];
                    $end_time = $date_time[1];
                    $query->whereBetweenTime('create_time', $start_time, $end_time);
                }
            }
            $count = $query->count();
            $list = $query->page($data['page'], $data['limit'])->order('id desc')->select();
            foreach ($list as $k => $item) {
                $item->look_time = date("Y-m-d H:i:s", $item->look_time);
            }
            return json(['code' => 0, 'msg' => '', 'count' => $count, 'data' => $list]);
        }
        View::assign("addAct", url('myAdd'));
        return View::fetch('index');
    }

    private function _createWhere()
    {
        $where = [
            ['room_no', '=', $this->room_no],
            ['user_type', '=', 2],
            ['group_id', '>', 1],
            ['is_robot', '=', 0]
        ];
        $data = request()->param();
        if (!empty($data['keyword'])) {
            $where[] = ["nick_name|user_name|create_time|group_name|login_ip|mobile", 'like', "%{$data['keyword']}%"];
        }

        return $where;
    }

    /**
     * 导出
     */
    public function export()
    {
        $data = request()->param();
        $where = $this->_createWhere();
        $query = $this->_model->where($where);
        if (!empty($data['date'])) {
            $date_time = explode('~', $data['date']);
            $start_time = $date_time[0];
            $end_time = $date_time[1];
            $query->whereBetweenTime('create_time', $start_time, $end_time);
        }
        $list = $query->order('id desc')->select();
        $xlsData = [];
        foreach ($list as $k => $item) {
            $xlsData[$k]['id'] = $k + 1;
            $xlsData[$k]['nick_name'] = $item->nick_name;
            $xlsData[$k]['mobile'] = $item->mobile;
            $xlsData[$k]['user_qq'] = $item->user_qq;
            $xlsData[$k]['group_name'] = $item->group_name;
            $xlsData[$k]['online_time'] = $item->online_time;
            $xlsData[$k]['look_time'] = date("Y-m-d H:i:s",$item->look_time);
            $xlsData[$k]['create_time'] = $item->create_time;
            $xlsData[$k]['login_ip'] = $item->login_ip;
            // $xlsData[$k]['user_status'] = $item->user_status;
            $xlsData[$k]['from_url'] = $item->from_url;
            $xlsData[$k]['remark'] = $item->remark;
        }
        // $heads = ["序号", "昵称", "手机号", "QQ号", "隶属组", "在线分钟", "观看到期日期", "注册时间", "登陆IP", "状态", "注册网址", "备注"];
        $heads = ["序号", "昵称", "手机号", "QQ号", "隶属组", "在线分钟", "观看到期日期", "注册时间", "登陆IP",  "注册网址", "备注"];
        $date = !empty($data['date']) ? $data['date'] : date("m月d日");
        (new Excel())->excelExport("注册会员数据表", $heads, $xlsData);
    }

    public function add()
    {
        if (request()->isPost()) {
            $data = request()->post();
            if (strlen($data['passwd']) < 6 && strlen($data['passwd']) < 12) {
                throw new ErrorException(['msg' => '密码不得低于6位.不得超过12位']);
            }
            if (md5($data['passwd']) != md5($data['passwd2'])) {
                throw new ErrorException(['msg' => '两次输入密码不一致,请重新输入']);
            }

            $count = $this->_model->where(['user_name' => $data['user_name']])->count();
            if ($count > 0) {
                throw new ErrorException(['msg' => '该账号已存在,请重新输入']);
            }
            $user_group = (new UserGroup())->where(['id' => $data['group_id']])->find();
            $data = [
                'room_no' => $this->room_no,
                'user_name' => $data['user_name'],
                'nick_name' => $data['nick_name'],
                'passwd' => md5($data['passwd']),
                'user_type' => 2,
                'group_id' => $user_group->id,
                'group_name' => $user_group->group_name,
                'group_icon' => $user_group->group_icon,
                'user_qq' => $data['user_qq'],
                'end_time' => $data['end_time'] ? $data['end_time'] : '0000-00-00',
                'look_time' => time() + $user_group->look_time * 60,
                //'admin_fenpei' => $data['admin_fenpei'],
                'head_img' => '/static/default/head_img.png'
            ];

            $res = $this->_model->save($data);
            if ($res) {
                return json(['code' => 200, 'msg' => '添加成功']);
            }
            return json(['code' => 201, 'msg' => '添加失败']);
        }
        $group_list = (new UserGroup())->select();
        View::assign(['group_list' => $group_list]);
        return View::fetch();
    }

    public function myAdd()
    {
        if (request()->isPost()) {
            if ($this->admin_info->group_id > 2) {
                throw new ErrorException(['msg' => '您无权添加会员']);
            }
            $data = request()->post();
            if (strlen($data['passwd']) < 6 && strlen($data['passwd']) < 12) {
                throw new ErrorException(['msg' => '密码不得低于6位.不得超过12位']);
            }
            if (md5($data['passwd']) != md5($data['passwd2'])) {
                throw new ErrorException(['msg' => '两次输入密码不一致,请重新输入']);
            }

            $count = $this->_model->where(['user_name' => $data['user_name']])->count();
            if ($count > 0) {
                throw new ErrorException(['msg' => '该账号已存在,请重新输入']);
            }
            $user_group = (new UserGroup())->where(['id' => $data['group_id']])->find();
            $data = [
                'admin_uid' => $this->admin_info->id == 2 ? $this->admin_info->id : 0,
                'room_no' => $this->room_no,
                'user_name' => $data['user_name'],
                'nick_name' => $data['nick_name'],
                'passwd' => md5($data['passwd']),
                'user_type' => 2,
                'group_id' => $user_group->id,
                'group_name' => $user_group->group_name,
                'group_icon' => $user_group->group_icon,
                'user_qq' => $data['user_qq'],
                'end_time' => $data['end_time'] ? $data['end_time'] : '0000-00-00',
                'look_time' => time() + $user_group->look_time * 60,
                'admin_fenpei' => $data['admin_fenpei'],
                'head_img' => '/static/default/head_img.png'
            ];

            $res = $this->_model->save($data);
            if ($res) {
                return json(['code' => 200, 'msg' => '添加成功']);
            }
            return json(['code' => 201, 'msg' => '添加失败']);
        }
        $group_list = (new UserGroup())->select();
        View::assign(['group_list' => $group_list]);
        return view('add');
    }

    /*
     * 编辑会员
     */
    public function edit()
    {
        $id = request()->param('id', 0, 'intval');
        $user_info = $this->_model->where(['id' => $id])->find();
        $user_info->look_time = date("Y-m-d H:i:s", $user_info->look_time);
        if (request()->isPost()) {
            $data = request()->post();
            $user_group = (new UserGroup())->where(['id' => $data['group_id']])->find();
            $data['group_id'] = $user_group->id;
            $data['group_name'] = $user_group->group_name;
            $data['group_icon'] = $user_group->group_icon;
            if (empty($data['passwd'])) {
                unset($data['passwd']);
            } else {
                $data['passwd'] = md5($data['passwd']);
            }
            //管理员才有权限修改观看时间
            if ($this->admin_info->group_id == 1) {
                $data['look_time'] = strtotime($data['look_time']);
            } else {
                unset($data['look_time']);
            }
            if ($data['is_red']==0) {
               $data['red_num'] = $user_info->red_num;
               
            }
            //p($data);
            $data['end_time'] = $data['end_time'] ? $data['end_time'] : '0000-00-00';
            
            //p($data);
            //$res =$this->_model->where(['id' => $id])-> update($data);
            $res =$user_info->save($data);
           // p($res);
            if ($res==1) {
                return json(['code' => 200, 'msg' => '修改成功']);
            }
            return json(['code' => 201, 'msg' => '修改失败']);
        }
        $user_group = (new UserGroup())->select();
        View::assign(['user_info' => $user_info, 'user_group' => $user_group]);
        return View::fetch();
    }


    /*
     * 获取IM客服/会员列表分配
     */
    public function fpim()
    {
        $id = request()->param('id', 0, 'intval');
        $user_info = $this->_model->where(['id' => $id])->field('id,admin_uid')->find();
        if (request()->isPost()) {
            $data = request()->post();

            $res = $user_info->save(['admin_uid' => $data['im_id']]);
            if ($res) {
                return json(['code' => 200, 'msg' => '修改成功']);
            }
            return json(['code' => 201, 'msg' => '修改失败']);
        }
        $im_list = $this->_model->where([
            ['room_no', '=', $this->room_no],
            ['user_type', '=', 1],
            ['group_id', '=', 2]
        ])->field('id,user_name,nick_name')->select();
        View::assign(['im_list' => $im_list, 'userinfo' => $user_info]);
        return View::fetch();
    }


    /*
     * 修改会员状态状态//统一接口
     */
    public function changeStatus()
    {
        $id = request()->get('id', 0, 'intval');
        $user_info = $this->_model->where(['id' => $id])->field('id,user_status')->find();
        if ($user_info['user_status'] == 1) {
            $user_info->user_status = 0;
        } else {
            $user_info->user_status = 1;
        }
        $res = $user_info->save();
        if ($res) {
            return json(['code' => 200, 'msg' => '修改成功']);
        }
        return json(['code' => 201, 'msg' => '修改失败']);
    }


    /*
     * 会员备注
     */
    public function changRemark()
    {
        $id = request()->param('id', 0, 'intval');
        $user_info = $this->_model->where(['id' => $id])->field('id,remark')->find();
        if (request()->isPost()) {
            $data = request()->post();
            $res = $user_info->save($data);
            if ($res) {
                return json(['code' => 200, 'msg' => '修改成功']);
            }
            return json(['code' => 201, 'msg' => '修改失败']);
        }
        View::assign(['remark' => $user_info]);
        return View::fetch();
    }


    /*
     * 在线会员状态管理
     */
    public function getIsOnline()
    {
        $id = request()->get('id/d', 0);
        $user_list = (new \app\model\User())->where(['id' => $id])->field('can_sendmsg')->find();
        if ($user_list['can_sendmsg'] == 1) {
            $user_list['can_sendmsg'] = 0;
        } else {
            $user_list['can_sendmsg'] = 1;
        }
        $res = $user_list->save();
        if ($res) {
            return json(['code' => 200, 'msg' => '修改成功']);
        }
        return json(['code' => 201, 'msg' => '修改失败']);
    }

}