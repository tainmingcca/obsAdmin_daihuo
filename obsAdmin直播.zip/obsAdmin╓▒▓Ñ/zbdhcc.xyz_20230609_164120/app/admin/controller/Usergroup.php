<?php


namespace app\admin\controller;
use think\facade\View;

class Usergroup extends Base
{
    public function __construct(\app\model\UserGroup $usergroupModel)
    {
        parent::__construct();
        $this->_model = $usergroupModel;
    }

    public function index()
    {
        if (request()->isAjax()) {
            $data = request()->param();
            $where = $this->_createWhere();
            $count = $this->_model->where($where)->count();
            $list = $this->_model->where($where)->page($data['page'], $data['limit'])->order('id desc')->select();
            return json(['code' => 0, 'msg' => '', 'data' => $list, 'count' => $count]);
        }
        return View::fetch();
    }

    private function _createWhere()
    {
        $where = [
            ['room_no', '=', $this->room_no],
        ];
        return $where;
    }


    /*
     * 会员组添加
     */
    public function add()
    {
        if (request()->isPost()) {
            $data = request()->post();
            $data['room_no'] = $this->room_no;
            $res = $this->_model->save($data);
            if ($res) {
                return json(['code' => 200, 'msg' => '添加成功']);
            }
            return json(['code' => 201, 'msg' => '添加失败']);
        }
        return View::fetch();

    }

    /*
     * 会员组编辑
     */
    public function edit()
    {
        $id = request()->param('id', 0, 'intval');
        $group_info = $this->_model->where(['id' => $id])->find();
        if (request()->isPost()) {
            $data = request()->post();
            $res = $group_info->save($data);
            if ($res) {
                return json(['code' => 200, 'msg' => '修改成功']);
            }
            return json(['code' => 201, 'msg' => '修改失败']);
        }
        View::assign(['group_info' => $group_info]);
        return View::fetch();
    }
  /*
      * 是否领取红包
      */
    public function changeStatus()
    {
        $id = request()->get('id', 0, 'intval');
        $userGroupInfo = $this->_model->where(['id' => $id])->field('id,is_red')->find();
        if ($userGroupInfo['is_red'] == 1) {
            $userGroupInfo->is_red = 0;
        } else {
            $userGroupInfo->is_red = 1;
        }
        $res = $userGroupInfo->save();
        if ($res) {
            return json(['code' => 200, 'msg' => '修改成功']);
        }
        return json(['code' => 201, 'msg' => '修改失败']);
    }

    public function dels()
    {
        if (request()->isAjax()) {
            $ids = input("post.ids");
            $ids = explode(",", $ids);
            $res = $this->_model->whereIn('id',$ids)->where(['can_del'=>2])->delete();
            if ($res !== false) {
                return json([
                    "msg" => "操作成功",
                    "url" => url("index")
                ]);

            } else {
                return json([
                    "msg" => "操作失败",
                    "url" => url("index")
                ]);
            }
        }
    }
}