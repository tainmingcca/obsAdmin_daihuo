<?php
namespace app\admin\controller;
use app\exception\ErrorException;
use app\model\AdList as AdListModel;
use think\facade\View;

class AdList extends Base
{
    public function __construct(AdListModel  $adListModl)
    {
        parent::__construct();
        $this->_model = $adListModl;

    }
    public function index(){
        if (request()->isAjax()) {
            $data = request()->param();
            $where = $this->_createWhere();
            $count = $this->_model->where($where)->count();
            $list = $this->_model->where($where)->page($data['page'], $data['limit'])->order('id desc')->select();
            return json(['code' => 0, 'msg' => '', 'data' => $list, 'count' => $count]);
        }
        return View::fetch();
    }
    private function _createWhere()
    {
        $where = [
            ['room_no', '=', $this->room_no],
        ];
        return $where;
    }
    public function add(){
        if (request()->isPost()) {
            $data = request()->post();
            $data['room_no'] = $this->room_no;
            $data['is_show'] = 1;
            $res = $this->_model->save($data);
            if ($res) {
                cache("banner{$this->room_no}",null);
                return json(['code' => 200, 'msg' => '添加成功']);
            }
            return json(['code' => 201, 'msg' => '添加失败']);
        }
        return View::fetch();
    }
    public function edit(){
        $id = request()->param('id', 0,'intval');
        $ad_info = $this->_model->where(['id' => $id])->find();
        if (request()->isPost()) {
            $data = request()->post();
            $ad_info = $this->_model->where(['id' => $data['id']])->find();
            $res = $ad_info->save($data);
            if ($res) {
                cache("banner{$this->room_no}",null);
                return json(['code' => 200, 'msg' => '修改成功']);
            }
            return json(['code' => 201, 'msg' => '修改失败']);
        }
        View::assign(['ad_info' => $ad_info]);
        return View::fetch();
    }
    public function adIsShow()
    {
        $id = request()->get('id', 0,'intval');
        $ad_list = $this->_model->where(['id' => $id])->find();
        if($ad_list->is_show){
            $ad_list->is_show=0;
        }else{
            $ad_list->is_show=1;
        }
        $res = $ad_list->save();
        if ($res) {
            cache("banner{$this->room_no}",null);
            return json(['code' => 200, 'msg' => '修改成功']);
        }
        return json(['code' => 201, 'msg' => '修改失败']);
    }
}

