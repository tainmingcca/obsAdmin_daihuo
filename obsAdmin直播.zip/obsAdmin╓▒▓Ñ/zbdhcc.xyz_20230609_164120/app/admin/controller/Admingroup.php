<?php

namespace app\admin\controller;

use think\facade\View;

class Admingroup extends Base
{
    public function __construct(\app\model\AdminGroup $admingroupModel)
    {
        parent::__construct();
        $this->_model = $admingroupModel;
    }

    public function index()
    {
        if (request()->isAjax()) {
            $data = request()->param();
            $where = $this->_createWhere();
            $count = $this->_model->where($where)->count();
            $list = $this->_model->where($where)->page($data['page'], $data['limit'])->order('id desc')->select();
            return json(['code' => 0, 'msg' => '', 'data' => $list, 'count' => $count]);
        }
        return View::fetch();
    }

    private function _createWhere()
    {
        $where = [
//            ['room_no', '=', $this->room_no],
        ];
        return $where;
    }


    public function add()
    {
        if (request()->isPost()) {
            $data = request()->post();
            $data['can_del'] = 2;
            $data['room_no'] = $this->room_no;
            $res = $this->_model->save($data);
            if ($res) {
                return json(['code' => 200, 'msg' => '添加成功']);
            }
            return json(['code' => 201, 'msg' => '添加失败']);
        }
        return View::fetch();
    }

    public function edit()
    {
        $id = request()->param('id', 0, 'intval');
        $group_info = $this->_model->where(['id' => $id])->find();
        if (request()->isPost()) {
            $data = request()->param();
            unset($data['file']);
            $res = $group_info->save($data);
            if ($res) {
                return json(['code' => 200, 'msg' => '修改成功']);
            }
            return json(['code' => 201, 'msg' => '修改失败']);
        }
        View::assign(['group_info' => $group_info]);
        return View::fetch();
    }

    public function dels()
    {
        if (request()->isAjax()) {
            $ids = input("post.ids");
            $ids = explode(",", $ids);
            $res = $this->_model->whereIn('id',$ids)->where(['can_del'=>2])->delete();
            if ($res !== false) {
                return json([
                    "msg" => "操作成功",
                    "url" => url("index")
                ]);

            } else {
                return json([
                    "msg" => "操作失败",
                    "url" => url("index")
                ]);
            }
        }
    }


    public function fenpei(){
        $id = request()->param("id/d",0);
        $info = (new \app\model\AdminGroup())->find($id);
        if(request()->isAjax()){
            if($info->rule=="all"){
                return json(['code'=>200, "msg" => "操作成功", "url" => url("index")]);
            }
            $data = request()->post("data");
            $is_login_admin = isset($data['is_login_admin']) ? 1:0;
            $info->is_login_admin = $is_login_admin;
            unset($data['is_login_admin']);
            $rules = array_keys($data);
            $info->rule = implode(",",$rules);
            $res = $info->save();
            if($res!==false){
                return json(['code'=>200, "msg" => "操作成功", "url" => url("index")]);
            }else{
                return json(['code'=>201, "msg" => "操作失败", "url" => url("index")]);
            }
        }
        $rules = explode(",",$info->rule);
        $adminMenu=$this->adminMenu;
        foreach ($adminMenu as $k=>$menu){
            $menu['isChecked']=false;
            if($info->rule=="all" || in_array($k,$rules)){
                $menu['isChecked']=true;
            }
            foreach ($menu['subMenu'] as $k2=>$subMenu){
                $menu['subMenu'][$k2]['isChecked']=false;
                if($info->rule=="all" || in_array($k."_".$k2,$rules)){
                    $menu['subMenu'][$k2]['isChecked']=true;
                }
            }
            $adminMenu[$k]=$menu;
        }
        View::assign("adminMenu",$adminMenu);
        View::assign("info",$info);
        return View::fetch();
    }

    public function changeStatusByField($id=0,$field=''){
        if(!request()->isAjax() || !$id || !$field){
            return json(['code'=>201, "msg" => "参数错误", "url" => url("index")]);
        }
        $info = (new \app\model\AdminGroup())->find($id);
        if($info->$field){
            $info->$field=0;
        }else{
            $info->$field=1;
        }
        $res = $info->save();
        if($res!==false){
            return json(['code'=>200, "msg" => "操作成功", "url" => url("index")]);
        }else{
            return json(['code'=>201, "msg" => "操作失败", "url" => url("index")]);
        }
    }

}