<?php


namespace app\admin\controller;
use think\facade\Request;
use think\facade\View;

class Notice extends Base
{
    public function __construct(\app\model\Notice $noticeModel)
    {
        parent::__construct();
        $this->_model = $noticeModel;
    }
    public function index(){
        if(request()->isAjax()){
            $params = Request::param();
            $where = $this->_create_index_where();

            $count = $this->_model->where($where)->count();
            $list = $this->_model->where($where)
                ->page($params['page'], $params['limit'])
                ->order("id desc")
                ->select();
            if (empty($list)) {
                return json(["code" => 1, "count" => 0, "data" => "", "msg" => "暂无数据"]);
            }
            return json(["code" => 0, "count" => $count, "data" => $list, "msg" => ""]);
        }
        return View::fetch();
    }

    private function _create_index_where() {
        $where = [];
        $where[]=['room_no','=',$this->room_no];
        return $where;
    }


    public function add(){

    }



    public function edit($id){
        $info = $this->_model->where(['room_no'=>$this->room_no])->find(intval($id));
        if (Request::isPost()) {
            $params = Request::post();
            $res = $this->_model::update($params,['id'=>$params['id']],['content']);
            if($res !== false){
                cache("notice{$this->room_no}",null);
                return json(["msg"=>"操作成功","url"=>url("index")]);
            }else{
                return json(["msg"=>"操作失败","url"=>url("index")]);
            }
        }
        View::assign("info",$info);
        return View::fetch();
    }
}