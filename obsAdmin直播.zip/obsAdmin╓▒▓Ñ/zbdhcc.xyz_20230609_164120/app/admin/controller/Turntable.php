<?php


namespace app\admin\controller;


use app\exception\ErrorException;
use think\facade\View;

class Turntable extends Base
{
    public function index()
    {
        $info = (new \app\model\Turntable())->find(1);
        if (request()->isAjax()) {
            $data = request()->post();
            $res = $info->save($data);
            if ($res !== false) {
                return json(['code' => 200, 'msg' => '保存成功']);
            }
            throw new ErrorException(['msg' => '保存失败']);
        }
        if (empty($info->prize_config)) {
            $prize_config = [];
            for ($i = 0; $i < 12; $i++) {
                $prize_config[$i] = "";
            }
            $info->prize_config = $prize_config;
        }
        if (empty($info->prize_gailv)) {
            $prize_gailv = [];
            for ($i = 0; $i < 12; $i++) {
                $prize_gailv[$i] = "";
            }
            $info->prize_gailv = $prize_gailv;
        }
//        halt($info->toArray()['prize_config']);
        View::assign("info", $info);
        return View::fetch();
    }
}