<?php


namespace app\admin\controller;


use app\exception\ErrorException;
use think\facade\View;

class TurntableLog extends Base
{
    public function __construct(\app\model\TurntableLog $turntablelogModel)
    {
        parent::__construct();
        $this->_model = $turntablelogModel;
    }

    public function index()
    {
        if (request()->isAjax()) {
            $data = request()->param();
            $where = $this->_createWhere();
            $count = $this->_model->where($where)->count();
            $list = $this->_model->where($where)->page($data['page'], $data['limit'])->order('id desc')->select();
            return json(['code' => 0, 'msg' => '', 'count' => $count, 'data' => $list]);
        }
        return View::fetch();
    }

    private function _createWhere()
    {
        $where = [
            ['room_no', '=', $this->room_no]
        ];
        return $where;
    }
}