<?php


namespace app\service;

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xls;

class Excel
{
    /**
     * 导出方法封装
     * @param string $list
     */
    public function excelExport($filename, $heads, $data)
    {
        $spreadsheet = new Spreadsheet();
        //获取激活当前的sheet表
        $sheet = $spreadsheet->getActiveSheet();
        //生成列信息
        $ary = array("A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z");
        $styleArray = [
            'alignment' => [
                'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER,
            ],
        ];
        //表头
        foreach ($heads as $k=>$title){
            $sheet->setCellValue($ary[$k].'1', $title);
            $sheet->getStyle($ary[$k])->applyFromArray($styleArray);
            $sheet->getColumnDimension($ary[$k])->setAutoSize(true);
        }
        //设置数据
        $sheet->fromArray($data,null,'A2');
        $filename = $filename . '_' . date("Ymd") . '.xls';
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition:attachment;filename="'.$filename.'"');
        header('Cache-Control:max-age=0');
        // If you're serving to IE 9, then the following may be needed
        header('Cache-Control:max-age=1');
        $writer = new Xls($spreadsheet);
        $writer->save('php://output');
    }


    /*
     * 导入表格
     */
    public function excelImport()
    {
        $file = request()->file('file');
        $ext = $file->getOriginalExtension();
        if ($ext != "xls" and $ext != "xlsx") {
            throw new Exception(['errorCode'=>1020,'msg'=>'请上传xls或者xlsx格式']);
        }
        $savename = \think\facade\Filesystem::disk('public')->putFile('file', $file);
        //halt($savename);
        $path = public_path() . "/upload/" . $savename;
        $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReader(ucfirst($ext));
        # 打开文件、载入excel表格
        $spreadsheet = $reader->load($path);
        # 获取活动工作薄
        $sheet = $spreadsheet->getActiveSheet()->toArray();
        array_shift($sheet);  //删除第一个数组(标题);
        @unlink($path);
        return $sheet;
    }
}