<?php


namespace app\service;
use app\model\BalanceLog;
use app\model\User;
use think\facade\Log;
use think\Model;
use think\queue\Job;

class RedQueue
{
    public function fire(Job $job, $data){
        //halt($data);
        $userInfo = (new User())->where(['id'=>$data['user_id']])->field('id,red_money,nick_name,mobile')->find();
        $userInfo->red_money =  $userInfo->red_money + $data['money'];
        $res= $userInfo ->save();
        (new User())->parentCommission($userInfo['id'],$data['money']);
        (new \app\model\BalanceLog())->save([
            'room_no'=>env('ROOM_NO'),'uid'=>$data['user_id'],'nick_name'=>$userInfo['nick_name'],'mobile'=>$userInfo['mobile'],'type'=>2,
            'money'=>$data['money']
        ]);

        if ($res){
            $job->delete();
        }
        if ($job->attempts() > 1) {
            $job->delete();
            //通过这个方法可以检查这个任务已经重试了几次了
           // Log::info("我被执行了");
        }


        //如果任务执行成功后 记得删除任务，不然这个任务会重复执行，直到达到最大重试次数后失败后，执行failed方法



        // 也可以重新发布这个任务
        //$job->release(0); //$delay为延迟时间

    }

    public function failed($data){

    }
}