<?php

namespace app\api\validate;

use think\Validate;

class User extends Validate
{
    protected $rule = [
        'user_name|登陆账户' => ['require', 'length' => '2,11'],
        'nick_name|个人昵称' => ['require', 'length' => '2,11'],
        'passwd|登陆密码' => ['require', 'length' => '6,13'],
        'repasswd|确认密码' => ['require', 'length' => '6,13', 'confirm' => 'passwd'],
        'mobile|手机号' => ['require', 'mobile'],
        'user_qq|QQ账号' => ['require', 'number'],
    ];

    protected $message = [
        'user_name.length' => '登陆账号长度必须在2~11位之间',
        'nick_name.length' => '个人昵称长度必须在2~11位之间',
        'passwd.length' => '登陆密码长度必须在6~12位之间',
        'repasswd.length' => '确认密码长度必须在6~12位之间',
        'repasswd.confirm' => '登陆密码和确认密码不一致',
    ];

    // edit 验证场景定义
    public function sceneLogin()
    {
        return $this->only(['user_name', 'passwd']);
    }

    // edit 验证场景定义
    public function sceneRegister()
    {
        return $this->only(['user_name', 'nick_name', 'passwd', 'repasswd',  'user_qq'])
            ->append('user_name', ['checkUserName']);
    }


    // 自定义验证规则
    protected function checkUserName($value, $rule, $data = [])
    {
        $user_info = (new \app\model\User())->where(['user_name' => $value])->field('id')->find();
        if (!empty($user_info)) {
            return '账号已存在,请勿重复注册';
        }
        return true;
    }
}