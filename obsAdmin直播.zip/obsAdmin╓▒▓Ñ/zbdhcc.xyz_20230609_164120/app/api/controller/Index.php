<?php

namespace app\api\controller;

use app\exception\SuccessException;
use app\model\AdminGroup;
use app\model\AdList;
use app\model\Goods;
use app\model\Notice;
use app\model\Teacher;
use app\model\Turntable;
use app\model\TurntableLog;
use app\model\Qqkf;
use app\model\TeacherZan;
use app\model\User;
use app\service\Aliyunoss;
use app\exception\ErrorException;
use GatewayClient\Gateway;
use think\facade\Queue;

class Index extends Base
{
    public function __construct()
    {
        parent::__construct();
        Gateway::$registerAddress = config('gateway_worker.registerAddress');
    }
    public function index()
    {

        $userToken = request()->header("usertoken", "");
        $userInfo = (new User())->checkToken($userToken);
        //p($userInfo->toArray());
        if ($userInfo->user_status != '1') throw new ErrorException(['msg' => "账户已被停用，请联系客服"]);
        $userInfo['head_img'] = imgDomain($userInfo['head_img']);
        $userInfo['group_icon'] = imgDomain($userInfo['group_icon']);
        // $userInfo['user_bg'] = imgDomain($userInfo['user_bg']);
        $userInfo['user_bg'] = $this->room->default_bg;
        //判断用户是否是游客，并复制
        $userInfo->isYk = isYk($userInfo);
        $userInfo->is_login_admin = 0;//用户是否可以登录后台
        $userInfo->is_audit = 0;//用户是否有审核互动信息的权限
        if ($userInfo->user_type == 1) {
            $groupInfo = (new AdminGroup())->find($userInfo->group_id);
            $userInfo->is_login_admin = $groupInfo->is_login_admin;
            $userInfo->is_audit = $groupInfo->is_audit;
        }
        if ($userInfo->red_num <=0 && $userInfo->is_red==0) {
            $rand = [18.8,28.8,38.8,58.8,68.8,88.8];
            $money = $rand[array_rand($rand)];
            $userInfo->red_num = $money;
            $userInfo->save();
        }
        //处理直播视频观看问题
        //echo('<script>alert("免费观看时间已用完，请注册成为会员继续观看!");</script>');
        //echo('<script>alert("观看时间已用完，请联系客服处理!");</script>');
        if ($userInfo->user_type == 2) {
            $chaTime = $userInfo->look_time - time();
            $userInfo->djs_time = $chaTime;
            if ($chaTime <= 0) {
                $this->room->video_url = "";
                $userInfo->djs_time = 0;
            }else{
                //  $this->room->video_url = '<iframe height="498" width="510" src="'.url("Index/getVideo",['id'=>$userInfo->id,'uid'=>'b8b97f21db','vid'=>'2811028']).'" frameborder="0" allowfullscreen="true"></iframe>';
               $this->room->video_url = $this->room->video_url;
            }
            if(in_array($userInfo->admin_uid,[0,1,308,5165286])) {
                $imInfo=(new User)->getNextIm();
                $userInfo->save(['admin_uid'=>$imInfo->id]);
            }
        } else {
            $userInfo->djs_time = 365*24*60*60;
            // $this->room->video_url = '<iframe height="498" width="510" src="'.url("Index/getVideo",['id'=>$userInfo->id,'uid'=>'b8b97f21db','vid'=>'2811028']).'" frameborder="0" allowfullscreen="true"></iframe>';
             $this->room->video_url = $this->room->video_url;
        }
        unset($userInfo['passwd']);


        //获取机器人
        $robotList = [];
        if ($userInfo->user_type == 1) {
            $robotList = (new User)->where(['room_no' => $this->room_no, 'admin_uid' => $userInfo->id, 'is_robot' => '1'])
                ->field('id,nick_name,group_name')
                ->cache("robotList{$userInfo->id}", 24 * 3600)
                ->order('group_id desc')->select();
        }
        //获取banner
        //$bannerList = (new AdList())->where(['room_no' => $this->room_no, 'is_show' => 1])->cache('banner'.env('room_no'), 24 * 3600)->select();
        //foreach ($bannerList as $item) $item->ad_url = imgDomain($item->ad_url);
        $bannerList=[];

        //获取公告
        $notice = (new Notice())->where(['room_no' => $this->room_no])->order('id desc')->cache('notice'.env('room_no'), 24 * 3600)->value('content');

        //获取讲师
        // cache('teacher',null);
        $teacherImg = (new Teacher())->where(['room_no' => $this->room_no,'is_recommend'=>1])->order('update_time desc')->cache('teacher'.env('room_no'), 24 * 3600)->value('intro_img');

        //获取交易数据
        // $tradeData = (new \app\model\Room())->where(['room_no' => $this->room_no])->value('trade_data');
        // if(empty(cache('tradeList'.env('room_no')))){
        //     $tradeData = $this->room->trade_data;
        //     $tradeData = explode("\n", $tradeData);
        //     $tradeList = [];
        //     $temp = [];
        //     foreach ($tradeData as $k => $item) {
        //         if ($k > 0 && $k % 4 == 0) {
        //             $tradeList[] = $temp;
        //             $temp=[];
        //         }
        //         $temp[] = $item;
        //     }
        //     $tradeList[] = $temp;
        //     cache('tradeList'.env('room_no'), $tradeList, 24 * 3600);
        // }else{
        //     $tradeList = cache('tradeList'.env('room_no'));
        // }
//         if(empty(cache('tradeList'.env('room_no')))){
//            $tradeData = $this->room->trade_data;
//            $tradeData = explode("\n", $tradeData);
//            cache('tradeList'.env('room_no'), $tradeData, 24 * 3600);
//        }else{
//            $tradeData = cache('tradeList'.env('room_no'));
//        }
//         if(empty(cache('ranKing'.env('room_no')))){
//            $this->room->ran_king = explode("\n", $this->room->ran_king);
//            cache('ranKing'.env('room_no'), $this->room->ran_king, 24 * 3600);
//        }else{
//            $this->room->ran_king = cache('ranKing'.env('room_no'));
//        }
        
       $is_button=0;
      if ($userInfo['user_type']==1)  $is_button=1;
        $userInfo['invitation_url']= request()->domain(true)."/#/register?invitation=".$userInfo['invitation'];
        $userInfo['is_red'] =  (new AdminGroup())->where(['id'=>$userInfo->group_id])->value('is_red');
        $goodsInfo = (new Goods())->where(['status'=>1])->field('id,title,img,price')->find();
        exit(json_encode(['code' => 200, 'msg' => 'ok', 'data' => [
            'roomInfo' => $this->room,
            'robotList' => $robotList,
//            'bannerList' => $bannerList,
            'notice' => $notice,
//            'tradeList'=>$tradeData,
            'userInfo' => $userInfo,
            'is_button' => $is_button,
            'teacherImg' => imgDomain($teacherImg),
            'goodsInfo' => $goodsInfo,
            'turnopen'=>(new Turntable())->where(['room_no' => $this->room_no])->value('is_open'),
        ]]));
    }
    public function getVideo($id){
        $userId=intval($id);
        if(empty($userId)) return "";
        $host = request()->server('http_host');
        $origin = request()->server('http_referer');
        $arr = parse_url($origin);
        if(!isset($arr['host']) || empty($arr['host']) || $host!==$arr['host']) return "";
        //p($this->userinfo);
        $videoUrl = strpos($this->room->video_url, '[uid]') === false ? $this->room->video_url : str_replace('[uid]', $userId, $this->room->video_url);
        preg_match('/<iframe[^>]*\s+src="([^"]*)"[^>]*>/is', $videoUrl, $matched);
        return file_get_contents($matched[1]);
    }

    //获取在线用户列表
    public function getOnlineUser()
    {
        $where = [
            'room_no' => $this->room_no,
            'user_type' => '2',
            'is_online' => '1',
            'is_robot' => '0',
        ];
        $count = (new User())->where($where)->count();
        $list = (new User)->where($where)
            ->field("id,nick_name,head_img,user_type,group_icon")
            ->limit(100)
            ->order("is_online desc,update_time desc")
            ->cache(2 * 3600)
            ->select();
       
        $onlineUser = Gateway::getAllUidCount();
        // $rand = rand(10000,50000);
        // $time = date('H:i',time());
        
        
        
        // if(date('w',time())==6 || date('w',time())==0){
        //      $rand = rand(20,100);
        // }elseif($time > '9:30' && $time < '23:50'){
        //     $rand = rand(11111,99999);
        // }
        foreach ($list as $item) {
            $item['head_img'] = imgDomain($item['head_img']);
        }
        $totalUser = $this->room->online_num + $onlineUser;
        // $totalUser = $rand + $onlineUser;
        
        exit(json_encode(['code' => 200, 'msg' => 'ok', 'data' => ['list' =>$list, 'totalUser' => $totalUser]]));
    }


    //获取客服qq
    public function getQQ()
    {
        // if (empty($this->userinfo->bind_qq)) {
        //     $kfInfo = (new User)->getNextQQ();
        // } else {
        //     //检查客服qq有没有被删除了
        //     $kfInfo = (new Qqkf())->where(['qq_account' => $this->userinfo->bind_qq])->find();
        //     if (empty($kfInfo)) $kfInfo = (new User)->getNextQQ();
        // }
        // if (empty($kfInfo)) throw new ErrorException(['msg' => "很抱歉，当前暂无客服在线"]);
        // $this->userinfo->save(['bind_qq' => $kfInfo->qq_account]);

        // $kfInfo = (new User)->getNextQQ();
        // if (empty($kfInfo)) throw new ErrorException(['msg' => "很抱歉，当前暂无客服在线"]);
        $kfInfo = (new Qqkf())->where(['room_no' => $this->room_no,'is_yx'=>1])->order('id desc')->select();
        return json(['code' => 200, 'msg' => 'ok', 'data' => $kfInfo]);
    }


    //保存桌面
    public function saveDesktop()
    {
        header('Content-type: text/html');
        header('Content-Disposition: attachment; filename="' . $this->room->room_name . '.html"');
        // exit('<script language="javascript">location.href="' . $this->room->main_domain . '";</script>');
        exit('<script language="javascript">location.href="' . request()->domain(true) . '";</script>');
    }

    //设置皮肤
    public function setBg()
    {
        $num = request()->post('num/s', '');
        $src = $this->room->default_bg;
        if (!empty($num) && in_array($num, [1, 2, 3, 4, 5, 6, 7, 8])) {
            $src = "/static/index/bg/ys_{$num}.jpg";
        }
        $user_id = $this->userinfo->id;
        (new User)->cache("userInfo{$user_id}")->where(['id' => $user_id])->update(['user_bg' => $src]);
        return json(['code' => 200, 'msg' => 'ok', 'data' => []]);
    }

    //获取教师列表
    public function getTeacherList()
    {
        $list = (new Teacher())->where(['room_no' => $this->room_no])->field('id,head_img')->select();
        return json(['code' => 200, 'msg' => 'ok', 'data' => $list]);
    }

    //老师点赞
    public function zanTeacher($id)
    {
        $id = request()->param('id/d', 0);
        if (empty($id)) throw new ErrorException(['msg' => "参数错误"]);
        if ($this->userinfo->isYk) throw new ErrorException(['msg' => "很抱歉，系统不允许游客点赞，请登录"]);
        $info = (new TeacherZan())->where([
            "uid" => $this->userinfo->id,
            "teacher_id" => $id
        ])->whereDay("create_time")->find();
        if (!empty($info)) throw new ErrorException(['msg' => "您今天已经点过赞了，请不要重复点赞"]);
        $teacherInfo = (new Teacher())->where(['id' => $id, 'room_no' => $this->room_no])->find();
        $teacherInfo->zan_nums++;
        $teacherInfo->save();
        $res = (new TeacherZan())->save([
            'room_no' => $this->room_no,
            "uid" => $this->userinfo->id,
            "teacher_id" => $id
        ]);
        if ($res !== false) return json(['code' => 200, 'msg' => "点赞成功，感谢您的支持", 'data' => $teacherInfo->zan_nums]);
        throw new ErrorException(['msg' => "啊哦，点赞失败了，请刷新页面重新来一次"]);
    }

    //获取左侧导航
    public function getNavData()
    {
        $type = request()->param('type/s', '');
        if (!empty($type)) {
            if ($type == 'kcb') {
                return json(['code' => 200, 'msg' => '', 'data' => ['type' => 'img', 'url' => imgDomain($this->room->kcb_url)]]);
            }
            if ($type == 'product') {
                return json(['code' => 200, 'msg' => '', 'data' => ['type' => 'iframe', 'url' => (string)url('Index/productPage')]]);
            }
            if ($type == 'service') {
                return json(['code' => 200, 'msg' => '', 'data' => ['type' => 'img', 'url' => imgDomain('/static/theme1/images/fwtx.png')]]);
            }
            if ($type == 'caijing') {
                return json(['code' => 200, 'msg' => '', 'data' => ['type' => 'iframe', 'url' => 'https://rili-d.jin10.com/open.php?new=0.012113788980271378']]);
            }
        }
        throw new ErrorException(['msg' => "参数错误"]);
    }

    public function productPage()
    {
        return view('pages/product');
    }

    //获取大转盘、中奖记录信息
    public function getTurnTableInfo()
    {
        $turntableInfo = (new Turntable())->find(1);
        $turntableInfo->bg_img = imgDomain($turntableInfo->bg_img);
        if ($turntableInfo->is_open == 0) throw new ErrorException(['msg' => "大转盘处于关闭状态，请联系客服了解开放时间！"]);
        //历史中奖记录
        //$prizeList = (new TurntableLog())->limit(50)->select();
        //$prizeList = (new TurntableLog())->hasWhere('user', ['user_type' => 2])->limit(50)->select();
        $key = env('cache_redis.prefix', '') . 'prizeList'.env('room_no');
        $prizeList = cache($key);
        if (empty($prizeList)) {
            $prizeList = [];
            $robotList = (new User())->where([['is_robot', '=', 1], ['group_id', '>', 1]])->field('id,nick_name')->select();
            foreach ($robotList as $k => $item) {
                $nums = mt_rand(0, count($turntableInfo->prize_config) * 2);
                $prizeList[] = [
                    'nick_name' => $item->nick_name,
                    'prize' => $turntableInfo->prize_config[$nums] ?? '[谢谢参与]',
                ];
            }
            cache($key, $prizeList, 12 * 60 * 60);
        }
        return json(['code' => 200, 'msg' => 'ok', 'data' => ['turntableInfo' => $turntableInfo, 'prizeList' => $prizeList]]);
    }

    //抽奖方法
    public function luckDraw()
    {
        $turntableInfo = (new Turntable())->find(1);
        //halt($turntableInfo->toArray());
        if ($turntableInfo->is_open == 0) throw new ErrorException(['msg' => "大转盘处于关闭状态，请联系客服了解开放时间！"]);
        //判断是否是青铜会员
        //if($this->userinfo->user_type==2 && $this->userinfo->group_id!=4) throw new ErrorException(['msg' => "抱歉，此活动仅支持活动用户参与！"]);
         if($this->userinfo->user_type==2 && $this->userinfo->group_id < 2) throw new ErrorException(['msg' => "抱歉，此活动仅支持初级用户以上参与！"]);
        //今天是否抽奖过了
        // $userPrizeLog = (new TurntableLog())->where(['room_no' => $this->room_no, 'uid' => $this->userinfo->id])->whereDay("create_time")->find();
        $userPrizeLog = (new TurntableLog())->where(['room_no' => $this->room_no, 'uid' => $this->userinfo->id])->count();
        if ($userPrizeLog >=2) throw new ErrorException(['msg' => "您好，您已经参与过此活动了！"]);


        //获取奖品并初始化
        $prize_arr = [];
        foreach ($turntableInfo->prize_config as $k => $item) {
            $prize_arr[$k] = [
                'id' => $k + 1,
                'min' => ($k + 1) * 30 - 20,
                'max' => ($k + 1) * 30 - 10,
                'prize' => $item,
                'v' => mt_rand(1, mt_rand(20, 50))
            ];
            if ($turntableInfo->prize_gailv[$k] == 0) $prize_arr[$k]['v'] = 0;
        }
        try {
            $result = getPrize($prize_arr);
            $prizeLog = [
                'room_no' => $this->room_no,
                'uid' => $this->userinfo->id,
                'nick_name' => $this->userinfo->nick_name,
                'mobile' => $this->userinfo->mobile,
                'user_qq' => $this->userinfo->user_qq,
                'prize' => $result['prize'],
            ];
            $res = (new TurntableLog())->save($prizeLog);
            if ($res) return json(['code' => 200, 'msg' => "", 'data' => [
                'index' => $result['index'] - 1,
                'prize' => $result['prize'],
                'angle' => $result['angle'],
                'info' => [
                    'nick_name' => $this->userinfo->nick_name,
                    'mobile' => $this->userinfo->mobile,
                    'user_qq' => $this->userinfo->user_qq,
                    'create_time' => date("Y-m-d H:i:s")
                ]
            ]]);
        } catch (\Exception $e) {
            throw new ErrorException(['msg' => "系统开小差了，请您再次尝试"]);
        }
    }

    //oss上传策略
    public function getOssPolicy()
    {
        $dir = request()->param("dir/s", 'temp');
        $aliyunoss = new Aliyunoss();
        $res = $aliyunoss->aliossPolicy($dir);
        return json(['code' => 200, 'msg' => 'ok', 'data' => $res]);
    }
    public function sendMusic(){
        $type = request()->get('type/d',0); //播放语音选择
        if ($type==0)throw new ErrorException(['msg'=>"非法请求"]);
        if (  $this->userinfo->group_id  !=1 && $this->userinfo->group_id  !=8 && $this->userinfo->group_id  !=3) throw new ErrorException(['msg'=>"您当前没有播放权限"]);
        Gateway::sendToAll(json_encode([
            'type' => 'audio',
            'data' => ['type'=>$type]
        ]));
        return json(['code' => 200, 'msg' => '播放成功']);
    }
     /*
     * 红包雨
     */
    public function sendRedRain(){
        if ($this->userinfo->user_type !=1)throw new ErrorException(['msg'=>"非法请求"]);
        if (  $this->userinfo->group_id  !=1 && $this->userinfo->group_id  !=3) throw new ErrorException(['msg'=>"您当前没有开启权限"]);
        Gateway::sendToAll(json_encode([
            'type' => 'red_rain',
        ]));
        return json(['code' => 200, 'msg' => '开启成功']);
    }
     /*
     * 领取红包雨
     */
    public function createRedRain(){
        $money = request()->post('money',0);
        Queue::later(2,'app\service\RedQueue@fire',['user_id'=>$this->userinfo->id,'money'=>$money]);
        return json(['code' => 200, 'msg' => '领取成功']);
        //Queue::later(3*60,'app\api\library\TestJob@fire',(['uid'=>$order['buy_uid'],'id' => $order_id]),'testTask');
    }
     public function upload()
    {
        // p($this->userinfo->user_type);
        // exit;
       
       
        
         if($this->userinfo->user_type == 2) throw new ErrorException(['msg' => "参数错误"]);
        
        if (!request()->isPost()) throw  new ErrorException(['msg' => "参数错误"]);
        $files = request()->file('file');
         $dir = request()->param('dir','temp');
        try {
            validate(['file' => 'fileSize:2048000|fileExt:jpg,jpeg,gif,png'])->check(['file' => $files]);
            $savename = \think\facade\Filesystem::disk('public')->putFile($dir, $files);
            if (empty($savename)) throw  new ErrorException(['msg' => '上传失败']);
            if ($dir == 'im') return json(['code' => 0, 'msg' => '上传成功', 'data' => ['src' => "/upload/" . $savename]]);
            return json(['code' => 200, 'msg' => '', 'data' => ['src' => "/upload/" . $savename]]);
        } catch (\think\exception\ValidateException $e) {
            throw  new ErrorException(['msg' => $e->getMessage()]);
        }
    }
    /*
     * 商品详情
     */
    public function getGoodsInfo(){
        $id = request()->get('id/d',0);
        $goodsInfo = (new Goods())->where(['id'=>$id])->find();
        if (empty($goodsInfo)) throw new ErrorException(['msg'=>"非法请求"]);
        return json(['code' => 200, 'msg' => '', 'data' => ['goods' => $goodsInfo]]);
    }






    /*
     * 快递查询
     */
    public function logiStics(){
        if (!request()->isPost()) throw new ErrorException(['msg'=>"非法请求"]);
        $order_no = request()->post('order_no/s','');
        $host = "https://wuliu.market.alicloudapi.com";//api访问链接
        $path = "/kdi";//API访问后缀
        $appcode = "";//开通服务后 买家中心-查看AppCode
        $headers = array();
        array_push($headers, "Authorization:APPCODE " . $appcode);
        $querys = "no={$order_no}";  //参数写在这里
        $bodys = "";
        $url = $host . $path . "?" . $querys;
        $rule = getCurl($url,$host,$headers);
        switch ($rule['status']){
            case 0:
                return json(['code' => 200, 'msg' => '查询成功','data'=>['list'=>$rule['result']]]);
                break;
            case 201:
                throw new ErrorException(['msg'=>"快递单号错误"]);
                break;
            case 203:
                throw new ErrorException(['msg'=>"快递公司不存在"]);
                break;
            case 204:
                throw new ErrorException(['msg'=>"快递公司识别失败"]);
                break;
            case 205:
                throw new ErrorException(['msg'=>"没有信息"]);
                break;
            case 207:
                throw new ErrorException(['msg'=>"该单号被限制"]);
                break;
            default:
                throw new ErrorException(['msg'=>"请联系客服"]);
                break;
        }

    }
}
