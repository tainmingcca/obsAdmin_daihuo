<?php


namespace app\api\controller;


use app\exception\ErrorException;
use app\model\Room;
use app\model\User;
use app\model\UserGroup;

class Login
{
    public function login()
    {
        $data = request()->post();
        try {
            validate(\app\api\validate\User::class)->scene('login')->check($data);
        } catch (\Exception $e) {
            // 验证失败 输出错误信息
            throw new ErrorException(['msg' => $e->getError()]);
        }
        $userinfo = (new User())->where(['user_name' => $data['user_name'], 'room_no' => env('room_no')])->find();
        
        if (empty($userinfo)) throw new ErrorException(['msg' => "账号或密码错误"]);
        if (md5($data['passwd']) !== $userinfo->passwd) throw new ErrorException(['msg' => "账号或密码错误"]);
        if ($userinfo->user_status != '1') throw new ErrorException(['msg' => "账户已被停用，请联系客服"]);
        //if ($userinfo->user_type == 2 && $userinfo->look_time - time() <= 0) throw new ErrorException(['msg' => "观看时间已用完，请联系客服处理"]);
        if (empty($userinfo->sess_id)) $userinfo->sess_id = createToken($userinfo->user_name);
        
        
        $ip=getRealIP();
        //  $region = new \Ip2Region();
        // $address =  $region->btreeSearch($ip);
        // $geoisp = str_replace(['内网IP', '0', '|'], '', $address['region'] ?? '') ?: '-';
       
       // $geoisp=mb_substr($geoisp,2,-2);
        $userinfo->login_time = time();
        $userinfo->login_ip = $ip;
        $userinfo->is_online = 1;
         //$userinfo->address = $geoisp;
        $userinfo->save();
        //p($userinfo['sess_id']);
        return json(['code' => 200, 'msg' => "登陆成功", 'data' => $userinfo['sess_id']]);
    }

    public function reg()
    {
        $room_no = env('room_no');
        $room = (new Room())->where(['room_no' => $room_no])->cache("room_info{$room_no}",24 * 3600)->find();
        if (!$room->is_open_reg) throw new ErrorException(['msg' => "请联系客服注册马甲"]);
        
        $userModel = (new User());
        $data = request()->post();
        
        try {
            validate(\app\api\validate\User::class)->scene('register')->check($data);
        } catch (\Exception $e) {
            throw new ErrorException(['msg' => $e->getError()]);
        }
        $userinfo = (new User())->where(['nick_name' => trim($data['nick_name']), 'room_no' => $room_no])->field('id')->find();
        if (!empty($userinfo)) throw new ErrorException(['msg' => '个人昵称已被占用']);
        if ($room['is_open_sms']==1){
             $userMobile = (new User())->where(['mobile' => trim($data['mobile']), 'room_no' => $room_no])->field('mobile')->find();
        if (!empty($userMobile)) throw new ErrorException(['msg' => '手机号已被占用']);
            if(empty($data['code'])) throw new ErrorException(['msg' => '验证码不能为空']);
            if(cache(trim($data['mobile'])) != trim($data['code']) ) throw new ErrorException(['msg' => "验证码错误"]);
        }  
        if (!empty($data['invitation'])){
            $parentInfo = (new User())->where(['room_no' => $room_no,'invitation'=>$data['invitation']])->field('id')->find();
            if (empty($parentInfo)) throw new ErrorException(['msg' => '上级不存在，请核对']);
            $data['pid'] = $parentInfo['id'];
        }
         $rand = [18.8,28.8,38.8,58.8,68.8,88.8];
        $money = $rand[array_rand($rand)];
        $invitation = rand(11111111,99999999);
        //获取im客服id
        $imInfo = (new User())->getNextIm();
        $imUid = !empty($imInfo) ? $imInfo->id : 1;
        $qqInfo = (new User())->getNextQQ();
        $bind_qq = !empty($qqInfo) ? $qqInfo->qq_account : '';
        
        
        $user_group = (new UserGroup())->where(['id' => 2])->find();
        $data['passwd'] = md5($data['passwd']);
        $data['room_no'] = $room_no;
        $data['user_bg'] = $room->default_bg;
        $data['admin_uid'] = $imUid;
        $data['user_type'] = 2;
        $data['group_id'] = $user_group->id;
        $data['group_name'] = $user_group->group_name;
        $data['group_icon'] = $user_group->group_icon;
        $data['look_time'] = time() + $user_group->look_time * 60;
        $data['head_img'] = "/static/default/head_img.png";
        $data['from_url'] = request()->domain(true);
        $data['reg_ip'] = getRealIP();
        $data['login_time'] = time();
        $data['login_ip'] = getRealIP();
        $data['bind_qq'] = $bind_qq;
        $data['user_status'] = 1;
        $data['can_sendmsg']=1;
        $data['red_num']=$money;
        $data['invitation']=$invitation;
        $data['end_time']=date('Y-m-d',strtotime('+1 year'));
        $data['sess_id'] = createToken($data['user_name']);
        // $region = new \Ip2Region();
        // $address =  $region->btreeSearch($data['login_ip']);
        // $geoisp = str_replace(['内网IP', '0', '|'], '', $address['region'] ?? '') ?: '-';
        // $data['address']=mb_substr($geoisp,2,-2);
        $inviUrl= request()->domain(true)."/#/register?invitation=".$invitation;
        $res = $userModel->save($data);
        if ($res)  return json(['code' => 200, 'msg' => '注册成功，请登陆', 'data' => $data['sess_id'],'invitation'=>$inviUrl,'money'=>$money]);
    }
    
     /**
    * 发送短信
    */
    public function sendSms() 
    {
        $mobile = request()->get('mobile/s','','trim');
        $smsapi = "http://api.smsbao.com/";
        // 短信平台帐号15196952584
        $user = "";
        // 短信平台密码
        //$pass = md5('2c76f951551345229de0ec6b6dd0add9');
        $pass = '';
        $sign = "";
        $code = rand(000000,999999);
        $content = "【".$sign."】您的验证码为{$code}，验证码5分钟内有效。";
        // 要发送短信的手机号码
        $sendUrl = $smsapi . "sms?u=" . $user . "&p=" . $pass . "&m=" . $mobile . "&c=" . urlencode($content); //echo $sendUrl;
        $result = file_get_contents($sendUrl);
       
        if ($result == '0') {
            cache($mobile, $code, 300);
            return json(['code' => 200, 'msg' => '发送成功']);
        } else {
           return json(['code' => 201, 'msg' => '发送失败']);
        }

    }
}