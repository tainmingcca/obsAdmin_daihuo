<?php
namespace app\api\controller;

class Error
{
    public function __call($method, $args)
    {
        return 'error request!';
    }
}