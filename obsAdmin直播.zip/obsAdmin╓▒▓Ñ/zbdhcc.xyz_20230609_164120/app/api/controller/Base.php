<?php
namespace app\api\controller;
use app\model\Room;
class Base
{
    public function __construct()
    {
        $roomInfo = (new Room())->where(['room_no' => env('room_no')])
            ->withoutField('close_desc,filter_text,look_contact,danmu_time,current_teacher,ykbc_day,skin_path,create_time,update_time')
            ->cache('room_info'.env('room_no'), 24 * 3600)
            ->find();
        $roomInfo['room_icon'] = imgDomain($roomInfo['room_icon']);
        $roomInfo['logo_url'] = imgDomain($roomInfo['logo_url']);
        $roomInfo['index_dialog_img'] = imgDomain($roomInfo['index_dialog_img']);
        $roomInfo['default_bg'] = imgDomain($roomInfo['default_bg']);
       // p($roomInfo);

        $this->userinfo = request()->userInfo;
        $this->room = $roomInfo;
        $this->room_no = env('room_no');
    }
    
    
    
    
    public function upFile()
    {
        //exit;
        //if($this->userinfo->user_type==1) throw new ErrorException(['msg' => "参数错误"]);
        if (!request()->isPost()) throw  new ErrorException(['msg' => "参数错误"]);

        $files = request()->file('file');
        $dir = request()->param('dir','temp');
        try {
            validate(['file' => 'fileSize:1024000|fileExt:jpg,jpeg,gif,png'])->check(['file' => $files]);
            $savename = \think\facade\Filesystem::disk('public')->putFile($dir, $files);
            if (empty($savename)) throw  new ErrorException(['msg' => '上传失败']);
            if ($dir == 'im') return json(['code' => 0, 'msg' => '上传成功', 'data' => ['src' => "/upload/" . $savename]]);
            return json(['code' => 200, 'msg' => '', 'data' => ['src' => "/upload/" . $savename]]);
        } catch (\think\exception\ValidateException $e) {
            throw  new ErrorException(['msg' => $e->getMessage()]);
        }
    }


    /**
     * 保存base64文件
     * @param FJ_img base64文件
     */
    public function saveImg()
    {
        exit();
        if (!request()->isPost()) throw  new ErrorException(['msg' => "参数错误"]);
        $data = request()->post();
        if (!empty($data['file'])) {
            $reg = '/data:image\/(\w+?);base64,(.+)$/si';
            preg_match($reg, $data['file'], $match_result);
            if (!in_array($match_result[1], ['jpg', 'jpeg', 'png', 'gif'])) throw  new ErrorException(['msg' => "非法图片"]);

            $file_name = "img_" . time() . random_int(10000, 99999) . '.' . $match_result[1];
            $file_path = "/upload/{$data['dir']}/" . date("Ymd") . "/" . $file_name;
            $dir = "." . dirname($file_path) . "/";
            if (!is_dir($dir)) mkdir($dir, 0777, true);

            $num = file_put_contents("." . $file_path, base64_decode($match_result[2]));
            if (!empty($num)) return json(['code' => 200, 'msg' => '', 'data' => ['src' => $file_path]]);
            throw  new ErrorException(['msg' => "保存失败"]);
        } else {
            throw  new ErrorException(['msg' => "参数错误"]);
        }
    }
}