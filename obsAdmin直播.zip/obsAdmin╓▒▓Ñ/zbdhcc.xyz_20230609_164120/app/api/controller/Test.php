<?php
namespace app\api\controller;
use app\model\AdminGroup;
use app\model\UserGroup;
use app\model\User;
class Test extends Base{
    public function index(){
        exit();
        $host = request()->server('http_host');
        $origin = request()->server('http_referer');
        $arr = parse_url($origin);
        if(!isset($arr['host']) || empty($arr['host']) || $host!==$arr['host']) return "";
        return $this->room->video_url;
    }
}