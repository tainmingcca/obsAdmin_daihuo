<?php


namespace app\api\controller;
use app\model\Headimg;
use GatewayClient\Gateway;
use think\facade\View;
use app\exception\ErrorException;
class User extends Base
{
    //修改密码
    public function editPass()
    {
        $pwd = request()->post('pwd', '');
        $pwd1 = request()->post('pwd1', '');
        $pwd2 = request()->post('pwd2', '');
        if (strlen($pwd) < 6 || strlen($pwd1) < 6 || strlen($pwd2) < 6) throw new ErrorException(['msg' => "密码格式错误"]);
        if ($pwd == $pwd1) throw new ErrorException(['msg' => "新密码和原密码一样，无需修改"]);
        if (md5($pwd1) != md5($pwd2)) throw new ErrorException(['msg' => "两次输入的新密码不一致"]);
        $passwd = (new \app\model\User())->where(['id' => $this->userinfo->id])->value("passwd");
        if ($passwd != md5($pwd)) throw new ErrorException(['msg' => "原始密码错误"]);
        $this->userinfo->passwd = md5($pwd1);
        $res = $this->userinfo->save();
        if ($res !== false) return json(['code' => 200, 'msg' => '修改成功，再次登录需要使用新密码', 'data' => []]);
        throw new ErrorException(['msg' => "修改密码失败"]);
    }


    //修改个人资料
    public function profile()
    {
        $user_sex = request()->post("user_sex", "男");
        $user_qq = request()->post("user_qq", "");
        $this->userinfo->user_sex = $user_sex;
        $this->userinfo->user_qq = $user_qq;
        $res = $this->userinfo->save();
        if ($res !== false) return json(['code' => 200, 'msg' => '保存成功', 'data' => []]);
        throw new ErrorException(['msg' => "保存失败"]);
    }

    //更换头像
    public function changeImg()
    {
        if (request()->isPost()) {
            $id = request()->post('id', 0, 'intval');
            $info = (new Headimg())->find($id);
            $this->userinfo->head_img = $info->img_url;
            $res = $this->userinfo->save();
            if ($res !== false) {
                return json(['code' => 200, 'msg' => '保存成功', 'data' => []]);
            } else {
                throw new ErrorException(['msg' => "保存失败"]);
            }
        }
        $imgList = (new Headimg())->where(['is_use' => 1])->select();
        View::assign("imgList", $imgList);
        return View::fetch();
    }

    //退出登录
    public function logOut()
    {
        // p($this->userinfo);
        // $this->userinfo->save(['is_online' => 0]);
        return json(['code' => 200, 'msg' => '已经安全退出']);
    }

}