<?php


namespace app\api\controller;

use app\model\AdminGroup;
use app\model\Blackip;
use think\facade\Db;
use app\exception\ErrorException;
use app\model\ChatMsg;
use app\model\User;
use GatewayClient\Gateway;
use think\Model;

class Chat extends Base
{
    public function __construct()
    {
        parent::__construct();
        Gateway::$registerAddress = config('gateway_worker.registerAddress');
    }

    /**
     * 实时获取互动消息
     */
    public function getHdMsg()
    {
        //游客和讲师只能看到
        // if ($this->userinfo->user_type == 2 || ($this->userinfo->user_type == 1 && $this->userinfo->group_id == 3)) {
        //     $subQuery = Db::table('zb_chat_msg')
        //         // ->where("room_no={$this->room_no} and (status='1' or uid={$this->userinfo->id})")
        //         ->where("status='1' or uid={$this->userinfo->id}")
        //         ->order('update_time', 'desc')
        //         ->limit(20)
        //         ->buildSql();
        // } else {
        //     $subQuery = Db::table('zb_chat_msg')
        //         // ->where("room_no={$this->room_no}")
        //         ->order('update_time', 'desc')
        //         ->limit(20)
        //         ->buildSql();
        // }
        // $list = Db::table($subQuery . ' a')
        //     ->order('update_time', 'asc')
        //     ->select();
        if ($this->userinfo->user_type == 2 || ($this->userinfo->user_type == 1 && $this->userinfo->group_id == 3)) {
            $list = Db::table('zb_chat_msg')
                // ->where("room_no={$this->room_no} and (status='1' or uid={$this->userinfo->id})")
                ->where("status='1' or uid={$this->userinfo->id}")
                ->order('update_time', 'desc')
                ->limit(20)
                ->select()->toArray();
        } else {
            $list = Db::table('zb_chat_msg')
                // ->where("room_no={$this->room_no}")
                ->order('update_time', 'desc')
                ->limit(20)
                ->select()->toArray();
        }
        $list = array_reverse($list);
        $list = (new ChatMsg())->returnMsg($list);
        //p($list);
        exit(json_encode(['code' => 200, 'msg' => 'ok', 'data' => $list]));
        //return json(['code' => 200, 'msg' => 'ok', 'data' => $list]);
    }

    /**
     * 发送互动消息
     */
    public function sendHdMsg()
    {
        if ($this->userinfo->can_sendmsg == '0') throw new ErrorException(['msg' => "暂时无法发言，请联系客服"]);
        $content = request()->post("content", "", "trim");
        $content = trim(str_replace(['&nbsp;', '\n', '\t'], ' ', $content));
        $robotId = request()->post("robotId", 0, 'intval');
        $isDanmu = request()->post("isDanmu", 0, 'intval');
        $isGroup = request()->post("isDanmu", 0, 'intval');
        if (empty($content)) throw new ErrorException(['msg' => "不能发送空内容"]);
        $content = htmlspecialchars($content);
        //发送弹幕
        if ($this->userinfo->user_type == 1 && $isDanmu > 0) {
            Gateway::sendToAll(json_encode([
                'type' => 'danmu',
                'data' => [
                    'content' => strpos($content, "script") === false ? htmlspecialchars_decode($content) : $content,
                ]
            ]));
            return json(['code' => 200, 'msg' => 'ok', 'data' => []]);
        }


        $chatmsgModel = (new ChatMsg());
        $data = [
            'room_no' => $this->room_no,
            'uid' => $this->userinfo->id,
            'nick_name' => $this->userinfo->nick_name,
            'group_icon' => $this->userinfo->group_icon,
            'admin_nickname' => $this->userinfo->user_type == 1 ? $this->userinfo->nick_name : '',
            'admin_group_name' => $this->userinfo->group_name,
            'from_app' => isMobile() ? "WAP" : 'PC',
            'ip' => getRealIP(),
            'status' => $this->userinfo->user_type == 1 ? 1 : 0,
            'content' => $content,
            'is_true_user' => 1,
            'is_red' => 0,
        ];
        if ($this->userinfo->user_type == 1) {
            if ($robotId > 0) {
                $userinfo = (new User)->where(['id' => $robotId, 'is_robot' => 1])->find();
                if (empty($userinfo)) throw new ErrorException(['msg' => "发送失败"]);
                $data['uid'] = $userinfo->id;
                $data['nick_name'] = $userinfo->nick_name;
                $data['group_icon'] = $userinfo->group_icon;
                $data['is_true_user'] = 0;
            } else {
                $data['is_true_user'] = 0;
                $data['is_red'] = (new AdminGroup())->where(['id' => $this->userinfo->group_id])->value('is_red');
            }
        }
        $res = $chatmsgModel->save($data);
        if ($res) {
            $data = $chatmsgModel->toArray();
            $data['create_time'] = time();
            $data['update_time'] = time();

            $data = $chatmsgModel->returnMsg([$data]);

            if ($this->userinfo->user_type == 1) {
                Gateway::sendToAll(json_encode([
                    'type' => 'hd_msg',
                    'data' => $data[0]
                ]));
            } else {
                $sendIds = [$this->userinfo->id];
                $adminList = (new User)->where([
                    ['user_type', '=', '1'],
                    ['group_id', '<>', '3'],
                    //['is_online', '=', '1']
                ])->field("id")->select();
                foreach ($adminList as $item) {
                    $sendIds[] = $item->id;
                }
                Gateway::sendToUid($sendIds, json_encode([
                    'type' => 'hd_msg',
                    'data' => $data[0]
                ]));
            }
            return json(['code' => 200, 'msg' => 'ok', 'data' => []]);
        }
        throw new ErrorException(['msg' => "发送失败"]);
    }

    public function senGroupMsg()
    {
        if ($this->userinfo->can_sendmsg == '0') throw new ErrorException(['msg' => "暂时无法发言，请联系客服"]);
        $content = request()->post("content", "", "trim");
        $content = trim(str_replace(['&nbsp;', '\n', '\t'], ' ', $content));
        $robotId = request()->post("robotId/s", 0);
        if (empty($content)) throw new ErrorException(['msg' => "不能发送空内容"]);
        if (empty($robotId)) throw new ErrorException(['msg' => "您当前不能群发"]);
        $content = htmlspecialchars($content);
        if ($this->userinfo->user_type == 1 && !empty($robotId)) {
            $robotIds = explode(",", $robotId);
            foreach ($robotIds as $key => $val) {
                $data = [
                    'room_no' => $this->room_no,
                    'from_app' => isMobile() ? "WAP" : 'PC',
                    'admin_nickname' => $this->userinfo->user_type == 1 ? $this->userinfo->nick_name : '',
                    'admin_group_name' => $this->userinfo->group_name,
                    'ip' => getRealIP(),
                    'content' => $content,
                    'status' => $this->userinfo->user_type == 1 ? 1 : 0,
                    'is_true_user' => 1,
                    'is_red' => 0,
                ];
                $userinfo = (new User)->where(['id' => $val, 'is_robot' => 1])->find();

                if (empty($userinfo)) throw new ErrorException(['msg' => "发送失败"]);

                $data['uid'] = $userinfo['id'];
                $data['nick_name'] = $userinfo['nick_name'];
                $data['group_icon'] = $userinfo['group_icon'];
                if ($userinfo['user_type'] == 1) {
                    $data['is_true_user'] = 0;
                    $data['is_red'] = (new AdminGroup())->where(['id' => $userinfo->group_id])->value('is_red');
                } else {
                    $data['uid'] = $userinfo['id'];
                    $data['nick_name'] = $userinfo['nick_name'];
                    $data['group_icon'] = $userinfo['group_icon'];
                    $data['is_true_user'] = 0;
                }
                $chatmsgModel= (new ChatMsg());
                $res = $chatmsgModel->save($data);
                if ($res) {
                    $data = $chatmsgModel->toArray();
                    $data['create_time'] = time();
                    $data['update_time'] = time();
                    $data = $chatmsgModel->returnMsg([$data]);
                    Gateway::sendToAll(json_encode([
                        'type' => 'hd_msg',
                        'data' => $data[0]
                    ]));
                }
//                if ($userinfo->user_type == 1) {
//                    Gateway::sendToAll(json_encode([
//                        'type' => 'hd_msg',
//                        'data' => $data[0]
//                    ]));
//                } else {
//                    $sendIds = [$userinfo->id];
//                    $adminList = (new User)->where([
//                        ['user_type', '=', '1'],
//                        ['group_id', '<>', '3'],
//                        //['is_online', '=', '1']
//                    ])->field("id")->select();
//                    foreach ($adminList as $item) {
//                        $sendIds[] = $item->id;
//                    }
//                    Gateway::sendToUid($sendIds, json_encode([
//                        'type' => 'hd_msg',
//                        'data' => $data[0]
//                    ]));
//                }
            }
            return json(['code' => 200, 'msg' => 'ok', 'data' => []]);
        }
        throw new ErrorException(['msg' => "发送失败"]);
    }

    public function sendBalloon()
    {
        if ($this->userinfo->user_type == 1) {
            Gateway::sendToAll(json_encode([
                'type' => 'yanhua',
                'date' => '5',  //烟花播放时间
            ]));
            return json(['code' => 200, 'msg' => 'ok', 'data' => []]);
        } else {
            throw new ErrorException(['msg' => "您没有权限"]);
        }
    }

    /**
     * 右键动作
     */
    public function contextMenu()
    {
        $type = request()->post("type/s", "");
        if ($type == "jinyan") {
            return $this->jinyan();
        } elseif ($type == "pingb") {
            return $this->pingb();
        } elseif ($type == "del") {
            return $this->dels();
        } elseif ($type == "pass") {
            return $this->pass();
        }
    }


    /**
     * 禁言该用户
     */
    public function jinyan()
    {
        if ($this->userinfo->user_type != 1) throw new ErrorException(['msg' => "操作失败"]);
        $id = request()->post('id', 0, 'intval');
        (new ChatMsg())->where(['id' => $id])->update(['status' => 0]);
        $user_id = (new ChatMsg())->where(['id' => $id])->value('uid');
        (new User())->where(['id' => $user_id])->save(['can_sendmsg' => 0]);
        return json(['code' => 200, 'msg' => 'ok', 'data' => []]);
    }

    /**
     * 屏蔽该ip
     */
    public function pingb()
    {
        if ($this->userinfo->user_type != 1) throw new ErrorException(['msg' => "操作失败"]);
        $id = request()->post('id', 0, 'intval');
        (new ChatMsg())->where(['id' => $id])->update(['status' => 0]);
        $ip = (new ChatMsg())->where(['id' => $id])->value('ip');
        (new Blackip())->save([
            'room_no' => $this->room_no,
            'act_user_name' => $this->userinfo->user_name,
            'ip' => $ip
        ]);
        return json(['code' => 200, 'msg' => 'ok', 'data' => []]);
    }


    /**
     * 通过互动消息
     */
    public function pass()
    {
        if ($this->userinfo->user_type != 1) throw new ErrorException(['msg' => "操作失败"]);
        $id = request()->post('id', 0, 'intval');
        $chatMsgModel = new ChatMsg();
        $chatMsgInfo = $chatMsgModel->find($id);
        if ($chatMsgInfo->status) return json(['code' => 200, 'msg' => 'ok', 'data' => []]);
        $chatMsgInfo->status = 1;
        $chatMsgInfo->save();

        //会员发言通过后加1积分
        $userinfo = (new User())->where(['id' => $chatMsgInfo->uid])->field('id,user_type,group_id,look_time')->find();
        if ($userinfo->user_type == 2 && $userinfo->group_id > 1) {
            $toatlTime = $userinfo['look_time'] + 300;
            $userinfo->save(['jifen' => Db::raw('jifen+1'), 'look_time' => $toatlTime]);
        }
        //end

        $data = $chatMsgModel->returnMsg([$chatMsgInfo->toArray()]);
        $data[0]['send_time'] = date("H:i");
        if ($this->userinfo->user_type == 1) {
            $exclude_client_ids = [];
            $chat_client_id = Gateway::getClientIdByUid($chatMsgInfo->uid);
            if (!empty($chat_client_id)) $exclude_client_ids[] = $chat_client_id[0];
            $self_client_id = Gateway::getClientIdByUid($this->userinfo->id);
            if (!empty($self_client_id)) $exclude_client_ids[] = $self_client_id[0];
            Gateway::sendToAll(json_encode([
                'type' => 'hd_msg',
                'data' => $data[0]
            ]), false, $exclude_client_ids);
        }
        return json(['code' => 200, 'msg' => 'ok', 'data' => []]);
    }


    /**
     * 删除互动消息
     */
    public function dels()
    {
        if ($this->userinfo->user_type != 1) throw new ErrorException(['msg' => "操作失败"]);
        $id = request()->post('id', 0, 'intval');
        $chatMsgModel = new ChatMsg();
        $chatMsgInfo = $chatMsgModel->find($id);
        $data = $chatMsgInfo->toArray();
        $res = $chatMsgInfo->delete();
        if ($res) {
            $data = $chatMsgModel->returnMsg([$data]);
            Gateway::sendToAll(json_encode([
                'type' => 'del_hd_msg',
                'data' => $data[0]['id']
            ]));
            return json(['code' => 200, 'msg' => 'ok', 'data' => []]);
        }
        throw new ErrorException(['msg' => "操作失败"]);
    }
}