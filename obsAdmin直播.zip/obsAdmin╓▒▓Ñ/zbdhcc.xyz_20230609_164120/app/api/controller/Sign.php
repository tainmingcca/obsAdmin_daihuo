<?php


namespace app\api\controller;


use app\exception\BaseException;
use app\exception\ErrorException;
use app\exception\SuccessException;
use app\model\UserSign;
use think\facade\Db;
use think\Model;

class Sign extends Base
{
    public function __construct()
    {
        parent::__construct();
        $this->_model = (new \app\model\Sign());
    }
    /*
     * 签到设置列表
     */
    public function SingList(){
        if (empty(cache('sign'.env('ROOM_NO')))){
            $list = $this->_model->field('id,term,name,value')->select();
            cache('sign'.env('ROOM_NO'),$list,24*3600);
        }
        $list = cache('sign'.env('ROOM_NO'));
        return json(['code'=>200,'msg'=>'success','data'=>['list'=>$list]]);
    }
    public function getUserSignCount (){
        $term = request()->get('term/s','');

        $count = (new UserSign())->where([
            "uid" => $this->userinfo->id,
            "term" => $term,
            'room_no'=>$this->room_no,
        ])->count();
        return json(['code'=>200,'msg'=>'success','data'=>['count'=>$count]]);
    }
    /*
     * 用户签到
     */
    public function createSign(){
        $term = request()->post('term/s','');
        $id = request()->post('id/d',0);

        if (empty($id)) throw new ErrorException(['msg'=>'非法请求']);
        if (empty($term)) throw new ErrorException(['msg'=>'非法请求']);
        if ($this->userinfo->isYk) throw new ErrorException(['msg' => "很抱歉，系统不允许游客签到，请登录"]);
        $info = (new UserSign())->where([
            "uid" => $this->userinfo->id,
            "term" => $term,
            'room_no'=>$this->room_no,
        ])->whereDay("create_time")->find();
        if (!empty($info)) throw new ErrorException(['msg' => "您今天已签到成功,不允许重复签到"]);
        $count = (new UserSign())->where([
            "uid" => $this->userinfo->id,
            "term" => $term,
            'room_no'=>$this->room_no,
        ])->count();
        if ($count >=7) throw new ErrorException(['msg' => "您已经签到满7次，请等待下次活动开启"]);
        $signInfo = (new \app\model\Sign())->where(['id'=>$id])->field('name,value')->find();
        Db::startTrans();
        try {
            (new UserSign())->save([
                'room_no'=>$this->room_no,
                'uid'=>$this->userinfo->id,'nick_name'=>$this->userinfo->nick_name,'mobile'=>$this->userinfo->mobile,
                'qq'=>$this->userinfo->user_qq,'term'=>$term,'day'=>$signInfo['name'],'value'=>$signInfo['value']
            ]);
            // 提交事务
            Db::commit();
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            throw  new ErrorException(['msg'=>"啊哦，签到失败，请刷新页面重新来一次"]);
        }
        return json(['code'=>200,'msg'=>'success']);

    }
    /*
     * 用户签到记录
     */
    public function userSingList(){
        $page = request()->get('page/d',1);
        $limit = request()->get('limit/d',10);
        $list = (new UserSign())->where([
            "uid" => $this->userinfo->id,
            'room_no'=>$this->room_no,
        ])->page($page,$limit)->order('id desc')->select();
        $count = (new UserSign())->where([
            "uid" => $this->userinfo->id,
            'room_no'=>$this->room_no,
        ])->page($page,$limit)->count();
        return json(['code'=>200,'msg'=>'success','data'=>['list'=>$list,'count'=>$count]]);
    }

}