<?php

namespace app\api\middleware;

use app\model\Blackip;
class CheckIp
{
    public function handle($request, \Closure $next)
    {
        $ipInfo = (new Blackip())->where(['room_no' => env('room_no'), 'ip' => getRealIP()])->find();
        if (!empty($ipInfo)) return abort(404, 'not found');
        return $next($request);
    }
}