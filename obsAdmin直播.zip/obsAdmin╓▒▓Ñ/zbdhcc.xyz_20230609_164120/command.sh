#!/bin/bash
cd /www/wwwroot/newtpl.com
php think worker:gateway stop && php think worker:gateway -d start && php think clearsql