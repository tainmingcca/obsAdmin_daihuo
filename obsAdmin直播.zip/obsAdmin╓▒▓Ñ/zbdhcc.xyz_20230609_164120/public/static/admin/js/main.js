layui.use(['form', 'element', 'layer', 'jquery'], function () {
    var form = layui.form,
        layer = parent.layer === undefined ? layui.layer : top.layer,
        element = layui.element;
    $ = layui.jquery;

    //icon动画
    $(".panel a").hover(function () {
        $(this).find(".layui-anim").addClass("layui-anim-scaleSpring");
    }, function () {
        $(this).find(".layui-anim").removeClass("layui-anim-scaleSpring");
    })
    $(".panel a").click(function () {
        parent.addTab($(this));
    })

    //加载层
    var index = layer.load(0, {shade: 0.6}); //0代表加载的风格，支持0-2
    layer.close(index);
    //开始添加数据
    $.ajax({
        url: "getMainData",
        type: "get",
        dataType: "json",
        success: function (res) {
            var regNum = res.data.regNum.reverse();
            if (regNum.length > 0) {
                var xdata = new Array();
                var ydata = new Array();
                $(regNum).each(function (idx) {
                    xdata[idx] = regNum[idx].date;
                    ydata[idx] = Number(regNum[idx].nums);
                });
                regechat(xdata, ydata, "regnum", "最近30天注册人数图");
            }
            var onlineNum = res.data.onlineNum;
            if (onlineNum.length > 0) {
                var xdata = new Array();
                var ydata = new Array();
                $(onlineNum).each(function (idx) {
                    var linedt = onlineNum[idx];
                    xdata[idx] = linedt.time;
                    ydata[idx] = Number(linedt.nums);
                });
                regechat(xdata, ydata, "container", "实时在线人数图");
            }
            var groupNum = res.data.groupNum;
            if (groupNum.length > 0) {
                var xdata = new Array();
                $(groupNum).each(function (idx) {
                    var grpdt = groupNum[idx];
                    xdata[idx] = grpdt.name;
                });
                if (xdata.length > 0) {
                    grpechat(xdata, groupNum);
                }
            } else {
                $("#hyfz").text('暂无会员');
            }
            layer.close(index);
        }
    })
})

//折线图
function regechat(dateList, valueList, obj, txt) {
    var dom = document.getElementById(obj);
    var myChart = echarts.init(dom);
    var app = {};
    option = null;


    option = {
        visualMap: [{
            show: false,
            type: 'continuous',
            seriesIndex: 0,
            min: 0
        }, {
            show: false,
            type: 'continuous',
            seriesIndex: 1,
            dimension: 0,
            min: 0,
            max: dateList.length - 1
        }],


        title: [{
            left: 'center',
            text: txt
        }],
        tooltip: {
            trigger: 'axis'
        },
        xAxis: [{
            data: dateList
        }],
        yAxis: [{
            splitLine: {show: false}
        }],
        lineStyle: {
            color: '#FF5722'
        },
        series: [{
            type: 'line',
            showSymbol: false,
            data: valueList
        }]
    };
    ;
    if (option && typeof option === "object") {
        myChart.setOption(option, true);
        window.addEventListener("resize", function () {
            myChart.resize();
        });
    }
}

//饼图
function grpechat(name, data) {
    var dom = document.getElementById("hyfz");
    var myChart2 = echarts.init(dom);
    var app = {};
    option = null;
    option = {
        title: {
            text: '用户组成员分布图',
            x: 'center'
        },
        tooltip: {
            trigger: 'item',
            formatter: "{a} <br/>{b} : {c} ({d}%)"
        },
        legend: {
            orient: 'vertical',
            left: 'left',
            data: name
        },
        series: [
            {
                name: '用户组成员分布图',
                type: 'pie',
                radius: '55%',
                center: ['50%', '60%'],
                data: data,
                itemStyle: {
                    emphasis: {
                        shadowBlur: 10,
                        shadowOffsetX: 0,
                        shadowColor: 'rgba(0, 0, 0, 0.5)'
                    }
                }
            }
        ]
    };
    ;
    if (option && typeof option === "object") {
        myChart2.setOption(option, true);
        window.addEventListener("resize", function () {
            myChart2.resize();
        });
    }
}