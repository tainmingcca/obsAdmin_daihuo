﻿var layer, carousel, count = 0, nowpage = 1, nick = "", room = "", wel = "", imimg = "", grop = "";
//链接WebSkoet
var connection = $.hubConnection();
var contosoChatHubProxy = connection.createHubProxy('chatHub');
connection.start(function () {
    // 连接开启成功才会进入这里
}).fail(function () {
    //连接开启失败则进入这里
    connection.start();
});

$(function () {
    //整个网页滚动条
    $(".lft").niceScroll({
        cursorcolor: "#6f6e6d",
        cursoropacitymax: 0.9,
        touchbehavior: false,
        cursorwidth: "5px",
        cursorborder: "0",
        zindex: 999999,
        cursorborderradius: "5px",
        autohidemode: false
    });
    //QQ表情
    if (window.location.href.indexOf("Msg_IMWap") > -1) {
        $('#fc').qqFace({
            id: 'facebox',
            assign: 'PriMsg',
            bottom: -245,
            nums: 10,
            path: '/face/arclist/'	//表情存放的路径
        });
    } else {
        $('#fc').qqFace({
            id: 'facebox',
            assign: 'PriMsg',
            bottom: -250,
            nums: 15,
            path: '/face/arclist/'	//表情存放的路径
        });
    }

    //监控键盘，当按下组合键的时候触发发送按钮
    $("#PriMsg").keypress(function (e) {
        if (e.which == 13 || e.which == 10) {
            SendImMsg();
        } else if (e.which == 13 || e.which == 10) {
            SendImMsg();
        }
    })

    //检测左边展开
    $(".lftopen").click(function () {
        var cls = $(".lftopen i").attr("class");
        var wid = $(window).width();
        if (cls.indexOf("layui-icon-next") > -1) {
            $(".lft").width(wid * 0.4);
            $(".rht").width(wid * 0.6);
            $(".lft").show(300);//展开
            $(".lftopen i").removeClass("layui-icon-next");
            $(".lftopen i").addClass("layui-icon-prev");
            $(this).css("left", wid * 0.4 - 12 + "px");
        } else {
            $(".rht").width(wid);
            $(".lft").hide();//回收
            $(".lftopen i").addClass("layui-icon-next");
            $(".lftopen i").removeClass("layui-icon-prev");
            $(this).css("left", "0");
        }
    });

    $(".layui-icon-close").click(function () {
        parent.layer.close(parent.imwid);
    });

    //上传图片
    layui.use(['layer', 'upload', 'carousel'], function () {
        var upload = layui.upload;
        layer = layui.layer;
        carousel = layui.carousel;
        GetUs(1);//开始加载
        //普通图片上传
        var uploadInst = upload.render({
            elem: '#tpsc'
            , url: '/Front/FctPage/LayUp.aspx'
            , before: function (obj) {
                //预读本地文件示例，不支持ie8
                obj.preview(function (index, file, result) {

                });
            }
            , done: function (res) {
                //如果上传失败
                if (res.code > 0) {
                    return layer.msg('上传失败');
                }
                //上传成功
                $(res).each(function (index) {
                    var val = res[index];
                    if (val.rtn.split(',')[0] == "true") {
                        var con = $("#PriMsg").html();
                        con = con == "<br>" || con == "<br/>" ? "" : con;
                        var pic = "<img src='" + val.rtn.split(',')[1] + "' style='max-width:400px;cursor:pointer;' onclick='bigimg(this)' /></ br>";
                        $("#PriMsg").html(con + pic);

                    } else {
                        parent.layer.msg(val.rtn, {icon: 5});
                    }
                });
            }
        });
    })


    //直接粘贴图片
    var imgReader = function (item) {
        var blob = item.getAsFile(),
            reader = new FileReader();

        reader.onload = function (e) {

            $.ajax({
                type: "POST",
                url: "/Front/FctPage/SaveImg.aspx",
                data: {"data": e.target.result},
                datatype: "text",//"xml", "html", "script", "json", "jsonp", "text".     
                success: function (vid_result) {
                    if (vid_result == "false") {
                        var img = new Image();
                        img.src = e.target.result;
                        //document.body.appendChild( img );
                        $("#PriMsg").append(img);
                        var con = $("#PriMsg").html();
                        $("#PriMsg").html(con);
                    } else {
                        if (vid_result == "nopow") {
                            layer.alert('很抱歉，您所在的组无权发送图片！');
                        } else {
                            $("#PriMsg").append("<img src='" + vid_result + "' style='max-width:400px;cursor:pointer;' onclick='bigimg(this)' /><br />");
                        }
                    }
                }
            });
        };

        reader.readAsDataURL(blob);
    };

    document.getElementById('PriMsg').addEventListener('paste', function (e) {

        var clipboardData = e.clipboardData,
            i = 0,
            items, item, types;

        if (clipboardData) {
            items = clipboardData.items;

            if (!items) {
                return;
            }

            item = items[0];
            types = clipboardData.types || [];

            for (; i < types.length; i++) {
                if (types[i] === 'Files') {
                    item = items[i];
                    break;
                }
            }

            if (item && item.kind === 'file' && item.type.match(/^image\//i)) {
                var yqx = 0;
                if ($("#pow", parent.document).text() != "") {
                    var usdata = eval($("#pow", parent.document).text());//转换为json对象 
                    $.each(usdata, function (index, qx) {
                        if (qx.FSTP == "1" || $("#usnm").text() == "admin") {
                            imgReader(item);
                            yqx = 1;
                        }
                    });
                    if (yqx == 0) {
                        layer.msg('很抱歉，您所在的用户组无权发送图片');
                    }
                }

            }
        }
    });
})

//欢迎语
function Welcome(type) {
    var tit = type == 1 ? "请您输入常用语" : "请设置默认欢迎语";
    var idx = layer.prompt({title: tit, formType: 2}, function (text, index) {
        layer.close(index);
        var rmidx = layer.msg('正在修改', {
            icon: 16
            , shade: 0.01
            , time: 0
        });
        $.ajax({
            type: "POST",
            url: "Msg_Welcome.aspx",
            data: {"welcon": text, "type": type},
            datatype: "text",//"xml", "html", "script", "json", "jsonp", "text".     
            success: function (result) {
                layer.close(rmidx);
                if (isJson(result)) {
                    var rtncon = eval(result);//转换为json对象 
                    $.each(rtncon, function (index, con) {
                        if (con.back == "true") {
                            layer.msg('修改成功');
                            if (type == 0) {
                                wel = text;
                            } else {
                                var cons = text.length > 12 ? text.substring(0, 12) + "..." : text;
                                $("#cy").append("<option title='" + text + "'>" + cons + "</option>");
                            }
                        } else {
                            layer.msg('修改失败，请再试一次');
                        }
                    });
                }
            }
        });
    });
    if (type == 0) {
        $('#layui-layer' + idx + " .layui-layer-input").val(wel);
    }
}

//点击以后的判断
function sltclk() {
    var vs = $('#cy option:selected').val();
    if ($("#cy option").length == 1 && vs == "新建常用语") {
        Welcome(1);
    }
}

//发送常用语
function sendcy() {
    if ($('#cy option:selected').val() == "新建常用语") {
        Welcome(1);
    } else {
        //询问框
        var xw = layer.confirm('请选择发送或删除？', {
            btn: ['发送', '删除'] //按钮
        }, function () {
            layer.close(xw);
            var con = $("#cy").find("option:selected").attr("title");
            if (typeof (con) != "undefined") {
                SendImTrue(con);
                $("#cy").val("新建常用语");
            }
        }, function () {
            if (typeof ($("#cy").val()) != "undefined") {
                var rmidx = layer.msg('正在删除', {
                    icon: 16
                    , shade: 0.01
                    , time: 0
                });
                $.ajax({
                    type: "POST",
                    url: "Msg_ImMsgDel.aspx",
                    data: {"id": $("#cy").val()},
                    datatype: "text",//"xml", "html", "script", "json", "jsonp", "text".     
                    success: function (result) {
                        layer.close(rmidx);
                        if (isJson(result)) {
                            var rtncon = eval(result);//转换为json对象 
                            $.each(rtncon, function (index, con) {
                                if (con.back == "true") {
                                    layer.msg('删除成功');
                                    $("#cy option[value='" + $("#cy").val() + "']").remove();
                                } else {
                                    layer.msg('删除失败，请再试一次');
                                }
                            });
                        }
                    }
                });
            }
        });
    }
}

//左侧鼠标点击
function liclk() {
    $(".lft ul li").click(function () {
        $(this).removeClass("lits layui-anim layui-anim-fadein layui-anim-loop");//先把提醒的动画删掉
        $(".lft ul li").each(function () {
            if ($(this).hasClass("lisel")) {
                $(this).removeClass("lisel");
                $(this).addClass("limr");
            }
        });
        $(this).removeClass("limr");
        $(this).addClass("lisel");
        if ($(this).find("a").attr("data-content") != $(".tit a:eq(0)").text()) {
            $(".tit img").attr("src", $(this).find("img").attr("src"));
            $(".tit a:eq(0)").text($(this).find("a").attr("data-content"));
            $(".tit a:eq(1)").text("【" + $(this).find("a").attr("data-target") + "】");
            GetMsg($(this).find("a").attr("data-content"));//开始加载数据
        }
    });

    $(".lft ul li i").click(function () {
        if ($(this).parent().children("a").attr("data-content") == $(".tit a:eq(0)").text()) {
            layer.msg('当前聊天窗口无法销毁！', {icon: 5});
        } else {
            $(this).parent().remove();
            $(".lft").getNiceScroll().resize();
        }
    });
}

//获取用户列表
function GetUs(page) {
    var rmidx = layer.msg('消息加载中', {
        icon: 16
        , shade: 0.01
        , time: 0
    });
    $.ajax({
        type: "POST",
        url: "Msg_GetImUser.aspx",
        data: {"page": page},
        datatype: "text",//"xml", "html", "script", "json", "jsonp", "text".     
        success: function (result) {
            layer.close(rmidx);
            if (isJson(result)) {
                var rtncon = eval(result);//转换为json对象 
                $.each(rtncon, function (index, con) {
                    if (con.back == "true") {
                        count = Number(con.count);//总条数
                        wel = con.wel;//欢迎语
                        grop = con.grp;
                        if (con.grp == "IM客服") {//加载常用语
                            $(".layui-icon-dialogue,#cy").show();
                            if (isJson(con.msg)) {
                                var msgcon = eval(con.msg);//转换为json对象 
                                $.each(msgcon, function (idx, mcon) {
                                    if (mcon.Im_Con != "") {
                                        var cons = mcon.Im_Con != null && mcon.Im_Con.length > 12 ? mcon.Im_Con.substring(0, 12) + "..." : mcon.Im_Con;
                                        $("#cy").append("<option title='" + mcon.Im_Con + "' value='" + mcon.ID + "'>" + cons + "</option>");
                                    }
                                });
                            }
                        }

                        if (isJson(con.data)) {
                            var datacon = eval(con.data);//转换为json对象 
                            $.each(datacon, function (idx, dtcon) {
                                var line = dtcon.US_Line == 1 ? "line" : "unline";
                                if (con.grp != "IM客服" && con.grp != "管理员") {
                                    wel = dtcon.US_ManageWel;//欢迎语
                                    imimg = dtcon.US_Img;//IM头像
                                }
                                var cls = con.noread != null && con.noread != "" && isbf(con.noread, dtcon.US_NickName) ? " lits layui-anim layui-anim-fadein layui-anim-loop" : "";
                                var str = '<li class="limr ' + cls + '"><img src="' + dtcon.US_Img + '" class="layui-circle" /><a data-content="' + dtcon.US_NickName + '" data-target="' + dtcon.US_Group + '" data-bind="' + dtcon.US_Line + '">' + dtcon.US_NickName + '</a><i class="layui-icon layui-icon-close-fill"></i><b class="layui-icon layui-icon-circle-dot ' + line + '"></b></li>';
                                if (cls != "") {
                                    $(".lft ul").prepend(str);
                                } else {
                                    $(".lft ul").append(str);
                                }
                                if (idx == 29 && count > 30) {
                                    nowpage += 1;
                                    $(".lft ul").append('<li class="limr" style="text-align:center;line-height:40px;" onclick="GetUs(' + nowpage + ');$(this).remove();">加载更多</li>');
                                }
                            });

                            nick = con.nick;//我的昵称
                            room = con.room;//房间号
                            if (location.href.indexOf("Msg_IMWap") == -1) {
                                $(".lft").getNiceScroll().resize();
                            }
                            liclk();
                            if ($(".tit a:eq(0)").text() == "" && $(".lft ul .lisel").length == 0) {//假如从来没加载过
                                $(".lft ul li:eq(0)").removeClass("limr lits layui-anim layui-anim-fadein layui-anim-loop");//先把提醒的动画删掉
                                $(".lft ul li:eq(0)").addClass("lisel");
                                $(".tit img").attr("src", $(".lft ul li:eq(0)").find("img").attr("src"));
                                $(".tit a:eq(0)").text($(".lft ul li:eq(0)").find("a").attr("data-content"));
                                $(".tit a:eq(1)").text("【" + $(".lft ul li:eq(0)").find("a").attr("data-target") + "】");
                                GetMsg($(".lft ul li:eq(0)").find("a").attr("data-content"));//开始自动加载数据
                            }

                        } else {
                            layer.msg('当前并未获取到您的私聊对象，系统将自动关闭');
                            window.setTimeout("top.layer.closeAll()", 1200);
                        }
                    } else {
                        layer.msg('当前并未获取到您的私聊对象，系统将自动关闭');
                        window.setTimeout("top.layer.closeAll()", 1200);
                    }
                });
            } else {
                $(".lft ul").append('<li class="limr"><img src="/Image/face/01.png" class="layui-circle" /><a>暂无数据</a><i class="layui-icon layui-icon-close-fill"></i> </li>');
            }
        }
    });
}

//获取聊天消息
function GetMsg(usnk) {
    if (typeof (usnk) != "undefined" && usnk != "") {
        $.ajax({
            type: "POST",
            url: "Msg_GetPriFstMsg.aspx",
            data: {"tous": usnk},
            datatype: "text",//"xml", "html", "script", "json", "jsonp", "text".     
            success: function (result) {
                if (isJson(result)) {
                    $("#primsgtable").empty();
                    var rtncon = eval(result);//转换为json对象 
                    $.each(rtncon, function (index, con) {
                        if (con.back == "true") {
                            if (isJson(con.data)) {
                                var datacon = eval(con.data);//转换为json对象 
                                $.each(datacon, function (idx, dtcon) {
                                    if (dtcon.Msg_Promoter == usnk) {//假如发送人是聊天的对象
                                        var str = '<tr><td class="face1"><img src="' + dtcon.Msg_Ico + '" class="layui-circle" /></td><td><p>' + dtcon.Msg_Promoter + ' ' + dtcon.Msg_SendTime.replace("T", " ").substring(0, 19) + '</p><div class="con1">' + dtcon.Msg_Content + '</div></td><td /></tr>';
                                        $("#primsgtable").append(str);
                                    } else {//假如是我自己发送的
                                        var str = '<tr><td /><td><p class="p1">' + dtcon.Msg_SendTime.replace("T", " ").substring(0, 19) + ' ' + dtcon.Msg_Promoter + '</p><div class="con2">' + dtcon.Msg_Content + '</div></td><td class="face2"><img src="' + dtcon.Msg_Ico + '" class="layui-circle" /></td></tr>';
                                        $("#primsgtable").append(str);
                                    }
                                });

                                if (wel != "" && grop != "IM客服" && grop != "管理员") {
                                    var str = '<tr><td class="face1"><img src="' + imimg + '" class="layui-circle" /></td><td><p>' + usnk + '</p><div class="con1">' + wel + '</div></td><td /></tr>';
                                    $("#primsgtable").append(str);
                                }
                                $('.datacon').scrollTop($('.datacon').prop("scrollHeight"), 200);//滚动条到最底部
                            }
                        } else {
                            if (wel != "" && grop != "IM客服" && grop != "管理员") {
                                var str = '<tr><td class="face1"><img src="' + imimg + '" class="layui-circle" /></td><td><p>' + usnk + '</p><div class="con1">' + wel + '</div></td><td /></tr>';
                                $("#primsgtable").append(str);
                            } else {
                                var str = '<tr><td class="nom" colspan="3">暂无消息</td></tr>';
                                $("#primsgtable").append(str);
                            }
                        }
                    });
                }
            }
        });
    }
}

//接收到新消息
contosoChatHubProxy.on('PriNewMsg', function (con) {
    if (isJson(con)) {
        var rtncon = eval(con);//转换为json对象 
        $.each(rtncon, function (index, cons) {
            if (cons.Msg_Room == room && cons.Msg_Promoter == nick || cons.Msg_Recipent == nick) {
                if ($(".tit a:eq(0)").text().trim() == cons.Msg_Promoter || $(".tit a:eq(0)").text().trim() == cons.Msg_Recipent) {
                    if ($("#primsgtable tr").length == 1 && $("#primsgtable tr td:eq(0)").text() == "暂无消息") {
                        $("#primsgtable").empty();
                    }//要是显示的是暂无消息就把这一行删掉
                    if (cons.Msg_Promoter == $(".tit a:eq(0)").text().trim()) {//假如发起人是对方
                        var str = '<tr><td class="face1"><img src="' + cons.Msg_Ico + '" class="layui-circle" /></td><td><p>' + cons.Msg_Promoter + ' ' + cons.Msg_SendTime.replace("T", " ").substring(0, 19) + '</p><div class="con1">' + cons.Msg_Content + '</div></td><td /></tr>';
                        $("#primsgtable").append(str);
                    } else {//假如是我自己发送的
                        var str = '<tr><td /><td><p class="p1">' + cons.Msg_SendTime.replace("T", " ").substring(0, 19) + ' ' + cons.Msg_Promoter + '</p><div class="con2">' + cons.Msg_Content + '</div></td><td class="face2"><img src="' + cons.Msg_Ico + '" class="layui-circle" /></td></tr>';
                        $("#primsgtable").append(str);
                    }
                    if (cons.Msg_Recipent == nick) {
                        ReadTrue(cons.Msg_OnlyID);//假如接收消息的人是我，就设置为已读
                    }
                } else {//假如发消息的不是当前聊天的用户
                    NewMsgTf(cons.Msg_Ico, cons.Msg_Promoter, cons.Msg_Group);
                }
            }
        });
        $('.datacon').scrollTop($('.datacon').prop("scrollHeight"), 200);//滚动条到最底部
    }
})

//发送私聊消息回调函数
function SendImMsg() {
    //定义收到服务器的响应后需要执行的JavaScript函数
    var vlu = $("#PriMsg").html().trim().replace(/<(?!img).*?>/g, '').replace('src="data:image', ' style="max-width:400px;cursor:pointer;" onclick="bigimg(this)" src="data:image');//先把截图的这些替换好;
    if (vlu.length > 0) {
        if (vlu.indexOf("data:image") > -1) {
            findimg(vlu);//截图的先转成图片
        } else {
            SendImTrue(vlu);
        }
    } else {
        layer.msg('消息内容不能为空', {icon: 5});
        return;
    }
}

//将消息设置为已读
function ReadTrue(oid) {
    if (typeof (oid) != "undefined" && oid != "") {
        $.ajax({
            type: "POST",
            url: "Msg_ImRead.aspx",
            data: {"oid": oid},
            datatype: "text", //"xml", "html", "script", "json", "jsonp", "text".
            success: function (result) {

            }
        });
    }
}

//json里是否包含
function isbf(json, usnick) {
    var tf = false;
    if (isJson(json)) {
        var rtncon = eval(json);//转换为json对象 
        $.each(rtncon, function (index, con) {
            if (con.Msg_Promoter == usnick) {
                tf = true;
                return false;
            }
        });
    }
    return tf;
}

//找到字符串里的img并检查
function findimg(str) {
    //思路分两步：
    //1，匹配出图片img标签（即匹配出所有图片），过滤其他不需要的字符
    //2.从匹配出来的结果（img标签中）循环匹配出图片地址（即src属性）

    //匹配图片（g表示匹配所有结果i表示区分大小写）
    var imgReg = /<img.*?(?:>|\/>)/gi;
    //匹配src属性
    var srcReg = /src=[\'\"]?([^\'\"]*)[\'\"]?/i;
    var arr = str.match(imgReg);

    if (countChar(arr) == 1) {
        for (var i = 0; i < arr.length; i++) {
            var src = arr[i].match(srcReg);
            //获取图片地址
            if (src[1] && src[1].indexOf("data:image") > -1) {
                $.ajax({
                    type: "POST",
                    async: false,
                    url: "/Front/FctPage/SaveImg.aspx",
                    data: {"data": src[1]},
                    datatype: "text",//"xml", "html", "script", "json", "jsonp", "text".     
                    success: function (vid_result) {
                        if (vid_result == "false") {
                            layer.alert('很抱歉，您的截图发送失败了，请您更换浏览器再次尝试');
                            return;
                        } else {
                            if (vid_result == "nopow") {
                                str = "";
                                layer.alert('很抱歉，您所在的组无权发送图片！');
                                $("#PriMsg").text('');
                                return;
                            } else {
                                str = str.replace(src[1], vid_result);
                            }
                        }
                    }
                });
            }
        }
    } else {
        layer.alert('对不起，您的浏览器不支持发送多张截图，请截选一张发送！', {icon: 5});
        str = "";
        return;
    }
    if (str != "") {
        SendImTrue(str);
    }
}

//查找字符在字符串中出现了几次
function countChar(str) {    //str为字符串，char为字符
    var cnt = 0;
    if (str.length > 1) {
        for (var i = 0; i < str.length; i++) {
            if (str[i].indexOf("data:image") > -1) {
                cnt += 1;
            }
        }
    } else {
        cnt = 1;
    }
    return cnt;
}

//图片转换完成后再发送
function SendImTrue(vl) {
    $.ajax({
        type: "POST",
        url: "Msg_PrivateSend.aspx",
        data: {"con": vl, "touser": $(".tit a:eq(0)").text()},
        datatype: "text",//"xml", "html", "script", "json", "jsonp", "text".     
        success: function (result) {
            if (isJson(result)) {
                var rtncon = eval(result);//转换为json对象 
                $.each(rtncon, function (index, con) {
                    if (con.request == "true") {
                        $("#PriMsg").html('');
                    } else {
                        layer.msg(con.request, {icon: 5});
                    }
                })
            }
        }
    });
}

//判断新的消息的用户在不在用户表里面，在的话调到最上面来
function NewMsgTf(usimg, usnk, grp) {
    $(".lft ul li a").each(function (index) {	//这里可以对每一个li进行遍历
        if ($(this).text().trim() == usnk) {
            $(this).parent().remove();
        }
    });
    var str = '<li class="limr lits layui-anim layui-anim-fadein layui-anim-loop"><img src="' + usimg + '" class="layui-circle" /><a data-content="' + usnk + '" data-target="' + grp + '" data-bind="1">' + usnk + '</a><i class="layui-icon layui-icon-close-fill"></i><b class="layui-icon layui-icon-circle-dot line"></b></li>';
    $(".lft ul").prepend(str);
    liclk();
}

//有人下线了
contosoChatHubProxy.on('zxlb', function (nick, rm) {
    if ($("#room", parent.document).text() == rm && $("#qxz", parent.document).text() == "1") {
        if ($(".lft ul li").length > 0) {
            $(".lft ul li").each(function (index) {	//这里可以对每一个li进行遍历
                if ($(this).find("a").text().trim() == nick) {
                    $(this).find("b").removeClass("line");
                    $(this).find("b").addClass("unline");
                }
            });
        }
    }
});

//有人上线了
contosoChatHubProxy.on('UsLine', function (con) {
    if (con.split(',').length == 2 && $("#room", parent.document).text() == con.split(',')[1]) {
        if ($(".lft ul li").length > 0) {
            $(".lft ul li").each(function (index) {	//这里可以对每一个li进行遍历
                if ($(this).find("a").text().trim() == con.split(',')[0]) {
                    $(this).find("b").removeClass("unline");
                    $(this).find("b").addClass("line");
                }
            });
        }
    }
});

//判断字符串是不是标准的JSON格式
function isJson(str) {
    try {
        if (str != null && typeof JSON.parse(str) == "object") {
            return true;
        }
    } catch (e) {
    }
    return false;
}

//获取更多消息
function GetMoreMsg() {
    if ($(".tit a:eq(0)").text() != "" && $("#primsgtable tr").length >= 1 && $("#primsgtable tr:eq(0)").find("td").text() != "暂无消息") {
        parent.history($('.tit a:eq(0)').text());
    } else {
        layer.msg('暂无更多消息');
    }
}

//放大图片
function bigimg(imgsrc) {
    var src = $(imgsrc).attr('src');
    if (src != "" && typeof (src) != "undefined") {

        var kgb;//宽高比
        var wid;//图片宽度
        var hgt;//图片高度
        imgReady(src, function () {
            kgb = this.height / this.width;
            if (kgb > 1) {
                hgt = this.height > 600 ? 600 : this.height;
                wid = ght / kgb;
            } else {
                wid = this.width > 1000 ? 1000 : this.width;
                hgt = wid * kgb;
            }
        });

        //页面层
        if (wid > 0 && hgt > 0) {
            var tcwid = wid >= $("body", parent.document).width() ? $("body", parent.document).width() - 10 : wid;
            var cnt = tcwid != wid ? '<img src="' + src + '" style="width:' + tcwid + 'px;"/>' : '<img src="' + src + '" style="width:' + wid + 'px;height:' + hgt + 'px;"/>';
            if ($("#pcwap", parent.document).text() == "0") {
                if (parent.bigmg == 0) {
                    parent.bigmg = parent.layer.open({
                        type: 1,
                        title: false,
                        maxmin: false,
                        shadeClose: true, //开启点击遮罩关闭层
                        closeBtn: true,
                        skin: 'layui-layer-rim', //加上边框
                        area: [tcwid + 5, hgt], //宽高
                        content: cnt,
                        zIndex: 99999999,
                        end: function () {
                            parent.bigmg = 0;
                        }
                    });

                    if (parent.bigmg == 0) {
                        parent.bigmg = parent.layer.open({
                            type: 1,
                            title: false,
                            maxmin: false,
                            shadeClose: true, //开启点击遮罩关闭层
                            closeBtn: true,
                            skin: 'layui-layer-rim', //加上边框
                            area: [tcwid + 5, hgt], //宽高
                            content: cnt,
                            zIndex: 99999999,
                            end: function () {
                                parent.bigmg = 0;
                            }
                        });
                    }
                }
            } else {
                hgt = $("body", parent.document).width() * kgb;
                parent.bigmg = parent.layer.open({
                    type: 2,
                    title: false,
                    maxmin: false,
                    shadeClose: true, //开启点击遮罩关闭层
                    closeBtn: true,
                    shade: [0.98, '#000'],
                    skin: 'layui-layer-nobg', //没有背景色
                    area: ["98%", hgt + "px"], //宽高
                    zIndex: 99999999,
                    content: ['/Front/Message/Msg_BigImg.html?src=' + src + "&hgt=" + hgt], //iframe的url  'no'是禁用滚动条
                    end: function () {
                        parent.bigmg = 0;
                    }
                });
            }
        }

    }
}

var imgReady = (function () {
    var list = [], intervalId = null,

        // 用来执行队列
        tick = function () {
            var i = 0;
            for (; i < list.length; i++) {
                list[i].end ? list.splice(i--, 1) : list[i]();
            }
            ;
            !list.length && stop();
        },

        // 停止所有定时器队列
        stop = function () {
            clearInterval(intervalId);
            intervalId = null;
        };

    return function (url, ready, load, error) {
        var onready, width, height, newWidth, newHeight,
            img = new Image();

        img.src = url;

        // 如果图片被缓存，则直接返回缓存数据
        if (img.complete) {
            ready.call(img);
            load && load.call(img);
            return;
        }
        ;

        width = img.width * 1.5;
        height = img.height * 1.5;

        // 加载错误后的事件
        img.onerror = function () {
            error && error.call(img);
            onready.end = true;
            img = img.onload = img.onerror = null;
        };

        // 图片尺寸就绪
        onready = function () {
            newWidth = img.width * 1.5;
            newHeight = img.height * 1.5;
            if (newWidth !== width || newHeight !== height ||
                // 如果图片已经在其他地方加载可使用面积检测
                newWidth * newHeight > 1024
            ) {
                ready.call(img);
                onready.end = true;
            }
            ;
        };
        onready();

        // 完全加载完毕的事件
        img.onload = function () {
            // onload在定时器时间差范围内可能比onready快
            // 这里进行检查并保证onready优先执行
            !onready.end && onready();

            load && load.call(img);

            // IE gif动画会循环执行onload，置空onload即可
            img = img.onload = img.onerror = null;
        };

        // 加入队列中定期执行
        if (!onready.end) {
            list.push(onready);
            // 无论何时只允许出现一个定时器，减少浏览器性能损耗
            if (intervalId === null) intervalId = setInterval(tick, 40);
        }
        ;
    };
})();