﻿// QQ表情插件
(function ($) {
    $.fn.qqFace = function (options) {
        var defaults = {
            id: 'facebox',
            path: 'face/',
            assign: 'content1',
            tip: 'em_',
            nums: 10,
            bottom: -280
        };
        var option = $.extend(defaults, options);
        var assign = $('#' + option.assign);
        var id = option.id;
        var path = option.path;
        var tip = option.tip;
        var bottom = option.bottom;
        var nums = option.nums;//每行显示多少个

        if (assign.length <= 0) {
            //alert('请勿频繁刷新。');
            return false;
        }

        $(this).click(function (e) {
            $("#fontsty").hide();
            $("#gnlb").hide();
            $("#ctlb").hide();
            var strFace, labFace;
            if ($('#' + id).length <= 0) {
                strFace = '<div id="' + id + '" style="position:absolute;display:none;z-index:1000;" class="qqFace">' +
                    '<table border="0" cellspacing="0" cellpadding="0"><tr>';
                for (var i = 1; i <= 89; i++) {
                    labFace = '[' + tip + i + ']';

                    strFace += '<td><img src="' + path + i + '.gif" style="width:24px;height:24px;" onclick="$(\'#' + option.assign + '\').setCaret();$(\'#' + option.assign + '\').insertAtCaret(\'' + labFace + '\');" /></td>';
                    if (i % nums == 0) strFace += '</tr><tr>';
                }
                strFace += '</tr></table></div>';
            } else {
                $('#' + id).hide();
                $('#' + id).remove();
            }

            $(this).parent().append(strFace);
            var offset = $(this).position();
            var top = offset.top + $(this).outerHeight();
            $('#' + id).css('top', bottom);
            $('#' + id).css('left', offset.left);
            $('#' + id).show();
            e.stopPropagation();
        });

        $(".Top,.wbtmk,.sd_cont,.trea,.snd").click(function () {
            $('#' + id).hide();
            $('#' + id).remove();
        });
    };

})(jQuery);

jQuery.extend({
    unselectContents: function () {
        if (window.getSelection)
            window.getSelection().removeAllRanges();
        else if (document.selection)
            document.selection.empty();
    }
});
jQuery.fn.extend({
    selectContents: function () {
        $(this).each(function (i) {
            var node = this;
            var selection, range, doc, win;
            if ((doc = node.ownerDocument) && (win = doc.defaultView) && typeof win.getSelection != 'undefined' && typeof doc.createRange != 'undefined' && (selection = window.getSelection()) && typeof selection.removeAllRanges != 'undefined') {
                range = doc.createRange();
                range.selectNode(node);
                if (i == 0) {
                    selection.removeAllRanges();
                }
                selection.addRange(range);
            } else if (document.body && typeof document.body.createTextRange != 'undefined' && (range = document.body.createTextRange())) {
                range.moveToElementText(node);
                range.select();
            }
        });
    },

    setCaret: function () {
        if (!$.support) return;
        var initSetCaret = function () {
            var textObj = $(this).get(0);
            textObj.caretPos = document.selection.createRange().duplicate();
        };
        $(this).click(initSetCaret).select(initSetCaret).keyup(initSetCaret);
    },

    insertAtCaret: function (textFeildValue) {
        textFeildValue = textFeildValue.replace(/\[em_([0-9]*)\]/g, '<img src="/static/index/face/arclist/$1.gif" border="0" />');
        var textObj = $(this).get(0);
        if (document.all && textObj.createTextRange && textObj.caretPos) {
            var caretPos = textObj.caretPos;
            caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == '' ?
                textFeildValue + '' : textFeildValue;
        } else if (textObj.setSelectionRange) {
            var rangeStart = textObj.selectionStart;
            var rangeEnd = textObj.selectionEnd;
            var tempStr1 = textObj.innerHTML.substring(0, rangeStart);
            var tempStr2 = textObj.innerHTML.substring(rangeEnd);
            textObj.innerHTML = tempStr1 + textFeildValue + tempStr2;
            textObj.focus();
            var len = textFeildValue.length;
            textObj.setSelectionRange(rangeStart + len, rangeStart + len);
            textObj.blur();
        } else {
            textObj.innerHTML = textObj.innerHTML == "<br>" ? textFeildValue : textObj.innerHTML + textFeildValue;
        }
    }
});