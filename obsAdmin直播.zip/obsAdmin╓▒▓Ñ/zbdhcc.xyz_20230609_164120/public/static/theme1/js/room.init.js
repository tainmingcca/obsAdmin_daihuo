
$(function () {
    isPhone = isTelphone();
    if (isPhone) {
        $(".notice").hide();
        $(".m_header").show();
    }else{
        $(".notice").show();
        $(".m_header").hide();
    }
    resize();
    $(window).resize(function () {
        resize();
        chatcontainer.scrollToLast();
    });
    //初始化视频源
    loadVideo();
    //初始化在线用户
    getOnlineUser();
    $('#list_u').mCustomScrollbar({
        setWidth:"200",
        autoHideScrollbar:false,
        autoDraggerLength: true,//根据内容区域自动调整滚动条拖块的长度
        autoExpandScrollbar: true,
        advanced:{ updateOnImageLoad: true, updateOnBrowserResize:true }
    });
});



 

